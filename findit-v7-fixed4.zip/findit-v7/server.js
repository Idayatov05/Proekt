const http = require('http');
const { PORT } = require('./src/config/env');
const { initDb } = require('./src/config/database');
const app = require('./src/app');
const { startArchiveService } = require('./src/services/archiveService');
const { startCleanupService } = require('./src/services/cleanupService');
const { initWebSocket } = require('./src/services/wsService');
const path = require('path');
const fs   = require('fs');

// Создаём папку для загрузок если нет
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const server = http.createServer(app);

initDb()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`\n🔍 FindIt запущен: http://localhost:${PORT}`);
      console.log(`   Логин админа:  admin@findit.kz / admin123`);
      console.log(`   Логин юзера:   user@findit.kz  / user123\n`);
    });
    initWebSocket(server);
    startArchiveService();
    startCleanupService();
  })
  .catch(err => { console.error('Ошибка БД:', err); process.exit(1); });
