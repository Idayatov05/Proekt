# FindIt v6 — Changelog

## Новое в этой версии

### 🔴 Критичные улучшения

**Верификация email** (`src/controllers/auth.js`, `public/verify-email.html`)
- При регистрации отправляется письмо с ссылкой подтверждения
- `GET /api/auth/verify-email?token=...` — страница verify-email.html
- `POST /api/auth/resend-verification` — повторная отправка
- Без SMTP_HOST в .env — токен выводится в консоль (для разработки)

**Очистка uploads/** (`src/services/cleanupService.js`)
- Каждые 24 часа сравнивает файлы на диске с записями в БД
- Удаляет файлы, которые больше не принадлежат ни одному объявлению или пользователю
- Первый запуск через 5 минут после старта сервера

---

### ⚡ Производительность

**WebSocket вместо polling** (`src/services/wsService.js`)
- socket.io на `/ws`; аутентификация через JWT-токен
- Чат полностью переведён на WS: сообщения приходят мгновенно
- **Индикатор "печатает…"** — отображается в реальном времени
- Fallback: если WS недоступен — polling каждые 5 сек (было 4 сек)
- Уведомления тоже приходят через WS + toast в реальном времени
- `setInterval` на badges снижен с 30 до 60 сек (WS берёт реалтайм)
- ⚠️ Требует: `npm install` (добавлен `"socket.io": "^4.7.5"`)

---

### 🗺 Поиск в радиусе

**`GET /api/items/nearby?lat=&lng=&radius=5`** (`src/models/index.js`, `src/controllers/social.js`)
- Формула Хаверсина прямо в SQLite — без внешних зависимостей
- Параметры: `lat`, `lng`, `radius` (км, default=5), `type`, `category`
- Результат отсортирован по расстоянию (`distance_km` в каждой строке)

---

### 🔔 Подписки на категорию / район

**Новая таблица `subscriptions`** (`database/schema.sql`, `src/models/index.js`)
- `POST /api/subscriptions` — создать подписку (тип, категория, ключевое слово места)
- `GET  /api/subscriptions` — список своих подписок
- `DELETE /api/subscriptions/:id` — удалить подписку
- При создании нового одобренного объявления — автоматически находим совпадения и шлём уведомления подписчикам
- То же при одобрении через админку
- **UI**: новый пункт «🔔 Подписки» в сайдбаре кабинета с формой управления

---

### 👤 Публичный профиль

**`/user.html?id=:id`** (`public/user.html`, `src/routes/index.js`)
- Имя, аватар, биография, рейтинг ⭐, очки, дата регистрации
- Все активные объявления пользователя
- Все отзывы с оценками
- Кнопка «Пожаловаться» (с модальным окном)
- В карточке объявления имя автора теперь — кликабельная ссылка

---

### 🚩 Жалобы на пользователей

**Новая таблица `user_reports`** (`database/schema.sql`, `src/models/index.js`)
- `POST /api/users/:id/report` — причины: spam / fraud / abusive / fake / other
- UNIQUE constraint: нельзя пожаловаться дважды на одного пользователя
- **Админка**: новая вкладка «👤 Жалобы на пользователей» с фильтрами pending / reviewed / dismissed
- Действия: заблокировать пользователя, рассмотрено, отклонить

---

### 📊 Аналитика и экспорт

**Графики за 30 дней** (`public/admin.html`, `src/controllers/admin.js`)
- Новая вкладка «📊 Аналитика» в админке
- Три bar-chart через Chart.js (CDN): новые объявления / возвраты / регистрации
- Данные из расширенного `GET /api/admin/stats` → поле `charts`

**CSV экспорт**
- `GET /api/admin/items/export.csv` — все объявления с BOM для Excel
- `GET /api/admin/users/export.csv` — все пользователи
- Кнопки «⬇ CSV» прямо в шапке соответствующих вкладок

**Массовые действия**
- Чекбоксы на карточках объявлений в модерации
- `POST /api/admin/items/bulk` с `{ ids: [...], action: 'approve'|'reject'|'delete' }`
- Кнопки «✅ Одобрить выбранные» / «❌ Отклонить выбранные» над списком

---

## Полный список изменённых файлов

| Файл | Что изменилось |
|------|----------------|
| `server.js` | http.Server + initWebSocket + startCleanupService |
| `package.json` | +socket.io |
| `database/schema.sql` | +subscriptions, +user_reports |
| `src/config/database.js` | +миграции email_verified, subscriptions, user_reports |
| `src/models/index.js` | FTS5 поиск, Subscriptions, UserReports, listNearby |
| `src/controllers/auth.js` | +verifyEmail, +resendVerification, sendVerificationEmail |
| `src/controllers/admin.js` | analytics, CSV, bulk, user reports, notify subscribers |
| `src/controllers/items.js` | +notify subscribers on create |
| `src/controllers/social.js` | +subscriptions, +reportUser, +getNearby |
| `src/routes/index.js` | все новые роуты |
| `src/services/wsService.js` | 🆕 WebSocket сервис |
| `src/services/cleanupService.js` | 🆕 очистка uploads |
| `public/app.js` | WS чат, subscriptions UI, bulk actions, analytics charts |
| `public/admin.html` | новые вкладки, CSV кнопки, chart.js |
| `public/dashboard.html` | socket.io CDN, subscriptions pane |
| `public/user.html` | 🆕 публичный профиль |
| `public/verify-email.html` | 🆕 страница подтверждения email |

---

## Как применить

```bash
# 1. Замените файлы проекта
# 2. Установите зависимости
npm install

# 3. Запустите — все миграции применятся автоматически
npm start
```

### Новые переменные окружения (опционально)

```env
APP_URL=https://your-domain.com    # для ссылок в письмах верификации
```

### Новые API endpoints

| Метод | URL | Описание |
|-------|-----|---------|
| `GET` | `/api/auth/verify-email?token=` | Подтвердить email |
| `POST` | `/api/auth/resend-verification` | Повторная отправка письма |
| `GET` | `/api/items/nearby` | Поиск в радиусе `?lat&lng&radius` |
| `GET` | `/api/subscriptions` | Мои подписки |
| `POST` | `/api/subscriptions` | Создать подписку |
| `DELETE` | `/api/subscriptions/:id` | Удалить подписку |
| `POST` | `/api/users/:id/report` | Пожаловаться на пользователя |
| `GET` | `/api/admin/user-reports` | Жалобы на пользователей (admin) |
| `PATCH` | `/api/admin/user-reports/:id` | Обработать жалобу (admin) |
| `GET` | `/api/admin/items/export.csv` | CSV объявлений |
| `GET` | `/api/admin/users/export.csv` | CSV пользователей |
| `POST` | `/api/admin/items/bulk` | Массовые действия |
