const router  = require('express').Router();
const multer  = require('multer');
const path    = require('path');
const { authRequired, authOptional, adminRequired } = require('../middleware/auth');
const { compressImage, compressImages } = require('../middleware/imageProcessor');
const auth    = require('../controllers/auth');
const items   = require('../controllers/items');
const social  = require('../controllers/social');
const admin   = require('../controllers/admin');
const game    = require('../controllers/gamification');
const { Users, Items: ItemsModel, Ratings } = require('../models');
const asyncHandler = require('../utils/asyncHandler');
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname,'..','..','public','uploads')),
  filename:    (req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname)}`),
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) =>
    /image\/(jpeg|png|webp|gif)/.test(file.mimetype) ? cb(null, true) : cb(new Error('Только изображения')),
});

// AUTH
router.post('/auth/register',        auth.register);
router.post('/auth/login',           auth.login);
router.get ('/auth/me',              authRequired, auth.me);
router.put ('/auth/profile',         authRequired, auth.updateProfile);
router.post('/auth/forgot-password', auth.forgotPassword);
router.post('/auth/reset-password',  auth.resetPassword);
router.post('/auth/change-password', authRequired, auth.changePassword);
router.post('/auth/avatar',          authRequired, upload.single('avatar'), compressImage, auth.uploadAvatar);
router.delete('/auth/me',            authRequired, auth.deleteAccount);
router.get ('/auth/verify-email',    auth.verifyEmail);                     // GET /api/auth/verify-email?token=...
router.post('/auth/resend-verification', authRequired, auth.resendVerification);

// PUBLIC ITEMS
router.get('/stats',           items.getStats);
router.get('/categories',      items.getCategories);
// Static /items/* routes MUST come before /items/:id to avoid param capture.
// BUG FIX: /items/nearby was previously registered after /items/:id (line 75),
// causing GET /items/nearby to be intercepted with id='nearby'. Moved here.
router.get('/items/latest',    items.getLatest);
router.get('/items/map',       items.getMapPoints);
router.get('/items/nearby',    social.getNearby);
router.get('/items',           items.getItems);
router.get('/items/:id',       authOptional, items.getItem);

// PROTECTED ITEMS
router.post  ('/items',             authRequired, upload.array('images', 5), compressImages, items.createItem);
router.put   ('/items/:id',         authRequired, items.updateItem);
router.delete('/items/:id',         authRequired, items.deleteItem);
router.patch ('/items/:id/status',  authRequired, items.closeItem);
router.get   ('/my-items',          authRequired, items.myItems);
router.post  ('/items/:id/favorite',authRequired, items.toggleFav);
router.get   ('/favorites',         authRequired, items.myFavorites);

// ПУБЛИЧНЫЙ ПРОФИЛЬ (/api/users/:id)
router.get('/users/:id', asyncHandler(async (req, res) => {
  const userId = Number(req.params.id);
  if (!userId) return res.status(400).json({ error: 'Некорректный ID.' });
  const user = await Users.publicProfile(userId);
  if (!user) return res.status(404).json({ error: 'Пользователь не найден.' });
  const [userItems, ratings] = await Promise.all([
    ItemsModel.listByOwner(userId),
    Ratings.forUser(userId),
  ]);
  // Только публичные активные объявления
  const publicItems = userItems.filter(i =>
    i.moderation_status === 'approved' && i.status === 'open'
  );
  res.json({ user, items: publicItems, ratings });
}));

// (GET /items/nearby moved above /items/:id — see line above)

// MATCHES
router.get  ('/matches',                 authRequired, social.getMyMatches);
router.patch('/matches/:id',             authRequired, social.updateMatchStatus);
router.post ('/matches/rebuild/:itemId', authRequired, social.rebuildMatches);

// MESSAGES
router.get ('/messages',         authRequired, social.getThreads);
router.get ('/messages/:userId', authRequired, social.getConversation);
router.post('/messages',         authRequired, social.sendMessage);
router.get ('/unread',           authRequired, social.unreadCounts);

// NOTIFICATIONS
router.get  ('/notifications',           authRequired, social.getNotifications);
router.patch('/notifications/all/read',  authRequired, social.markAllNotifsRead);
router.patch('/notifications/:id/read',  authRequired, social.markNotifRead);

// CLAIMS
router.post('/claims',     authRequired, social.createClaim);
router.get ('/my-claims',  authRequired, social.getMyClaims);

// REPORTS — объявления
router.post('/items/:id/report', authRequired, social.reportItem);

// REPORTS — пользователи
router.post('/users/:id/report', authRequired, social.reportUser);

// SUBSCRIPTIONS
router.get   ('/subscriptions',     authRequired, social.getSubscriptions);
router.post  ('/subscriptions',     authRequired, social.createSubscription);
router.delete('/subscriptions/:id', authRequired, social.deleteSubscription);

// RATINGS
router.post('/ratings',          authRequired, social.giveRating);
router.get ('/ratings/:userId',  social.getUserRatings);

// GAMIFICATION
router.get ('/game/me',           authRequired, game.getMyProfile);
router.get ('/game/user/:id',     game.getUserProfile);
router.get ('/game/leaderboard',  game.getLeaderboardCtrl);
router.get ('/push/key',          game.getVapidKey);
router.post('/push/subscribe',    authRequired, game.subscribePush);
router.post('/push/unsubscribe',  authRequired, game.unsubscribePush);

// ADMIN
router.use('/admin', authRequired, adminRequired);
router.get   ('/admin/stats',                 admin.getStats);
router.get   ('/admin/pending',               admin.getPending);
router.get   ('/admin/items',                 admin.getAllItems);
// BUG FIX: specific static paths must come BEFORE /admin/items/:id to avoid param capture
router.post  ('/admin/items/bulk',            admin.bulkAction);          // Массовые действия
router.get   ('/admin/items/export.csv',      admin.exportItemsCsv);      // CSV объявлений
router.patch ('/admin/items/:id/moderate',    admin.moderate);
router.delete('/admin/items/:id',             admin.adminDeleteItem);
router.get   ('/admin/users',                 admin.getUsers);
// BUG FIX: same — export.csv before /:id
router.get   ('/admin/users/export.csv',      admin.exportUsersCsv);      // CSV пользователей
router.patch ('/admin/users/:id/ban',         admin.banUser);
router.patch ('/admin/users/:id/role',        admin.setRole);
router.get   ('/admin/claims',                admin.getClaims);
router.patch ('/admin/claims/:id',            admin.processClaim);
router.get   ('/admin/reports',               admin.getReports);
router.patch ('/admin/reports/:id',           admin.processReport);
router.get   ('/admin/user-reports',          admin.getUserReports);       // Жалобы на юзеров
router.patch ('/admin/user-reports/:id',      admin.processUserReport);

module.exports = router;
