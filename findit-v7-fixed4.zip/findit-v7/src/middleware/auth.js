const jwt    = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config/env');
const { get } = require('../config/database');

function hashPassword(pw)         { return bcrypt.hashSync(pw, 10); }
function verifyPassword(pw, hash) { return bcrypt.compareSync(pw, hash); }
function createToken(user)        { return jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN }); }
function verifyToken(token) {
  try { return jwt.verify(token, JWT_SECRET); }
  catch { return null; }
}

// BUG FIX: Express middleware must be (req, res, next) — 3 args.
// Mode 'optional' was passed as 4th arg but Express never calls it that way.
// Solution: factory function that returns a properly shaped middleware.
function authMiddleware(mode = 'required') {
  return async function (req, res, next) {
    try {
      const header  = req.headers.authorization || '';
      const token   = header.startsWith('Bearer ') ? header.slice(7) : null;
      const payload = verifyToken(token);
      if (!payload?.id) {
        if (mode === 'optional') return next();
        return res.status(401).json({ error: 'Требуется авторизация.' });
      }
      const user = await get('SELECT * FROM users WHERE id = ?', [payload.id]);
      if (!user) {
        if (mode === 'optional') return next();
        return res.status(401).json({ error: 'Пользователь не найден.' });
      }
      if (user.is_banned) return res.status(403).json({ error: 'Аккаунт заблокирован.' });
      req.user = user;
      next();
    } catch (e) { next(e); }
  };
}

// Named exports kept for backward compat with existing controllers
const authRequired = authMiddleware('required');
const authOptional = authMiddleware('optional');

function adminRequired(req, res, next) {
  if (req.user?.role !== 'admin')
    return res.status(403).json({ error: 'Только для администратора.' });
  next();
}

module.exports = { hashPassword, verifyPassword, createToken, verifyToken, authRequired, authOptional, adminRequired };
