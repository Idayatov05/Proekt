function notFound(req, res) {
  if (req.path.startsWith('/api/'))
    return res.status(404).json({ error: `Маршрут ${req.method} ${req.path} не найден.` });
  res.status(404).send('404 Not Found');
}

function errorHandler(err, req, res, _next) {
  console.error('[ERROR]', err.message);
  const status = err.status || 500;
  res.status(status).json({ error: err.message || 'Внутренняя ошибка сервера.' });
}

module.exports = { notFound, errorHandler };
