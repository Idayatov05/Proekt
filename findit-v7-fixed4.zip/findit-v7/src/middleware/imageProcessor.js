/**
 * Middleware: сжимает загруженное изображение до max 1200px
 * и конвертирует в WebP (80% качество).
 * Экономит место и ускоряет загрузку страниц в ~3-5 раз.
 */
const path = require('path');
const fs   = require('fs');

let sharp;
try { sharp = require('sharp'); } catch { /* sharp не установлен — сжатие пропускаем */ }

async function compressImage(req, res, next) {
  if (!req.file || !sharp) return next();

  const originalPath = req.file.path;
  const webpName     = req.file.filename.replace(/\.[^.]+$/, '') + '.webp';
  const webpPath     = path.join(path.dirname(originalPath), webpName);

  try {
    await sharp(originalPath)
      .resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 80 })
      .toFile(webpPath);

    // Удаляем оригинал, заменяем данные в req.file
    fs.unlink(originalPath, () => {});
    req.file.filename = webpName;
    req.file.path     = webpPath;
    req.file.mimetype = 'image/webp';
  } catch (err) {
    // Если Sharp упал — продолжаем с оригиналом, не ломаем запрос
    console.error('[imageProcessor] Sharp error:', err.message);
  }

  next();
}


/**
 * Middleware для множественной загрузки (upload.array).
 * Сжимает каждый файл в req.files.
 */
async function compressImages(req, res, next) {
  if (!req.files || !req.files.length || !sharp) return next();
  try {
    for (let i = 0; i < req.files.length; i++) {
      const f = req.files[i];
      const webpName = f.filename.replace(/\.[^.]+$/, '') + '.webp';
      const webpPath = path.join(path.dirname(f.path), webpName);
      await sharp(f.path)
        .resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true })
        .webp({ quality: 80 })
        .toFile(webpPath);
      fs.unlink(f.path, () => {});
      f.filename = webpName;
      f.path     = webpPath;
      f.mimetype = 'image/webp';
    }
  } catch (err) {
    console.error('[imageProcessor] compressImages error:', err.message);
  }
  next();
}

module.exports = { compressImage, compressImages };
