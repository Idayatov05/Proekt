const asyncHandler = require('../utils/asyncHandler');
const { getTotalPoints, getPointsHistory, getUserBadges, getLeaderboard, getLevel } = require('../services/gamification');
const { saveSubscription, VAPID_PUBLIC_KEY } = require('../services/pushService');
const { get } = require('../config/database');

// ─── Профиль геймификации текущего юзера ─────────────────
const getMyProfile = asyncHandler(async (req, res) => {
  const [points, history, badges] = await Promise.all([
    getTotalPoints(req.user.id),
    getPointsHistory(req.user.id),
    getUserBadges(req.user.id),
  ]);
  const level = getLevel(points);
  res.json({ points, level, history, badges });
});

// ─── Профиль любого пользователя ─────────────────────────
const getUserProfile = asyncHandler(async (req, res) => {
  const userId = Number(req.params.id);
  const user   = await get('SELECT id,name,avatar,rating,created_at FROM users WHERE id=?', [userId]);
  if (!user) return res.status(404).json({ error: 'Пользователь не найден.' });
  const [points, badges] = await Promise.all([
    getTotalPoints(userId),
    getUserBadges(userId),
  ]);
  res.json({ user, points, level: getLevel(points), badges });
});

// ─── Таблица лидеров ─────────────────────────────────────
const getLeaderboardCtrl = asyncHandler(async (req, res) => {
  const board = await getLeaderboard(20);
  const enriched = board.map((u, i) => ({ ...u, rank: i + 1, level: getLevel(u.total_points) }));
  res.json({ leaderboard: enriched });
});

// ─── Push: получить публичный VAPID ключ ─────────────────
const getVapidKey = asyncHandler(async (req, res) => {
  res.json({ publicKey: VAPID_PUBLIC_KEY });
});

// ─── Push: сохранить подписку ────────────────────────────
const subscribePush = asyncHandler(async (req, res) => {
  const { subscription } = req.body;
  if (!subscription?.endpoint) return res.status(400).json({ error: 'Нет подписки.' });
  await saveSubscription(req.user.id, subscription);
  res.json({ ok: true });
});

// ─── Push: отписаться ────────────────────────────────────
const unsubscribePush = asyncHandler(async (req, res) => {
  const { removeSubscription } = require('../services/pushService');
  const { endpoint } = req.body;
  if (endpoint) await removeSubscription(endpoint);
  res.json({ ok: true });
});

module.exports = { getMyProfile, getUserProfile, getLeaderboardCtrl, getVapidKey, subscribePush, unsubscribePush };
