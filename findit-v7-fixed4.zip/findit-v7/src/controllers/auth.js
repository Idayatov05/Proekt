const asyncHandler = require('../utils/asyncHandler');
const crypto       = require('crypto');
const nodemailer   = require('nodemailer');
const { hashPassword, verifyPassword, createToken } = require('../middleware/auth');
const { Users, Items } = require('../models');
const env = require('../config/env');

// ── Email transporter ────────────────────────────────────
function getTransporter() {
  if (!env.SMTP_HOST) return null;
  return nodemailer.createTransport({
    host: env.SMTP_HOST, port: env.SMTP_PORT || 587,
    auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
  });
}

async function sendVerificationEmail(user, token) {
  const transport = getTransporter();
  if (!transport) {
    console.log(`[email-verify] token для ${user.email}: ${token}`);
    return;
  }
  const url = `${env.APP_URL || 'http://localhost:3000'}/verify-email.html?token=${token}`;
  await transport.sendMail({
    from: `"FindIt" <${env.SMTP_USER}>`,
    to: user.email,
    subject: 'Подтвердите email — FindIt',
    html: `<p>Здравствуйте, ${user.name}!</p>
           <p>Нажмите кнопку для подтверждения адреса:</p>
           <a href="${url}" style="background:#4f46e5;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none">Подтвердить email</a>
           <p>Или перейдите по ссылке: ${url}</p>`,
  });
}

// ── Проверка надёжности пароля ────────────────────────────
const WEAK_PASSWORDS = new Set([
  '123456','123456789','12345678','password','qwerty','abc123',
  '111111','123123','1234567','sunshine','princess','welcome',
  'shadow','monkey','dragon','master','letmein','login','hello',
  'qwerty123','iloveyou','admin','pass','test','1q2w3e',
]);

function validatePassword(password) {
  if (password.length < 8)
    return 'Пароль минимум 8 символов.';
  if (WEAK_PASSWORDS.has(password.toLowerCase()))
    return 'Пароль слишком простой. Придумайте более надёжный.';
  if (!/[0-9]/.test(password) && !/[^a-zA-Zа-яА-Я0-9]/.test(password))
    return 'Пароль должен содержать хотя бы одну цифру или спецсимвол.';
  return null;
}

// ── Email transport ───────────────────────────────────────
let _mailer = null;
function getMailer() {
  if (_mailer) return _mailer;
  if (env.SMTP_HOST) {
    _mailer = nodemailer.createTransport({
      host: env.SMTP_HOST, port: env.SMTP_PORT, secure: env.SMTP_SECURE,
      auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
    });
  }
  return _mailer;
}

async function sendResetEmail(to, resetLink) {
  const mailer = getMailer();
  if (mailer) {
    await mailer.sendMail({
      from: env.EMAIL_FROM, to,
      subject: 'FindIt — сброс пароля',
      html: `<div style="font-family:sans-serif;max-width:480px;margin:auto">
        <h2 style="color:#6366f1">🔑 Сброс пароля FindIt</h2>
        <p>Перейдите по ссылке — она действует <strong>1 час</strong>.</p>
        <p><a href="${resetLink}" style="display:inline-block;padding:12px 24px;background:#6366f1;color:#fff;border-radius:8px;text-decoration:none;font-weight:600">Сбросить пароль</a></p>
        <p style="color:#888;font-size:.85rem">Если это были не вы — просто проигнорируйте письмо.</p>
      </div>`,
      text: `Ссылка для сброса пароля (1 час): ${resetLink}`,
    });
    return { sent: true };
  } else {
    console.log(`\n🔑 СБРОС ПАРОЛЯ для ${to}:\n${resetLink}\n`);
    return { sent: false, resetLink };
  }
}

const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Заполните имя, email и пароль.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: 'Некорректный email.' });
  const pwdError = validatePassword(password);
  if (pwdError) return res.status(400).json({ error: pwdError });
  if (await Users.findByEmail(email))
    return res.status(409).json({ error: 'Пользователь с таким email уже существует.' });
  const user  = await Users.create({ name, email, passwordHash: hashPassword(password) });
  // Отправляем письмо подтверждения email
  const verifyToken = crypto.randomBytes(32).toString('hex');
  await Users.setEmailVerifyToken(user.id, verifyToken);
  sendVerificationEmail(user, verifyToken).catch(e => console.error('[verify-email]', e.message));
  const token = createToken(user);
  res.status(201).json({ token, user });
});

const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Введите email и пароль.' });
  const user = await Users.findByEmail(email);
  if (!user || !verifyPassword(password, user.password_hash))
    return res.status(401).json({ error: 'Неверный email или пароль.' });
  if (user.is_banned)
    return res.status(403).json({ error: 'Аккаунт заблокирован.' });
  const token = createToken(user);
  res.json({ token, user: await Users.findById(user.id) });
});

const me = asyncHandler(async (req, res) => {
  res.json({ user: await Users.findById(req.user.id) });
});

const updateProfile = asyncHandler(async (req, res) => {
  await Users.update(req.user.id, req.body);
  res.json({ user: await Users.findById(req.user.id) });
});

const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Введите email.' });
  const user = await Users.findByEmail(email);
  if (!user) return res.json({ ok: true });
  const token   = crypto.randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + 60 * 60 * 1000).toISOString();
  await Users.setResetToken(user.id, token, expires);
  const resetLink = `${req.protocol}://${req.get('host')}/auth.html#reset?token=${token}`;
  const result    = await sendResetEmail(user.email, resetLink);
  res.json({ ok: true, ...(result.resetLink ? { resetLink: result.resetLink } : {}) });
});

const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  if (!token || !password)
    return res.status(400).json({ error: 'Токен и новый пароль обязательны.' });
  const pwdError = validatePassword(password);
  if (pwdError) return res.status(400).json({ error: pwdError });
  const user = await Users.findByResetToken(token);
  if (!user) return res.status(400).json({ error: 'Ссылка недействительна или срок истёк.' });
  await Users.setPassword(user.id, hashPassword(password));
  await Users.clearResetToken(user.id);
  const freshUser = await Users.findById(user.id);
  res.json({ ok: true, token: createToken(freshUser), user: freshUser });
});

// 🔴 #2 — Смена пароля прямо из профиля (требует текущий пароль)
const changePassword = asyncHandler(async (req, res) => {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password)
    return res.status(400).json({ error: 'Введите текущий и новый пароль.' });
  const pwdError = validatePassword(new_password);
  if (pwdError) return res.status(400).json({ error: pwdError });
  const row = await Users.findByEmail(req.user.email);
  if (!row || !verifyPassword(current_password, row.password_hash))
    return res.status(401).json({ error: 'Текущий пароль неверный.' });
  await Users.setPassword(req.user.id, hashPassword(new_password));
  res.json({ ok: true });
});

// 🔴 Удаление аккаунта (GDPR)
const deleteAccount = asyncHandler(async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Введите пароль для подтверждения.' });
  const row = await Users.findByEmail(req.user.email);
  if (!row || !verifyPassword(password, row.password_hash))
    return res.status(401).json({ error: 'Неверный пароль.' });
  await Users.anonymize(req.user.id);
  res.json({ ok: true, message: 'Аккаунт удалён.' });
});

// 🔴 #3 — Загрузка аватара
const uploadAvatar = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не загружен.' });
  const url = `/uploads/${req.file.filename}`;
  await Users.update(req.user.id, { avatar: url });
  res.json({ ok: true, user: await Users.findById(req.user.id) });
});

// Подтверждение email по ссылке
const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.query;
  if (!token) return res.status(400).json({ error: 'Токен обязателен.' });
  const user = await Users.findByEmailVerifyToken(token);
  if (!user) return res.status(400).json({ error: 'Неверный или устаревший токен.' });
  await Users.verifyEmail(user.id);
  res.json({ ok: true, message: 'Email подтверждён!' });
});

// Повторная отправка письма верификации
const resendVerification = asyncHandler(async (req, res) => {
  const user = await Users.findById(req.user.id);
  if (user.email_verified) return res.status(400).json({ error: 'Email уже подтверждён.' });
  const verifyToken = crypto.randomBytes(32).toString('hex');
  await Users.setEmailVerifyToken(user.id, verifyToken);
  await sendVerificationEmail(user, verifyToken);
  res.json({ ok: true, message: 'Письмо отправлено.' });
});

module.exports = { register, login, me, updateProfile, forgotPassword, resetPassword, changePassword, uploadAvatar, deleteAccount, verifyEmail, resendVerification };
