const asyncHandler = require('../utils/asyncHandler');
const { Items, ItemPhotos, Favorites, Notifications, Subscriptions } = require('../models');
const { buildMatchesForItem } = require('../services/matchingService');
const { awardPoints } = require('../services/gamification');

const getStats     = asyncHandler(async (req, res) => res.json({ stats: await Items.stats() }));
const getLatest    = asyncHandler(async (req, res) => res.json({ items: await Items.listLatest(8) }));
const getMapPoints = asyncHandler(async (req, res) => res.json({ points: await Items.listMapPoints() }));
const getCategories = asyncHandler(async (req, res) => {
  const { Categories } = require('../models');
  res.json({ categories: await Categories.list() });
});

const getItems = asyncHandler(async (req, res) => {
  const { page = 1, limit = 12, sort = 'newest' } = req.query;
  const lim    = Math.min(Math.max(Number(limit), 1), 50);
  const offset = (Number(page) - 1) * lim;
  const { rows: items, total } = await Items.list({ status: 'open', ...req.query, sort, limit: lim, offset });
  const pages = Math.ceil(total / lim) || 1;
  res.json({ items, total, pages, page: Number(page) });
});

const getItem = asyncHandler(async (req, res) => {
  const item = await Items.findById(Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Объявление не найдено.' });
  await Items.incViews(item.id);
  let isFav = false;
  if (req.user) isFav = !!(await Favorites.check(req.user.id, item.id));
  res.json({ item, isFav });
});

const createItem = asyncHandler(async (req, res) => {
  const { type, title, description, category_id, brand, color,
          location_text, latitude, longitude, event_date,
          serial_number, reward, contact_info } = req.body;

  if (!type || !title || !description || !category_id || !location_text || !event_date)
    return res.status(400).json({ error: 'Заполните обязательные поля.' });
  if (!['lost','found'].includes(type))
    return res.status(400).json({ error: 'Тип: lost или found.' });

  // Защита от дублирования: то же название в течение 24 часов
  const duplicate = await Items.findDuplicate(req.user.id, title.trim());
  if (duplicate)
    return res.status(409).json({ error: 'Похожее объявление уже было создано вами сегодня. Подождите 24 часа или отредактируйте существующее.' });

  const moderation_status = req.user.role === 'admin' ? 'approved' : 'pending';

  // FIX-2: isFirst was evaluated AFTER Items.create(), so listByOwner always
  // returned length >= 1 → badge never awarded. Must check before inserting.
  const existingItems = await Items.listByOwner(req.user.id);
  const isFirst = existingItems.length === 0;

  // Collect uploaded photo URLs (multiple via req.files, single legacy via req.file)
  const photoFiles = req.files?.length
    ? req.files.map(f => `/uploads/${f.filename}`)
    : req.file
      ? [`/uploads/${req.file.filename}`]
      : [];

  const item = await Items.create({
    owner_id: req.user.id, type, title: title.trim(), description: description.trim(),
    category_id, brand, color, location_text: location_text.trim(),
    latitude, longitude, event_date, serial_number, reward, contact_info,
    image_url: photoFiles[0] || null,   // первое фото — для обратной совместимости
    moderation_status,
  });

  // Сохраняем дополнительные фото в item_photos
  if (photoFiles.length) {
    await ItemPhotos.addAll(item.id, photoFiles);
    item.photos = photoFiles;
  } else {
    item.photos = [];
  }

  // Очки за создание объявления
  await awardPoints(req.user.id, 'create_item', item.id);
  if (isFirst) await awardPoints(req.user.id, 'first_item', item.id);

  if (moderation_status === 'approved') {
    await awardPoints(req.user.id, 'item_approved', item.id);
    await buildMatchesForItem(item.id);
    // Уведомить подписчиков
    try {
      const category = item.category_slug || null;
      const subs = await Subscriptions.findMatching(category, item.location_text, item.type);
      for (const sub of subs) {
        if (sub.user_id === req.user.id) continue; // не уведомлять автора
        await Notifications.create(sub.user_id, 'info', '🔔 Новое объявление по вашей подписке',
          `${item.type === 'lost' ? '🔍 Потеряно' : '📦 Найдено'}: «${item.title}» — ${item.location_text}`,
          `/item.html?id=${item.id}`);
      }
    } catch { /* не ломаем создание из-за подписок */ }
  } else {
    await Notifications.create(req.user.id, 'info', '📋 Объявление на модерации',
      `Ваше объявление «${item.title}» будет опубликовано после проверки.`);
  }

  res.status(201).json({ item });
});

const updateItem = asyncHandler(async (req, res) => {
  const item = await Items.findById(Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Не найдено.' });
  if (item.owner_id !== req.user.id && req.user.role !== 'admin')
    return res.status(403).json({ error: 'Нет доступа.' });
  res.json({ item: await Items.update(item.id, req.body) });
});

const deleteItem = asyncHandler(async (req, res) => {
  const item = await Items.findById(Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Не найдено.' });
  if (item.owner_id !== req.user.id && req.user.role !== 'admin')
    return res.status(403).json({ error: 'Нет доступа.' });
  await Items.delete(item.id);
  res.json({ ok: true });
});

const myItems    = asyncHandler(async (req, res) => res.json({ items: await Items.listByOwner(req.user.id) }));
const toggleFav  = asyncHandler(async (req, res) => res.json({ added: await Favorites.toggle(req.user.id, Number(req.params.id)) }));
const myFavorites= asyncHandler(async (req, res) => res.json({ items: await Favorites.list(req.user.id) }));

const closeItem = asyncHandler(async (req, res) => {
  const item = await Items.findById(Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Не найдено.' });
  if (item.owner_id !== req.user.id && req.user.role !== 'admin')
    return res.status(403).json({ error: 'Нет доступа.' });
  const newStatus = req.body.status || 'closed';
  await Items.setStatus(item.id, newStatus);
  // Очки за возврат
  if (newStatus === 'returned') await awardPoints(req.user.id, 'item_returned', item.id);
  res.json({ ok: true });
});

module.exports = { getStats, getCategories, getLatest, getMapPoints, getItems, getItem,
  createItem, updateItem, deleteItem, myItems, toggleFav, myFavorites, closeItem };
