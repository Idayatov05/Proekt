const asyncHandler = require('../utils/asyncHandler');
const { Items, Users, Claims, Notifications, Reports, Subscriptions, UserReports } = require('../models');
const { buildMatchesForItem } = require('../services/matchingService');
const { awardPoints } = require('../services/gamification');
const { notifyApproved } = require('../services/pushService');
const emailService = require('../services/emailService');
const { run, all } = require('../config/database');

// ── Расширенная аналитика ────────────────────────────────
const getStats = asyncHandler(async (req, res) => {
  const [basic, daily, returns, registrations] = await Promise.all([
    Items.stats(),
    // Новые объявления за последние 30 дней
    all(`SELECT DATE(created_at) AS day, COUNT(*) AS count
         FROM items WHERE created_at > datetime('now','-30 days')
         GROUP BY day ORDER BY day ASC`),
    // Возвраты за 30 дней
    all(`SELECT DATE(updated_at) AS day, COUNT(*) AS count
         FROM items WHERE status='returned' AND updated_at > datetime('now','-30 days')
         GROUP BY day ORDER BY day ASC`),
    // Регистрации за 30 дней
    all(`SELECT DATE(created_at) AS day, COUNT(*) AS count
         FROM users WHERE created_at > datetime('now','-30 days')
         GROUP BY day ORDER BY day ASC`),
  ]);
  res.json({ stats: basic, charts: { daily, returns, registrations } });
});

// ── CSV экспорт объявлений ───────────────────────────────
const exportItemsCsv = asyncHandler(async (req, res) => {
  const rows = await all(`
    SELECT items.id, items.type, items.title, items.status, items.moderation_status,
           items.location_text, items.created_at, u.name AS owner, u.email AS owner_email
    FROM items LEFT JOIN users u ON u.id = items.owner_id
    ORDER BY items.created_at DESC`);

  const header = ['ID','Тип','Название','Статус','Модерация','Место','Дата','Владелец','Email'];
  const escape = v => `"${String(v ?? '').replace(/"/g,'""')}"`;
  const csv = [header.map(escape).join(',')]
    .concat(rows.map(r => [r.id,r.type,r.title,r.status,r.moderation_status,
      r.location_text,r.created_at,r.owner,r.owner_email].map(escape).join(',')))
    .join('\r\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="items.csv"');
  res.send('\uFEFF' + csv); // BOM для корректного отображения в Excel
});

// ── CSV экспорт пользователей ────────────────────────────
const exportUsersCsv = asyncHandler(async (req, res) => {
  const rows = await Users.list();
  const header = ['ID','Имя','Email','Роль','Рейтинг','Очки','Заблокирован','Дата регистрации'];
  const escape = v => `"${String(v ?? '').replace(/"/g,'""')}"`;
  const csv = [header.map(escape).join(',')]
    .concat(rows.map(r => [r.id,r.name,r.email,r.role,r.rating,r.total_points,
      r.is_banned ? 'Да' : 'Нет', r.created_at].map(escape).join(',')))
    .join('\r\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="users.csv"');
  res.send('\uFEFF' + csv);
});

// ── Массовые действия ────────────────────────────────────
const bulkAction = asyncHandler(async (req, res) => {
  const { ids, action } = req.body; // action: 'approve' | 'reject' | 'delete'
  if (!Array.isArray(ids) || !ids.length)
    return res.status(400).json({ error: 'Укажите массив ids.' });
  if (!['approve','reject','delete'].includes(action))
    return res.status(400).json({ error: 'action: approve | reject | delete' });

  let processed = 0;
  for (const id of ids.map(Number)) {
    const item = await Items.findById(id);
    if (!item) continue;
    if (action === 'approve') {
      await Items.moderate(id, 'approved', null);
      await Notifications.create(item.owner_id, 'info', '✅ Объявление одобрено',
        `Ваше объявление «${item.title}» опубликовано.`);
      buildMatchesForItem(id).catch(() => {});
    } else if (action === 'reject') {
      await Items.moderate(id, 'rejected', 'Массовое отклонение');
      await Notifications.create(item.owner_id, 'warn', '❌ Объявление отклонено',
        `«${item.title}» отклонено администратором.`);
    } else if (action === 'delete') {
      if (item.owner_id) await Notifications.create(item.owner_id, 'warn', '🗑 Объявление удалено',
        `Ваше объявление «${item.title}» удалено администратором.`);
      await Items.delete(id);
    }
    processed++;
  }
  res.json({ ok: true, processed });
});

// ── Жалобы на пользователей ─────────────────────────────
const getUserReports = asyncHandler(async (req, res) => {
  const status = req.query.status || 'pending';
  res.json({ reports: await UserReports.list(status) });
});

const processUserReport = asyncHandler(async (req, res) => {
  const { action } = req.body; // 'reviewed' | 'dismissed' | 'ban'
  const reportId = Number(req.params.id);
  if (!['reviewed','dismissed','ban'].includes(action))
    return res.status(400).json({ error: 'action: reviewed | dismissed | ban' });

  if (action === 'ban') {
    const reports = await UserReports.list('pending');
    const report = reports.find(r => r.id === reportId);
    if (report) await Users.ban(report.target_id, true);
  }
  await UserReports.setStatus(reportId, action === 'ban' ? 'reviewed' : action);
  res.json({ ok: true });
});
const getPending = asyncHandler(async (req, res) => res.json({ items: await Items.listPending() }));
const getAllItems = asyncHandler(async (req, res) => {
  // FIX-3: { moderation: null, ...req.query } is wrong — when req.query.moderation
  // is absent, spread sets the key to undefined which overrides null, causing
  // Items.list to fall back to default 'approved'. Admin would never see
  // pending/rejected items. Fix: build filters object cleanly.
  const filters = { ...req.query, limit: 200 };
  if (!filters.moderation) filters.moderation = null; // null = no moderation filter
  const { rows: items } = await Items.list(filters);
  res.json({ items });
});

const moderate = asyncHandler(async (req, res) => {
  const { action, reason } = req.body;
  const id   = Number(req.params.id);
  const item = await Items.findById(id);
  if (!item) return res.status(404).json({ error: 'Не найдено.' });

  if (action === 'approve') {
    await Items.moderate(id, 'approved', null);
    await awardPoints(item.owner_id, 'item_approved', id);
    await buildMatchesForItem(id);
    await Notifications.create(item.owner_id, 'info', '✅ Объявление одобрено',
      `Ваше объявление «${item.title}» опубликовано.`);
    notifyApproved(item.owner_id, item.title).catch(() => {});
    // Уведомить подписчиков
    Subscriptions.findMatching(item.category_slug, item.location_text, item.type)
      .then(subs => subs.forEach(sub => {
        if (sub.user_id === item.owner_id) return;
        Notifications.create(sub.user_id, 'info', '🔔 Новое объявление по подписке',
          `${item.type==='lost'?'🔍 Потеряно':'📦 Найдено'}: «${item.title}» — ${item.location_text}`,
          `/item.html?id=${item.id}`).catch(() => {});
      })).catch(() => {});
  } else if (action === 'reject') {    await Items.moderate(id, 'rejected', reason);
    await Notifications.create(item.owner_id, 'warn', '❌ Объявление отклонено',
      `«${item.title}» отклонено.${reason ? ' Причина: ' + reason : ''}`);
  } else if (action === 'return') {
    await Items.setStatus(id, 'returned');
    await awardPoints(item.owner_id, 'item_returned', id);
    await Notifications.create(item.owner_id, 'info', '🎉 Предмет возвращён!',
      `Предмет «${item.title}» отмечен как возвращённый!`);
  } else {
    return res.status(400).json({ error: 'Неизвестное действие.' });
  }
  res.json({ ok: true });
});

const adminDeleteItem = asyncHandler(async (req, res) => {
  const item = await Items.findById(Number(req.params.id));
  if (!item) return res.status(404).json({ error: 'Не найдено.' });
  if (item.owner_id)
    await Notifications.create(item.owner_id, 'warn', '🗑 Объявление удалено',
      `Ваше объявление «${item.title}» удалено администратором.`);
  await Items.delete(item.id);
  res.json({ ok: true });
});

const getUsers = asyncHandler(async (req, res) => res.json({ users: await Users.list() }));
const banUser  = asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: 'Нельзя заблокировать себя.' });
  await Users.ban(Number(req.params.id), req.body.ban);
  res.json({ ok: true });
});
const setRole = asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id) return res.status(400).json({ error: 'Нельзя изменить свою роль.' });
  if (!['user','admin'].includes(req.body.role)) return res.status(400).json({ error: 'Роль: user или admin.' });
  await Users.setRole(Number(req.params.id), req.body.role);
  res.json({ ok: true });
});

const getClaims = asyncHandler(async (req, res) => res.json({ claims: await Claims.list() }));
const processClaim = asyncHandler(async (req, res) => {
  const { action, note } = req.body;
  const claim = await Claims.findById(Number(req.params.id));
  if (!claim) return res.status(404).json({ error: 'Не найдена.' });
  if (claim.status !== 'pending') return res.status(409).json({ error: 'Уже обработана.' });

  if (action === 'approve') {
    await Claims.setStatus(claim.id, 'approved', note);
    await run('UPDATE items SET status=? WHERE id=?', ['returned', claim.item_id]);
    await awardPoints(claim.requester_id, 'claim_approved', claim.item_id);
    await Notifications.create(claim.requester_id, 'info', '✅ Заявка одобрена',
      `Ваша заявка на «${claim.item_title}» одобрена.`);
    // Email-уведомление заявителю
    Users.findById(claim.requester_id).then(u => {
      if (u) emailService.notifyClaimStatus(u, claim, { id: claim.item_id, title: claim.item_title }, 'approved', note).catch(() => {});
    }).catch(() => {});
    if (claim.owner_id) {
      await awardPoints(claim.owner_id, 'item_returned', claim.item_id);
      await Notifications.create(claim.owner_id, 'info', '🎉 Нашёлся владелец',
        `Для «${claim.item_title}» подтверждена заявка владельца.`);
    }
  } else if (action === 'reject') {
    await Claims.setStatus(claim.id, 'rejected', note);
    await Notifications.create(claim.requester_id, 'warn', '❌ Заявка отклонена',
      `Ваша заявка на «${claim.item_title}» отклонена.${note ? ' ' + note : ''}`);
    // Email-уведомление заявителю
    Users.findById(claim.requester_id).then(u => {
      if (u) emailService.notifyClaimStatus(u, claim, { id: claim.item_id, title: claim.item_title }, 'rejected', note).catch(() => {});
    }).catch(() => {});
  } else {
    return res.status(400).json({ error: 'action: approve или reject.' });
  }
  res.json({ ok: true });
});

const getReports = asyncHandler(async (req, res) => {
  const status = req.query.status || 'pending';
  res.json({ reports: await Reports.list(status) });
});

const processReport = asyncHandler(async (req, res) => {
  const { action } = req.body; // 'reviewed' | 'dismissed'
  if (!['reviewed','dismissed'].includes(action))
    return res.status(400).json({ error: 'action: reviewed или dismissed.' });
  await Reports.setStatus(Number(req.params.id), action);
  res.json({ ok: true });
});

module.exports = { getStats, getPending, getAllItems, moderate, adminDeleteItem,
  getUsers, banUser, setRole, getClaims, processClaim, getReports, processReport,
  exportItemsCsv, exportUsersCsv, bulkAction, getUserReports, processUserReport };
