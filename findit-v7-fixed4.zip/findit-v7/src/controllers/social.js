const asyncHandler = require('../utils/asyncHandler');
const { Messages, Notifications, Claims, Ratings, Items, Matches, Reports, Subscriptions, UserReports, Users } = require('../models');
const { buildMatchesForItem } = require('../services/matchingService');
const { awardPoints } = require('../services/gamification');
const { notifyMessage } = require('../services/pushService');
const emailService = require('../services/emailService');

const getThreads = asyncHandler(async (req, res) => res.json({ threads: await Messages.threads(req.user.id) }));

const getConversation = asyncHandler(async (req, res) => {
  const other = Number(req.params.userId);
  await Messages.markRead(other, req.user.id);
  res.json({ messages: await Messages.conversation(req.user.id, other) });
});

const sendMessage = asyncHandler(async (req, res) => {
  const { receiver_id, body, item_id } = req.body;
  if (!receiver_id || !body?.trim()) return res.status(400).json({ error: 'Укажите получателя и текст.' });
  if (Number(receiver_id) === req.user.id) return res.status(400).json({ error: 'Нельзя написать себе.' });
  await Messages.send(req.user.id, Number(receiver_id), body.trim(), item_id);
  await Notifications.create(Number(receiver_id), 'message', '💬 Новое сообщение',
    `${req.user.name} написал вам.`, `/dashboard.html`);
  await awardPoints(req.user.id, 'send_message');
  notifyMessage(Number(receiver_id), req.user.name).catch(() => {});
  // Email-уведомление получателю
  Users.findById(Number(receiver_id)).then(receiver => {
    if (receiver) emailService.notifyNewMessage(receiver, req.user, body.trim()).catch(() => {});
  }).catch(() => {});
  res.status(201).json({ ok: true });
});

const unreadCounts = asyncHandler(async (req, res) => {
  const msgs  = await Messages.unreadCount(req.user.id);
  const notif = await Notifications.unreadCount(req.user.id);
  res.json({ messages: msgs.n, notifications: notif.n });
});

const getNotifications = asyncHandler(async (req, res) =>
  res.json({ notifications: await Notifications.list(req.user.id) }));

// BUG FIX: split into two separate handlers so routes can be registered separately
// (avoids /notifications/all/read clashing with /notifications/:id/read)
const markNotifRead = asyncHandler(async (req, res) => {
  await Notifications.markRead(Number(req.params.id), req.user.id);
  res.json({ ok: true });
});

const markAllNotifsRead = asyncHandler(async (req, res) => {
  await Notifications.markAllRead(req.user.id);
  res.json({ ok: true });
});

const createClaim = asyncHandler(async (req, res) => {
  const { item_id, proof } = req.body;
  if (!item_id || !proof?.trim()) return res.status(400).json({ error: 'Укажите ID и доказательство.' });
  const item = await Items.findById(Number(item_id));
  if (!item) return res.status(404).json({ error: 'Объявление не найдено.' });
  if (item.owner_id === req.user.id) return res.status(400).json({ error: 'Это ваше объявление.' });
  await Claims.create(item_id, req.user.id, proof.trim());
  if (item.owner_id) await Notifications.create(item.owner_id, 'claim', '📬 Новая заявка',
    `${req.user.name} подал заявку на «${item.title}».`);
  res.status(201).json({ ok: true });
});

const giveRating = asyncHandler(async (req, res) => {
  const { to_id, score, comment } = req.body;
  if (!to_id || !score) return res.status(400).json({ error: 'Укажите пользователя и оценку.' });
  if (Number(to_id) === req.user.id) return res.status(400).json({ error: 'Нельзя оценить себя.' });
  if (score < 1 || score > 5) return res.status(400).json({ error: 'Оценка от 1 до 5.' });
  await Ratings.give(req.user.id, Number(to_id), Number(score), comment);
  await awardPoints(req.user.id, 'give_rating');
  if (Number(score) === 5) await awardPoints(Number(to_id), 'got_5star');
  await Notifications.create(Number(to_id), 'info', `⭐ Новый отзыв`,
    `${req.user.name} оценил вас на ${score} из 5${comment ? ': ' + comment : ''}.`);
  res.json({ ok: true });
});

const getUserRatings = asyncHandler(async (req, res) =>
  res.json({ ratings: await Ratings.forUser(Number(req.params.userId)) }));

const getMyMatches = asyncHandler(async (req, res) => {
  const { getMatchesForUser } = require('../services/matchingService');
  res.json({ matches: await getMatchesForUser(req.user.id) });
});

const updateMatchStatus = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!['confirmed','rejected'].includes(status)) return res.status(400).json({ error: 'confirmed или rejected.' });
  await Matches.setStatus(Number(req.params.id), status);
  if (status === 'confirmed') await awardPoints(req.user.id, 'match_confirmed', Number(req.params.id));
  res.json({ ok: true });
});

const rebuildMatches = asyncHandler(async (req, res) => {
  const results = await buildMatchesForItem(Number(req.params.itemId));
  res.json({ matches: results });
});

const reportItem = asyncHandler(async (req, res) => {
  const itemId = Number(req.params.id);
  const { reason, comment } = req.body;
  const validReasons = ['spam','inappropriate','duplicate','fake','other'];
  if (!reason || !validReasons.includes(reason))
    return res.status(400).json({ error: 'Укажите корректную причину жалобы.' });

  const item = await Items.findById(itemId);
  if (!item) return res.status(404).json({ error: 'Объявление не найдено.' });
  if (item.owner_id === req.user.id)
    return res.status(400).json({ error: 'Нельзя пожаловаться на собственное объявление.' });

  try {
    await Reports.create(itemId, req.user.id, reason, comment);
  } catch (e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Вы уже отправляли жалобу на это объявление.' });
    throw e;
  }
  res.status(201).json({ ok: true, message: 'Жалоба принята. Мы рассмотрим её в ближайшее время.' });
});

// 🔴 #4 — Список своих заявок для пользователя
const getMyClaims = asyncHandler(async (req, res) => {
  const claims = await Claims.listByUser(req.user.id);
  res.json({ claims });
});

// ── Подписки ──────────────────────────────────────────────
const getSubscriptions = asyncHandler(async (req, res) => {
  res.json({ subscriptions: await Subscriptions.list(req.user.id) });
});

const createSubscription = asyncHandler(async (req, res) => {
  const { category_slug, location_keyword, item_type } = req.body;
  if (!category_slug && !location_keyword)
    return res.status(400).json({ error: 'Укажите категорию или район.' });
  await Subscriptions.create(req.user.id, category_slug, location_keyword, item_type);
  res.status(201).json({ ok: true });
});

const deleteSubscription = asyncHandler(async (req, res) => {
  await Subscriptions.delete(Number(req.params.id), req.user.id);
  res.json({ ok: true });
});

// ── Жалоба на пользователя ───────────────────────────────
const reportUser = asyncHandler(async (req, res) => {
  const targetId = Number(req.params.id);
  const { reason, comment } = req.body;
  if (!reason) return res.status(400).json({ error: 'Укажите причину.' });
  if (targetId === req.user.id) return res.status(400).json({ error: 'Нельзя жаловаться на себя.' });
  try {
    await UserReports.create(req.user.id, targetId, reason, comment);
    res.status(201).json({ ok: true, message: 'Жалоба принята.' });
  } catch (e) {
    if (e.message?.includes('UNIQUE')) return res.status(409).json({ error: 'Вы уже жаловались на этого пользователя.' });
    throw e;
  }
});

// ── Поиск в радиусе ──────────────────────────────────────
const getNearby = asyncHandler(async (req, res) => {
  const { lat, lng, radius = 5, type, category } = req.query;
  if (!lat || !lng) return res.status(400).json({ error: 'Укажите lat и lng.' });
  const items = await Items.listNearby(
    Number(lat), Number(lng), Number(radius),
    { type, category }
  );
  res.json({ items });
});

module.exports = {
  getThreads, getConversation, sendMessage, unreadCounts,
  getNotifications, markNotifRead, markAllNotifsRead,
  createClaim, getMyClaims,
  giveRating, getUserRatings,
  getMyMatches, updateMatchStatus, rebuildMatches,
  reportItem,
  getSubscriptions, createSubscription, deleteSubscription,
  reportUser,
  getNearby,
};
