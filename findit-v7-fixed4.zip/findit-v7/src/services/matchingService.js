const { all, get, run } = require('../config/database');

const STOP_WORDS = new Set(['был','была','было','были','это','что','как','для','при','под','над','или','но','и','а','в','на','по','за','из','от','до','со','же','бы','не','нет']);

function tokenize(text) {
  return String(text || '').toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(w => w.length > 2 && !STOP_WORDS.has(w));
}

function jaccardSimilarity(a, b) {
  const setA = new Set(tokenize(a));
  const setB = new Set(tokenize(b));
  if (!setA.size || !setB.size) return 0;
  let inter = 0;
  for (const t of setA) if (setB.has(t)) inter++;
  const union = setA.size + setB.size - inter;
  return union ? inter / union : 0;
}

function daysDiff(a, b) {
  return Math.abs((new Date(a) - new Date(b)) / 86400000);
}

function haversineKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return null;
  const R  = 6371;
  const dL = (lat2 - lat1) * Math.PI / 180;
  const dLo = (lon2 - lon1) * Math.PI / 180;
  const a  = Math.sin(dL/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLo/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function computeScore(lost, found) {
  let score = 0;
  if (lost.category_id && lost.category_id === found.category_id) score += 25;
  if (lost.brand && found.brand && lost.brand.toLowerCase().trim() === found.brand.toLowerCase().trim()) score += 15;
  if (lost.color && found.color && lost.color.toLowerCase().trim() === found.color.toLowerCase().trim()) score += 10;
  const textSim = jaccardSimilarity(`${lost.title} ${lost.description}`, `${found.title} ${found.description}`);
  score += Math.round(textSim * 20);
  if (lost.serial_number && found.serial_number && lost.serial_number.toLowerCase() === found.serial_number.toLowerCase()) score += 20;
  const diff = daysDiff(lost.event_date, found.event_date);
  if (diff <= 1) score += 15; else if (diff <= 3) score += 10; else if (diff <= 7) score += 5; else if (diff <= 30) score += 2;
  const km = haversineKm(lost.latitude, lost.longitude, found.latitude, found.longitude);
  if (km !== null) {
    if (km < 0.5) score += 15; else if (km < 2) score += 10; else if (km < 5) score += 5; else if (km < 15) score += 2;
  } else {
    score += Math.round(jaccardSimilarity(lost.location_text, found.location_text) * 10);
  }
  return Math.min(100, score);
}

async function buildMatchesForItem(itemId) {
  const { awardPoints } = require('./gamification');
  const { notifyMatch }  = require('./pushService');
  const emailService     = require('./emailService');
  const { Users }        = require('../models');

  const item = await get('SELECT * FROM items WHERE id = ? AND moderation_status = ?', [itemId, 'approved']);
  if (!item) return [];

  const opposite   = item.type === 'lost' ? 'found' : 'lost';
  const candidates = await all(
    "SELECT * FROM items WHERE type=? AND moderation_status='approved' AND status='open' AND id!=?",
    [opposite, itemId]
  );

  const results = [];
  for (const c of candidates) {
    const lost  = item.type === 'lost'  ? item : c;
    const found = item.type === 'found' ? item : c;
    const score = computeScore(lost, found);
    if (score >= 40) {
      const exists = await get('SELECT id FROM matches WHERE lost_item_id=? AND found_item_id=?', [lost.id, found.id]);
      if (!exists) {
        await run('INSERT INTO matches(lost_item_id,found_item_id,score) VALUES(?,?,?)', [lost.id, found.id, score]);

        // DB уведомление + push уведомление + email + очки
        if (lost.owner_id) {
          await run('INSERT INTO notifications(user_id,type,title,body,link) VALUES(?,?,?,?,?)',
            [lost.owner_id, 'match', '🔍 Найдено совпадение!',
             `Для вашего объявления «${lost.title}» найдено совпадение (${score}%)`, `/item.html?id=${found.id}`]);
          notifyMatch(lost.owner_id, lost.title, found.title, score, `/item.html?id=${found.id}`).catch(() => {});
          Users.findById(lost.owner_id).then(u => {
            if (u) emailService.notifyNewMatch(u, lost, found, score).catch(() => {});
          }).catch(() => {});
        }
        if (found.owner_id) {
          await run('INSERT INTO notifications(user_id,type,title,body,link) VALUES(?,?,?,?,?)',
            [found.owner_id, 'match', '🔍 Найдено совпадение!',
             `Ваше объявление «${found.title}» совпадает с потерянной вещью (${score}%)`, `/item.html?id=${lost.id}`]);
          notifyMatch(found.owner_id, found.title, lost.title, score, `/item.html?id=${lost.id}`).catch(() => {});
          Users.findById(found.owner_id).then(u => {
            if (u) emailService.notifyNewMatch(u, found, lost, score).catch(() => {});
          }).catch(() => {});
        }
      }
      results.push({ lost_item_id: lost.id, found_item_id: found.id, score });
    }
  }
  return results;
}

async function getMatchesForUser(userId) {
  return all(`
    SELECT m.id, m.score, m.status, m.created_at,
           li.id AS lost_id, li.title AS lost_title, li.location_text AS lost_location,
           fi.id AS found_id, fi.title AS found_title, fi.location_text AS found_location
    FROM matches m
    JOIN items li ON li.id = m.lost_item_id
    JOIN items fi ON fi.id = m.found_item_id
    WHERE li.owner_id=? OR fi.owner_id=?
    ORDER BY m.score DESC, m.created_at DESC
  `, [userId, userId]);
}

module.exports = { computeScore, buildMatchesForItem, getMatchesForUser };
