/**
 * Push Notification Service — Web Push API.
 * Для продакшена: npm install web-push
 * Сгенерируйте ключи: npx web-push generate-vapid-keys
 */

const { run, all } = require('../config/database');

const VAPID_PUBLIC_KEY  = process.env.VAPID_PUBLIC_KEY  || 'BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || 'UUxI4O8-FbRouAevSmBQ6co62groqdki4j8C7X2mxpU';

let webpush = null;
try {
  webpush = require('web-push');
  webpush.setVapidDetails('mailto:admin@findit.kz', VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
} catch {
  console.log('[PushService] web-push не установлен — push-уведомления только в лог.');
}

// BUG FIX: destructuring subscription.keys crashes if keys is undefined/null.
// Validate structure before destructuring.
async function saveSubscription(userId, subscription) {
  if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
    throw new Error('Некорректная push-подписка: отсутствуют endpoint или keys.');
  }
  const { endpoint, keys: { p256dh, auth } } = subscription;
  await run(
    'INSERT OR REPLACE INTO push_subscriptions(user_id,endpoint,p256dh,auth) VALUES(?,?,?,?)',
    [userId, endpoint, p256dh, auth]
  );
}

async function removeSubscription(endpoint) {
  await run('DELETE FROM push_subscriptions WHERE endpoint=?', [endpoint]);
}

async function pushToUser(userId, payload) {
  const subs = await all('SELECT * FROM push_subscriptions WHERE user_id=?', [userId]);
  const data  = JSON.stringify(payload);

  for (const sub of subs) {
    if (!webpush) {
      console.log(`[PUSH → user ${userId}]`, payload.title, payload.body);
      continue;
    }
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        data
      );
    } catch (err) {
      if (err.statusCode === 410 || err.statusCode === 404) {
        await removeSubscription(sub.endpoint);
      } else {
        console.error('[PUSH error]', err.message);
      }
    }
  }
}

async function pushToMany(userIds, payload) {
  await Promise.all(userIds.map(id => pushToUser(id, payload)));
}

async function notifyMatch(userId, lostTitle, foundTitle, score, itemUrl) {
  await pushToUser(userId, {
    title: `🔍 Найдено совпадение ${score}%`,
    body:  `«${lostTitle}» ↔ «${foundTitle}»`,
    url:   itemUrl || '/',
    icon:  '/icon-192.png',
    badge: '/icon-96.png',
  });
}

async function notifyApproved(userId, itemTitle) {
  await pushToUser(userId, {
    title: '✅ Объявление одобрено',
    body:  `«${itemTitle}» теперь видно всем.`,
    url:   '/dashboard.html',
    icon:  '/icon-192.png',
  });
}

async function notifyMessage(userId, fromName) {
  await pushToUser(userId, {
    title: '💬 Новое сообщение',
    body:  `${fromName} написал вам`,
    url:   '/dashboard.html',
    icon:  '/icon-192.png',
  });
}

module.exports = {
  VAPID_PUBLIC_KEY,
  saveSubscription,
  removeSubscription,
  pushToUser,
  pushToMany,
  notifyMatch,
  notifyApproved,
  notifyMessage,
};
