/**
 * Сервис автоархивирования объявлений.
 *
 * Логика:
 * — За 10 дней до архивирования (50-й день) пользователь получает уведомление.
 * — На 60-й день объявление переходит в статус 'archived'.
 *
 * Запускается раз в 6 часов через setInterval.
 */
const { run, all } = require('../config/database');
const { Notifications } = require('../models');

const WARN_DAYS    = 50;  // предупредить за 10 дней
const ARCHIVE_DAYS = 60;  // архивировать через 60 дней

async function runArchiveCycle() {
  try {
    // 1. Предупреждаем тех, кто ещё не получил уведомление
    const toWarn = await all(`
      SELECT id, owner_id, title FROM items
      WHERE status = 'open'
        AND moderation_status = 'approved'
        AND archive_warned = 0
        AND created_at < datetime('now', '-${WARN_DAYS} days')
    `);
    for (const item of toWarn) {
      await Notifications.create(
        item.owner_id, 'info',
        '⏳ Объявление скоро архивируется',
        `Объявление «${item.title}» будет архивировано через 10 дней. ` +
        `Если оно всё ещё актуально — просто обновите его.`,
        `/item.html?id=${item.id}`,
      );
      await run('UPDATE items SET archive_warned=1 WHERE id=?', [item.id]);
    }

    // 2. Архивируем объявления старше ARCHIVE_DAYS дней
    const toArchive = await all(`
      SELECT id, owner_id, title FROM items
      WHERE status = 'open'
        AND moderation_status = 'approved'
        AND created_at < datetime('now', '-${ARCHIVE_DAYS} days')
    `);
    for (const item of toArchive) {
      await run(
        "UPDATE items SET status='archived', updated_at=CURRENT_TIMESTAMP WHERE id=?",
        [item.id],
      );
      await Notifications.create(
        item.owner_id, 'info',
        '📦 Объявление архивировано',
        `Объявление «${item.title}» автоматически архивировано после ${ARCHIVE_DAYS} дней. ` +
        `Вы можете создать новое объявление, если вещь ещё не найдена.`,
      );
    }

    if (toWarn.length || toArchive.length) {
      console.log(`[archive] warned=${toWarn.length}  archived=${toArchive.length}`);
    }
  } catch (err) {
    console.error('[archive] Error:', err.message);
  }
}

function startArchiveService() {
  // Первый запуск через 1 минуту после старта сервера (не мешает инициализации)
  setTimeout(() => {
    runArchiveCycle();
    setInterval(runArchiveCycle, 6 * 60 * 60 * 1000); // каждые 6 часов
  }, 60_000);
  console.log('📦 Сервис автоархивирования запущен (каждые 6 часов)');
}

module.exports = { startArchiveService };
