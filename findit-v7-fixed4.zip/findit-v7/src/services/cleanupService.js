/**
 * Сервис очистки осиротевших файлов из uploads/.
 *
 * Логика:
 * — Собирает все image_url из БД (items + users.avatar)
 * — Сравнивает с файлами в public/uploads/
 * — Удаляет файлы, которых нет ни в одной записи БД
 * — Запускается раз в сутки
 */

const fs   = require('fs');
const path = require('path');
const { all } = require('../config/database');

const UPLOADS_DIR = path.join(__dirname, '..', '..', 'public', 'uploads');

async function runCleanup() {
  try {
    if (!fs.existsSync(UPLOADS_DIR)) return;

    // Собираем все используемые файлы из БД
    const [items, users] = await Promise.all([
      all('SELECT image_url FROM items WHERE image_url IS NOT NULL'),
      all('SELECT avatar FROM users WHERE avatar IS NOT NULL'),
    ]);

    const usedFiles = new Set();
    for (const row of items) {
      const name = path.basename(row.image_url);
      usedFiles.add(name);
    }
    for (const row of users) {
      const name = path.basename(row.avatar);
      usedFiles.add(name);
    }

    // Читаем все файлы на диске
    const diskFiles = fs.readdirSync(UPLOADS_DIR)
      .filter(f => !f.startsWith('.'));

    let deleted = 0;
    for (const file of diskFiles) {
      if (!usedFiles.has(file)) {
        try {
          fs.unlinkSync(path.join(UPLOADS_DIR, file));
          deleted++;
        } catch { /* файл уже удалён */ }
      }
    }

    if (deleted > 0) {
      console.log(`[uploads-cleanup] Удалено ${deleted} осиротевших файлов из ${diskFiles.length}`);
    }
  } catch (err) {
    console.error('[uploads-cleanup] Ошибка:', err.message);
  }
}

function startCleanupService() {
  // Первый запуск через 5 минут после старта
  setTimeout(() => {
    runCleanup();
    setInterval(runCleanup, 24 * 60 * 60 * 1000); // раз в 24 часа
  }, 5 * 60_000);
  console.log('🧹 Сервис очистки uploads запущен (раз в 24 часа)');
}

module.exports = { startCleanupService, runCleanup };
