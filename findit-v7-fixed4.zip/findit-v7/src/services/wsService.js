/**
 * WebSocket сервис через socket.io.
 *
 * Заменяет polling каждые 4 секунды → real-time события.
 * Экономия: ~750 HTTP-запросов/час на пользователя → 0.
 *
 * События:
 *   client → server:  join_room, send_message, typing
 *   server → client:  new_message, notification, unread_count
 */

const jwt = require('jsonwebtoken');
const { Messages, Notifications } = require('../models');

let io = null;
// userId → Set<socketId>
const onlineUsers = new Map();

function initWebSocket(server) {
  const { Server } = require('socket.io');
  io = new Server(server, {
    cors: { origin: '*' },
    path: '/ws',
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.query?.token;
    if (!token) return next(new Error('Нет токена'));
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET || 'findit-secret-2024');
      socket.userId = payload.id;
      next();
    } catch {
      next(new Error('Неверный токен'));
    }
  });

  io.on('connection', socket => {
    const uid = socket.userId;
    if (!onlineUsers.has(uid)) onlineUsers.set(uid, new Set());
    onlineUsers.get(uid).add(socket.id);

    // Автоматически присоединяем к личной комнате
    socket.join(`user:${uid}`);

    // ── Новое сообщение ──────────────────────────────────
    socket.on('send_message', async ({ receiver_id, body, item_id }) => {
      if (!receiver_id || !body?.trim()) return;
      if (Number(receiver_id) === uid) return;
      try {
        await Messages.send(uid, Number(receiver_id), body.trim(), item_id || null);
        const msg = {
          sender_id:   uid,
          receiver_id: Number(receiver_id),
          body:        body.trim(),
          item_id:     item_id || null,
          created_at:  new Date().toISOString(),
          is_read:     0,
        };
        // Отправляем получателю если он онлайн
        io.to(`user:${receiver_id}`).emit('new_message', msg);
        // Подтверждаем отправителю
        socket.emit('new_message', { ...msg, sent: true });
      } catch (e) {
        socket.emit('error', { message: e.message });
      }
    });

    // ── Индикатор набора ─────────────────────────────────
    socket.on('typing', ({ receiver_id, is_typing }) => {
      io.to(`user:${receiver_id}`).emit('typing', { from: uid, is_typing: !!is_typing });
    });

    // ── Отключение ───────────────────────────────────────
    socket.on('disconnect', () => {
      const sockets = onlineUsers.get(uid);
      if (sockets) {
        sockets.delete(socket.id);
        if (sockets.size === 0) onlineUsers.delete(uid);
      }
    });
  });

  console.log('⚡ WebSocket (socket.io) инициализирован на /ws');
  return io;
}

// Отправить push-событие пользователю по userId (используется из других сервисов)
function emitToUser(userId, event, data) {
  if (!io) return;
  io.to(`user:${userId}`).emit(event, data);
}

// Уведомить пользователя о новом уведомлении
async function emitNotification(userId, notification) {
  emitToUser(userId, 'notification', notification);
}

function isOnline(userId) {
  return onlineUsers.has(userId);
}

module.exports = { initWebSocket, emitToUser, emitNotification, isOnline };
