/**
 * emailService.js — централизованная отправка email-уведомлений.
 *
 * Поддерживает три события:
 *   • new_match   — найдено совпадение между объявлениями
 *   • claim_status — заявка одобрена / отклонена
 *   • new_message  — получено новое сообщение
 *
 * Если SMTP не настроен — пишет в консоль (dev-режим).
 */

const nodemailer = require('nodemailer');
const env = require('../config/env');

// ── Transporter (singleton) ───────────────────────────────
let _transport = null;
function getTransport() {
  if (_transport) return _transport;
  if (!env.SMTP_HOST) return null;
  _transport = nodemailer.createTransport({
    host:   env.SMTP_HOST,
    port:   env.SMTP_PORT,
    secure: env.SMTP_SECURE,
    auth:   { user: env.SMTP_USER, pass: env.SMTP_PASS },
  });
  return _transport;
}

// ── Base send ─────────────────────────────────────────────
async function send({ to, subject, html, text }) {
  const transport = getTransport();
  if (transport) {
    try {
      await transport.sendMail({ from: env.EMAIL_FROM, to, subject, html, text });
    } catch (err) {
      console.error('[emailService] send error:', err.message);
    }
  } else {
    console.log(`\n📧 [emailService DEV] → ${to}\nSubject: ${subject}\n${text || subject}\n`);
  }
}

// ── Shared layout ─────────────────────────────────────────
function layout(title, body) {
  return `
  <div style="font-family:sans-serif;max-width:520px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb">
    <div style="background:#6366f1;padding:20px 24px">
      <span style="color:#fff;font-size:1.3rem;font-weight:700">🔍 FindIt</span>
    </div>
    <div style="padding:28px 24px">
      <h2 style="margin:0 0 16px;font-size:1.1rem;color:#111">${title}</h2>
      ${body}
    </div>
    <div style="background:#f9fafb;padding:14px 24px;text-align:center;font-size:.78rem;color:#9ca3af">
      Это автоматическое уведомление от FindIt. Не отвечайте на это письмо.
    </div>
  </div>`;
}

function btn(href, label) {
  return `<a href="${href}"
    style="display:inline-block;margin-top:16px;padding:12px 24px;background:#6366f1;
           color:#fff;border-radius:8px;text-decoration:none;font-weight:600;font-size:.95rem"
  >${label}</a>`;
}

// ── 1. Новое совпадение ───────────────────────────────────
/**
 * @param {object} user      — { email, name }
 * @param {object} myItem    — { id, title, type }
 * @param {object} matchItem — { id, title, type }
 * @param {number} score     — совпадение 0-100
 */
async function notifyNewMatch(user, myItem, matchItem, score) {
  if (!user?.email) return;

  const typeLabel  = myItem.type === 'lost' ? '🔴 Потеряно' : '🟢 Найдено';
  const matchLabel = matchItem.type === 'lost' ? '🔴 Потеряно' : '🟢 Найдено';
  const matchUrl   = `${env.APP_URL || 'http://localhost:3000'}/item.html?id=${matchItem.id}`;

  const html = layout(
    '🎯 Найдено возможное совпадение!',
    `<p style="color:#444;line-height:1.6">Привет, <strong>${user.name}</strong>!</p>
     <p style="color:#444;line-height:1.6">
       Для вашего объявления <strong>«${myItem.title}»</strong> (${typeLabel})
       нашлось похожее: <strong>«${matchItem.title}»</strong> (${matchLabel}).
     </p>
     <p style="color:#444">Степень совпадения: <strong style="color:#6366f1">${score}%</strong></p>
     ${btn(matchUrl, 'Посмотреть объявление')}`,
  );
  const text = `FindIt: для «${myItem.title}» найдено совпадение — «${matchItem.title}» (${score}%). ${matchUrl}`;

  await send({
    to:      user.email,
    subject: `🎯 Совпадение для «${myItem.title}» — FindIt`,
    html, text,
  });
}

// ── 2. Статус заявки (одобрена / отклонена) ──────────────
/**
 * @param {object} user    — { email, name }
 * @param {object} claim   — { id }
 * @param {object} item    — { id, title }
 * @param {string} status  — 'approved' | 'rejected'
 * @param {string} note    — комментарий администратора
 */
async function notifyClaimStatus(user, claim, item, status, note) {
  if (!user?.email) return;

  const approved = status === 'approved';
  const icon     = approved ? '✅' : '❌';
  const label    = approved ? 'одобрена' : 'отклонена';
  const color    = approved ? '#10b981' : '#ef4444';
  const itemUrl  = `${env.APP_URL || 'http://localhost:3000'}/item.html?id=${item.id}`;

  const html = layout(
    `${icon} Заявка ${label}`,
    `<p style="color:#444;line-height:1.6">Привет, <strong>${user.name}</strong>!</p>
     <p style="color:#444;line-height:1.6">
       Ваша заявка на вещь <strong>«${item.title}»</strong> была
       <strong style="color:${color}">${label}</strong>.
     </p>
     ${note ? `<div style="background:#f3f4f6;border-radius:8px;padding:12px 16px;color:#555;font-size:.9rem">
       <strong>Комментарий:</strong> ${note}
     </div>` : ''}
     ${btn(itemUrl, 'Перейти к объявлению')}`,
  );
  const text = `FindIt: ваша заявка на «${item.title}» ${label}. ${note ? 'Комментарий: ' + note + '. ' : ''}${itemUrl}`;

  await send({
    to:      user.email,
    subject: `${icon} Заявка ${label} — FindIt`,
    html, text,
  });
}

// ── 3. Новое сообщение ────────────────────────────────────
/**
 * @param {object} receiver — { email, name }
 * @param {object} sender   — { id, name }
 * @param {string} preview  — первые ~100 символов сообщения
 */
async function notifyNewMessage(receiver, sender, preview) {
  if (!receiver?.email) return;

  const msgUrl = `${env.APP_URL || 'http://localhost:3000'}/dashboard.html#messages`;

  const html = layout(
    '💬 Новое сообщение',
    `<p style="color:#444;line-height:1.6">Привет, <strong>${receiver.name}</strong>!</p>
     <p style="color:#444;line-height:1.6">
       <strong>${sender.name}</strong> отправил(а) вам сообщение:
     </p>
     <div style="background:#f3f4f6;border-radius:8px;padding:14px 16px;
                 color:#374151;font-size:.95rem;line-height:1.5;font-style:italic">
       «${preview.length > 120 ? preview.slice(0, 120) + '…' : preview}»
     </div>
     ${btn(msgUrl, 'Открыть переписку')}`,
  );
  const text = `FindIt: ${sender.name} написал(а) вам: «${preview.slice(0, 80)}». ${msgUrl}`;

  await send({
    to:      receiver.email,
    subject: `💬 Сообщение от ${sender.name} — FindIt`,
    html, text,
  });
}

module.exports = { notifyNewMatch, notifyClaimStatus, notifyNewMessage };
