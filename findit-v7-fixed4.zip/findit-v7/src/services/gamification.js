const { run, get, all } = require('../config/database');

// ─── Конфигурация очков ───────────────────────────────────
const POINT_ACTIONS = {
  create_item:     { points: 10,  label: 'Создано объявление'     },
  item_approved:   { points: 5,   label: 'Объявление одобрено'    },
  item_returned:   { points: 50,  label: 'Вещь возвращена'        },
  match_confirmed: { points: 20,  label: 'Совпадение подтверждено'},
  send_message:    { points: 2,   label: 'Сообщение отправлено'   },
  give_rating:     { points: 5,   label: 'Оставлен отзыв'        },
  got_5star:       { points: 15,  label: 'Получена оценка 5⭐'    },
  claim_approved:  { points: 30,  label: 'Заявка одобрена'        },
  first_item:      { points: 25,  label: 'Первое объявление'      },
};

// ─── Конфигурация бейджей ─────────────────────────────────
const BADGES = {
  first_post:    { icon: '🌱', name: 'Первый шаг',     desc: 'Создано первое объявление' },
  helper:        { icon: '🤝', name: 'Помощник',       desc: 'Вещь успешно возвращена' },
  super_helper:  { icon: '🦸', name: 'Супергерой',     desc: '5 вещей возвращено' },
  communicator:  { icon: '💬', name: 'Коммуникатор',   desc: '20 сообщений отправлено' },
  trusted:       { icon: '⭐', name: 'Проверенный',    desc: 'Рейтинг выше 4.5' },
  detective:     { icon: '🕵️', name: 'Детектив',      desc: '10 совпадений подтверждено' },
  veteran:       { icon: '🏅', name: 'Ветеран',        desc: '100 очков набрано' },
  champion:      { icon: '🏆', name: 'Чемпион',        desc: '500 очков набрано' },
};

// ─── Начислить очки ───────────────────────────────────────
async function awardPoints(userId, action, refId = null) {
  const cfg = POINT_ACTIONS[action];
  if (!cfg) return 0;

  await run(
    'INSERT INTO user_points(user_id,action,points,ref_id,note) VALUES(?,?,?,?,?)',
    [userId, action, cfg.points, refId, cfg.label]
  );

  // Обновляем суммарные очки в users (денормализация для быстрой выборки)
  const total = await getTotalPoints(userId);
  await run('UPDATE users SET total_points = ? WHERE id=?', [total, userId]);

  // Проверяем бейджи после каждого начисления
  await checkAndAwardBadges(userId, action, total);

  return cfg.points;
}

// ─── Получить сумму очков ─────────────────────────────────
async function getTotalPoints(userId) {
  const r = await get('SELECT COALESCE(SUM(points),0) AS total FROM user_points WHERE user_id=?', [userId]);
  return r?.total || 0;
}

// ─── Получить историю очков ───────────────────────────────
async function getPointsHistory(userId) {
  return all('SELECT * FROM user_points WHERE user_id=? ORDER BY created_at DESC LIMIT 30', [userId]);
}

// ─── Получить бейджи пользователя ────────────────────────
async function getUserBadges(userId) {
  const rows = await all('SELECT badge_slug, created_at FROM user_badges WHERE user_id=? ORDER BY created_at DESC', [userId]);
  return rows.map(r => ({ ...BADGES[r.badge_slug], slug: r.badge_slug, earned_at: r.created_at }));
}

// ─── Выдать бейдж (если ещё нет) ─────────────────────────
async function grantBadge(userId, slug) {
  try {
    await run('INSERT OR IGNORE INTO user_badges(user_id,badge_slug) VALUES(?,?)', [userId, slug]);
    return BADGES[slug];
  } catch { return null; }
}

// ─── Проверить и выдать бейджи ────────────────────────────
async function checkAndAwardBadges(userId, action, totalPoints) {
  const newBadges = [];

  // Ветеран и Чемпион — по очкам
  if (totalPoints >= 100) {
    const b = await grantBadge(userId, 'veteran');
    if (b) newBadges.push(b);
  }
  if (totalPoints >= 500) {
    const b = await grantBadge(userId, 'champion');
    if (b) newBadges.push(b);
  }

  // Первый пост
  if (action === 'create_item') {
    const cnt = await get('SELECT COUNT(*) AS n FROM user_points WHERE user_id=? AND action=?', [userId, 'create_item']);
    if (cnt.n === 1) {
      const b = await grantBadge(userId, 'first_post');
      if (b) newBadges.push(b);
    }
  }

  // Помощник и Супергерой — по возвратам
  if (action === 'item_returned') {
    const cnt = await get('SELECT COUNT(*) AS n FROM user_points WHERE user_id=? AND action=?', [userId, 'item_returned']);
    if (cnt.n >= 1) { const b = await grantBadge(userId, 'helper'); if (b) newBadges.push(b); }
    if (cnt.n >= 5) { const b = await grantBadge(userId, 'super_helper'); if (b) newBadges.push(b); }
  }

  // Коммуникатор — 20 сообщений
  if (action === 'send_message') {
    const cnt = await get('SELECT COUNT(*) AS n FROM user_points WHERE user_id=? AND action=?', [userId, 'send_message']);
    if (cnt.n >= 20) { const b = await grantBadge(userId, 'communicator'); if (b) newBadges.push(b); }
  }

  // Детектив — 10 подтверждённых совпадений
  if (action === 'match_confirmed') {
    const cnt = await get('SELECT COUNT(*) AS n FROM user_points WHERE user_id=? AND action=?', [userId, 'match_confirmed']);
    if (cnt.n >= 10) { const b = await grantBadge(userId, 'detective'); if (b) newBadges.push(b); }
  }

  // Проверенный — рейтинг > 4.5
  if (action === 'got_5star') {
    const user = await get('SELECT rating FROM users WHERE id=?', [userId]);
    if (user?.rating >= 4.5) { const b = await grantBadge(userId, 'trusted'); if (b) newBadges.push(b); }
  }

  return newBadges;
}

// ─── Таблица лидеров ─────────────────────────────────────
async function getLeaderboard(limit = 10) {
  return all(`
    SELECT u.id, u.name, u.avatar, u.rating,
           COALESCE(SUM(p.points), 0) AS total_points,
           COUNT(DISTINCT CASE WHEN p.action='item_returned' THEN p.id END) AS returns
    FROM users u
    LEFT JOIN user_points p ON p.user_id = u.id
    WHERE u.role != 'admin'
    GROUP BY u.id
    ORDER BY total_points DESC
    LIMIT ?`, [limit]);
}

// ─── Получить уровень по очкам ────────────────────────────
function getLevel(points) {
  if (points < 50)   return { level: 1, name: 'Новичок',     icon: '🌱', next: 50 };
  if (points < 150)  return { level: 2, name: 'Участник',    icon: '🔵', next: 150 };
  if (points < 350)  return { level: 3, name: 'Активист',    icon: '🟡', next: 350 };
  if (points < 700)  return { level: 4, name: 'Помощник',    icon: '🟠', next: 700 };
  if (points < 1200) return { level: 5, name: 'Герой',       icon: '🔴', next: 1200 };
  return               { level: 6, name: 'Легенда',          icon: '💎', next: null };
}

module.exports = { awardPoints, getTotalPoints, getPointsHistory, getUserBadges, getLeaderboard, getLevel, BADGES, POINT_ACTIONS };
