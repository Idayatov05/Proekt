const { run, get, all } = require('../config/database');

// ─── USERS ───────────────────────────────────────────────
const Users = {
  findByEmail: email => get('SELECT * FROM users WHERE email=?', [email.toLowerCase().trim()]),
  // FIX-4a: total_points was absent from SELECT — gamification page always
  // showed 0 points even after earning them.
  findById: id => get(
    'SELECT id,name,email,role,avatar,phone,bio,city,rating,rating_count,total_points,is_banned,created_at FROM users WHERE id=?',
    [id]
  ),
  create: ({ name, email, passwordHash }) =>
    run('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)', [name.trim(), email.toLowerCase().trim(), passwordHash])
      .then(r => Users.findById(r.id)),
  // FIX-4b: total_points missing from admin user list too.
  list: () => all(
    'SELECT id,name,email,role,avatar,phone,rating,rating_count,total_points,is_banned,created_at FROM users ORDER BY created_at DESC'
  ),
  update: (id, fields) => {
    const allowed = ['name','phone','bio','avatar','city'];
    const sets = [], vals = [];
    for (const k of allowed) if (fields[k] !== undefined) { sets.push(`${k}=?`); vals.push(fields[k]); }
    if (!sets.length) return Promise.resolve();
    vals.push(id);
    return run(`UPDATE users SET ${sets.join(',')} WHERE id=?`, vals);
  },
  ban:        (id, v)  => run('UPDATE users SET is_banned=? WHERE id=?', [v ? 1 : 0, id]),
  setRole:    (id, r)  => run('UPDATE users SET role=? WHERE id=?', [r, id]),
  setResetToken: (id, token, expires) =>
    run('UPDATE users SET reset_token=?, reset_token_expires=? WHERE id=?', [token, expires, id]),
  findByResetToken: token =>
    get('SELECT * FROM users WHERE reset_token=? AND reset_token_expires > ?', [token, new Date().toISOString()]),
  clearResetToken: id =>
    run('UPDATE users SET reset_token=NULL, reset_token_expires=NULL WHERE id=?', [id]),
  setPassword: (id, hash) =>
    run('UPDATE users SET password_hash=? WHERE id=?', [hash, id]),

  setEmailVerifyToken: (id, token) =>
    run('UPDATE users SET email_verify_token=? WHERE id=?', [token, id]),
  findByEmailVerifyToken: token =>
    get('SELECT * FROM users WHERE email_verify_token=?', [token]),
  verifyEmail: id =>
    run('UPDATE users SET email_verified=1, email_verify_token=NULL WHERE id=?', [id]),

  // GDPR — анонимизация аккаунта вместо жёсткого удаления (сохраняем целостность объявлений)
  anonymize: async (id) => {
    await run(
      `UPDATE users SET
        name='Удалённый пользователь',
        email=?,
        password_hash='',
        avatar=NULL, phone=NULL, bio=NULL,
        reset_token=NULL, reset_token_expires=NULL
       WHERE id=?`,
      [`deleted_${id}@findit.invalid`, id],
    );
    await run('DELETE FROM notifications WHERE user_id=?', [id]);
    await run('DELETE FROM messages WHERE sender_id=? OR receiver_id=?', [id, id]);
  },

  // Публичный профиль (без приватных полей) + статистика
  publicProfile: async (id) => {
    const user = await get(
      'SELECT id, name, avatar, bio, city, rating, rating_count, total_points, created_at FROM users WHERE id=?',
      [id],
    );
    if (!user) return null;
    const stats = await get(`
      SELECT
        COUNT(*) AS items_count,
        SUM(CASE WHEN status='returned' THEN 1 ELSE 0 END) AS returned_count,
        SUM(CASE WHEN type='lost' THEN 1 ELSE 0 END) AS lost_count,
        SUM(CASE WHEN type='found' THEN 1 ELSE 0 END) AS found_count
      FROM items
      WHERE owner_id=? AND moderation_status='approved'`,
      [id],
    );
    user.stats = stats;
    return user;
  },
};

// ─── CATEGORIES ──────────────────────────────────────────
const Categories = {
  list: () => all('SELECT * FROM categories ORDER BY id'),
};

// ─── ITEMS ───────────────────────────────────────────────
const ITEM_JOINS = `
  SELECT items.*, u.name AS owner_name, u.avatar AS owner_avatar,
         c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon
  FROM items
  LEFT JOIN users      u ON u.id = items.owner_id
  LEFT JOIN categories c ON c.id = items.category_id
`;

const Items = {
  findById: async (id) => {
    const item = await get(`${ITEM_JOINS} WHERE items.id=?`, [id]);
    if (!item) return null;
    const photos = await all(
      'SELECT url FROM item_photos WHERE item_id=? ORDER BY sort_order ASC', [id]
    );
    item.photos = photos.map(p => p.url);
    return item;
  },

  list: async (filters = {}) => {
    const { type, category, color, brand, location, search, status, moderation='approved', limit=50, offset=0, sort='newest' } = filters;

    // Допустимые варианты сортировки
    const ORDER_MAP = {
      newest:     'items.created_at DESC',
      event_date: 'items.event_date DESC, items.created_at DESC',
      oldest:     'items.created_at ASC',
    };
    const orderBy = ORDER_MAP[sort] || ORDER_MAP.newest;

    // FTS5 полнотекстовый поиск когда есть поисковый запрос
    if (search && search.trim()) {
      const ftsQuery = search.trim()
        .split(/\s+/)
        .filter(Boolean)
        .map(w => `"${w.replace(/"/g, '')}"*`)
        .join(' OR ');

      const conds = ['items.moderation_status=?'];
      const params = [moderation];
      if (type)     { conds.push('items.type=?');  params.push(type); }
      if (category) { conds.push('c.slug=?');       params.push(category); }
      if (status)   { conds.push('items.status=?'); params.push(status); }
      const where = 'WHERE ' + conds.join(' AND ');

      // Считаем total для FTS-запроса
      const countParams = [...params, ftsQuery];
      const countRow = await get(`
        SELECT COUNT(*) AS total
        FROM items_fts
        JOIN items ON items.id = items_fts.rowid
        LEFT JOIN categories c ON c.id = items.category_id
        ${where} AND items_fts MATCH ?`, countParams);

      params.push(ftsQuery, Number(limit), Number(offset));
      const rows = await all(`
        SELECT items.*, u.name AS owner_name, u.avatar AS owner_avatar,
               c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon
        FROM items_fts
        JOIN items ON items.id = items_fts.rowid
        LEFT JOIN users      u ON u.id = items.owner_id
        LEFT JOIN categories c ON c.id = items.category_id
        ${where} AND items_fts MATCH ?
        ORDER BY rank, ${orderBy}
        LIMIT ? OFFSET ?`, params);
      return { rows, total: countRow.total };
    }

    // Обычный запрос без поиска
    const conds = [], params = [];
    if (type)       { conds.push('items.type=?');                      params.push(type); }
    if (category)   { conds.push('c.slug=?');                          params.push(category); }
    if (color)      { conds.push('LOWER(items.color) LIKE ?');         params.push(`%${color.toLowerCase()}%`); }
    if (brand)      { conds.push('LOWER(items.brand) LIKE ?');         params.push(`%${brand.toLowerCase()}%`); }
    if (location)   { conds.push('LOWER(items.location_text) LIKE ?'); params.push(`%${location.toLowerCase()}%`); }
    if (status)     { conds.push('items.status=?');                    params.push(status); }
    if (moderation) { conds.push('items.moderation_status=?');         params.push(moderation); }
    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';

    // Считаем total
    const countRow = await get(`SELECT COUNT(*) AS total FROM items LEFT JOIN categories c ON c.id = items.category_id ${where}`, params);

    params.push(Number(limit), Number(offset));
    const rows = await all(`${ITEM_JOINS} ${where} ORDER BY ${orderBy} LIMIT ? OFFSET ?`, params);
    return { rows, total: countRow.total };
  },

  // Защита от дублей: то же название от того же пользователя за 24ч
  findDuplicate: (ownerId, title) => get(
    `SELECT id FROM items
     WHERE owner_id=? AND LOWER(title)=LOWER(?)
       AND created_at > datetime('now', '-24 hours')`,
    [ownerId, title],
  ),

  // Поиск в радиусе (км) — формула Хаверсина прямо в SQLite
  listNearby: (lat, lng, radiusKm, filters = {}) => {
    const { type, category, limit = 50 } = filters;
    const conds = [
      "items.moderation_status='approved'",
      "items.status='open'",
      'items.latitude IS NOT NULL',
      'items.longitude IS NOT NULL',
    ];
    // FIX 1: correct param order — Haversine needs (lat, lat, lng):
    //   position 1: items.latitude  - user_lat
    //   position 2: COS(user_lat)   ← was wrongly lng
    //   position 3: items.longitude - user_lng ← was wrongly lat
    const params = [lat, lat, lng];
    if (type)     { conds.push('items.type=?'); params.push(type); }
    if (category) { conds.push('c.slug=?');     params.push(category); }
    // FIX 2: SQLite ignores SELECT aliases in WHERE; use HAVING instead
    params.push(Number(radiusKm));
    params.push(Number(limit));
    return all(`
      SELECT items.*, u.name AS owner_name, u.avatar AS owner_avatar,
             c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon,
             (6371 * 2 * ASIN(SQRT(
               POWER(SIN((items.latitude  - ?) * 3.14159265/180 / 2), 2) +
               COS(? * 3.14159265/180) * COS(items.latitude * 3.14159265/180) *
               POWER(SIN((items.longitude - ?) * 3.14159265/180 / 2), 2)
             ))) AS distance_km
      FROM items
      LEFT JOIN users      u ON u.id = items.owner_id
      LEFT JOIN categories c ON c.id = items.category_id
      WHERE ${conds.join(' AND ')}
      GROUP BY items.id
      HAVING distance_km <= ?
      ORDER BY distance_km ASC
      LIMIT ?`, params);
  },

  // FIX 3: duplicate listByOwner removed (second definition silently overwrote first)
  listByOwner: ownerId => all(`${ITEM_JOINS} WHERE items.owner_id=? ORDER BY items.created_at DESC`, [ownerId]),

  listLatest: (n = 8) => all(`${ITEM_JOINS} WHERE items.moderation_status='approved' ORDER BY items.created_at DESC LIMIT ?`, [n]),

  listPending: () => all(`${ITEM_JOINS} WHERE items.moderation_status='pending' ORDER BY items.created_at DESC`),

  listMapPoints: () => all(`SELECT id,type,title,location_text,latitude,longitude FROM items
    WHERE moderation_status='approved' AND latitude IS NOT NULL ORDER BY created_at DESC LIMIT 100`),

  create: p => run(`INSERT INTO items(owner_id,type,title,description,category_id,brand,color,
    location_text,latitude,longitude,event_date,image_url,serial_number,reward,contact_info,status,moderation_status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'open',?)`,
    [p.owner_id, p.type, p.title, p.description, p.category_id, p.brand||null, p.color||null,
     p.location_text, p.latitude||null, p.longitude||null, p.event_date, p.image_url||null,
     p.serial_number||null, p.reward||null, p.contact_info||null, p.moderation_status])
    .then(r => Items.findById(r.id)),

  update: (id, p) => run(`UPDATE items SET title=?,description=?,brand=?,color=?,location_text=?,
    event_date=?,reward=?,contact_info=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`,
    [p.title, p.description, p.brand||null, p.color||null, p.location_text,
     p.event_date, p.reward||null, p.contact_info||null, id])
    .then(() => Items.findById(id)),

  moderate: (id, status, reason) => run(
    'UPDATE items SET moderation_status=?,reject_reason=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
    [status, reason||null, id]).then(() => Items.findById(id)),

  setStatus: (id, status) => run('UPDATE items SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', [status, id]),

  delete: id => run('DELETE FROM items WHERE id=?', [id]),

  incViews: id => run('UPDATE items SET views=views+1 WHERE id=?', [id]),

  stats: () => get(`SELECT
    (SELECT COUNT(*) FROM items) total,
    (SELECT COUNT(*) FROM items WHERE type='lost') lost,
    (SELECT COUNT(*) FROM items WHERE type='found') found,
    (SELECT COUNT(*) FROM items WHERE status='returned') returned,
    (SELECT COUNT(*) FROM users) users,
    (SELECT COUNT(*) FROM items WHERE moderation_status='pending') pending,
    (SELECT COUNT(*) FROM claims WHERE status='pending') claims`),
};

// ─── MATCHES ─────────────────────────────────────────────
const Matches = {
  forItem: itemId => all(`
    SELECT m.*, li.title AS lost_title, fi.title AS found_title
    FROM matches m JOIN items li ON li.id=m.lost_item_id JOIN items fi ON fi.id=m.found_item_id
    WHERE m.lost_item_id=? OR m.found_item_id=? ORDER BY m.score DESC`, [itemId, itemId]),
  setStatus: (id, status) => run('UPDATE matches SET status=? WHERE id=?', [status, id]),
};

// ─── CLAIMS ──────────────────────────────────────────────
const Claims = {
  // Транзакция: если что-то упадёт на полпути — данные не испортятся
  create: async (itemId, reqId, proof) => {
    const { db } = require('../config/database');
    return new Promise((resolve, reject) => {
      db.serialize(() => {
        db.run('BEGIN');
        db.run(
          'INSERT INTO claims(item_id,requester_id,proof) VALUES(?,?,?)',
          [itemId, reqId, proof],
          function (err) {
            if (err) { db.run('ROLLBACK'); return reject(err); }
            db.run('COMMIT', commitErr => {
              if (commitErr) { db.run('ROLLBACK'); return reject(commitErr); }
              resolve({ id: this.lastID });
            });
          },
        );
      });
    });
  },
  list: () => all(`SELECT cl.*, i.title AS item_title, u.name AS requester_name
    FROM claims cl LEFT JOIN items i ON i.id=cl.item_id LEFT JOIN users u ON u.id=cl.requester_id
    ORDER BY cl.created_at DESC`),
  listByItem: itemId => all('SELECT cl.*, u.name AS requester_name FROM claims cl LEFT JOIN users u ON u.id=cl.requester_id WHERE cl.item_id=? ORDER BY cl.created_at DESC', [itemId]),
  setStatus: (id, status, note) => run('UPDATE claims SET status=?,admin_note=? WHERE id=?', [status, note||null, id]),
  findById: id => get('SELECT cl.*, i.title AS item_title, i.owner_id, u.name AS requester_name FROM claims cl LEFT JOIN items i ON i.id=cl.item_id LEFT JOIN users u ON u.id=cl.requester_id WHERE cl.id=?', [id]),
  // 🔴 #4 — список заявок самого пользователя
  listByUser: userId => all(`
    SELECT cl.id, cl.status, cl.proof, cl.admin_note, cl.created_at,
           i.id AS item_id, i.title AS item_title, i.type AS item_type
    FROM claims cl
    LEFT JOIN items i ON i.id = cl.item_id
    WHERE cl.requester_id = ?
    ORDER BY cl.created_at DESC`, [userId]),
};

// ─── MESSAGES ────────────────────────────────────────────
const Messages = {
  send: (senderId, receiverId, body, itemId) =>
    run('INSERT INTO messages(sender_id,receiver_id,body,item_id) VALUES(?,?,?,?)', [senderId, receiverId, body, itemId||null]),
  conversation: (a, b) => all(`
    SELECT m.*, u.name AS sender_name FROM messages m
    LEFT JOIN users u ON u.id=m.sender_id
    WHERE (m.sender_id=? AND m.receiver_id=?) OR (m.sender_id=? AND m.receiver_id=?)
    ORDER BY m.created_at ASC`, [a, b, b, a]),
  threads: userId => all(`
    SELECT c.contact_id,
      u.name  AS contact_name,
      u.avatar AS contact_avatar,
      (SELECT body FROM messages
        WHERE (sender_id=? AND receiver_id=c.contact_id)
           OR (sender_id=c.contact_id AND receiver_id=?)
        ORDER BY created_at DESC LIMIT 1) AS last_msg,
      (SELECT created_at FROM messages
        WHERE (sender_id=? AND receiver_id=c.contact_id)
           OR (sender_id=c.contact_id AND receiver_id=?)
        ORDER BY created_at DESC LIMIT 1) AS last_at,
      (SELECT COUNT(*) FROM messages
        WHERE sender_id=c.contact_id AND receiver_id=? AND is_read=0) AS unread
    FROM (
      SELECT DISTINCT CASE WHEN sender_id=? THEN receiver_id ELSE sender_id END AS contact_id
      FROM messages
      WHERE sender_id=? OR receiver_id=?
    ) c
    LEFT JOIN users u ON u.id = c.contact_id
    ORDER BY last_at DESC`,
    [userId,userId,userId,userId,userId,userId,userId,userId]),
  markRead: (senderId, receiverId) =>
    run('UPDATE messages SET is_read=1 WHERE sender_id=? AND receiver_id=?', [senderId, receiverId]),
  unreadCount: userId => get('SELECT COUNT(*) AS n FROM messages WHERE receiver_id=? AND is_read=0', [userId]),
};

// ─── NOTIFICATIONS ───────────────────────────────────────
const Notifications = {
  create: (userId, type, title, body, link) =>
    run('INSERT INTO notifications(user_id,type,title,body,link) VALUES(?,?,?,?,?)', [userId, type, title, body, link||null]),
  list: userId => all('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50', [userId]),
  markRead: (id, userId) => run('UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?', [id, userId]),
  markAllRead: userId => run('UPDATE notifications SET is_read=1 WHERE user_id=?', [userId]),
  unreadCount: userId => get('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND is_read=0', [userId]),
};

// ─── FAVORITES ───────────────────────────────────────────
const Favorites = {
  toggle: async (userId, itemId) => {
    const ex = await get('SELECT id FROM favorites WHERE user_id=? AND item_id=?', [userId, itemId]);
    if (ex) { await run('DELETE FROM favorites WHERE id=?', [ex.id]); return false; }
    await run('INSERT INTO favorites(user_id,item_id) VALUES(?,?)', [userId, itemId]);
    return true;
  },
  list: userId => all(`${ITEM_JOINS} JOIN favorites f ON f.item_id=items.id WHERE f.user_id=? ORDER BY f.created_at DESC`, [userId]),
  check: (userId, itemId) => get('SELECT id FROM favorites WHERE user_id=? AND item_id=?', [userId, itemId]),
};

// ─── RATINGS ─────────────────────────────────────────────
const Ratings = {
  give: async (fromId, toId, score, comment) => {
    await run('INSERT OR REPLACE INTO ratings(from_id,to_id,score,comment) VALUES(?,?,?,?)', [fromId, toId, score, comment||null]);
    const avg = await get('SELECT AVG(score) AS avg, COUNT(*) AS cnt FROM ratings WHERE to_id=?', [toId]);
    await run('UPDATE users SET rating=?,rating_count=? WHERE id=?', [Math.round(avg.avg * 10) / 10, avg.cnt, toId]);
  },
  forUser: userId => all('SELECT r.*, u.name AS from_name FROM ratings r LEFT JOIN users u ON u.id=r.from_id WHERE r.to_id=? ORDER BY r.created_at DESC', [userId]),
};

const Reports = {
  create: (itemId, userId, reason, comment) =>
    run('INSERT INTO reports(item_id,user_id,reason,comment) VALUES(?,?,?,?)',
      [itemId, userId, reason, comment||null]),
  list: (status='pending') => all(`
    SELECT r.*, i.title AS item_title, u.name AS reporter_name
    FROM reports r
    LEFT JOIN items i ON i.id=r.item_id
    LEFT JOIN users u ON u.id=r.user_id
    WHERE r.status=? ORDER BY r.created_at DESC`, [status]),
  setStatus: (id, status) => run('UPDATE reports SET status=? WHERE id=?', [status, id]),
  countByItem: itemId => get('SELECT COUNT(*) AS n FROM reports WHERE item_id=?', [itemId]),
};

// ─── ПОДПИСКИ НА КАТЕГОРИЮ/РАЙОН ─────────────────────────
const Subscriptions = {
  create: (userId, categorySlug, locationKeyword, type) =>
    run(
      'INSERT INTO subscriptions(user_id, category_slug, location_keyword, item_type) VALUES(?,?,?,?)',
      [userId, categorySlug || null, locationKeyword || null, type || null],
    ),
  list: userId =>
    all('SELECT * FROM subscriptions WHERE user_id=? ORDER BY created_at DESC', [userId]),
  delete: (id, userId) =>
    run('DELETE FROM subscriptions WHERE id=? AND user_id=?', [id, userId]),
  findMatching: (categorySlug, locationText, itemType) =>
    all(`SELECT s.*, u.email, u.name, u.id AS user_id FROM subscriptions s
         LEFT JOIN users u ON u.id = s.user_id
         WHERE (s.category_slug IS NULL OR s.category_slug = ?)
           AND (s.location_keyword IS NULL OR LOWER(?) LIKE '%' || LOWER(s.location_keyword) || '%')
           AND (s.item_type IS NULL OR s.item_type = ?)
           AND u.is_banned = 0`,
      [categorySlug, locationText || '', itemType]),
};

// ─── ЖАЛОБЫ НА ПОЛЬЗОВАТЕЛЕЙ ─────────────────────────────
const UserReports = {
  create: (reporterId, targetId, reason, comment) =>
    run(
      'INSERT INTO user_reports(reporter_id, target_id, reason, comment) VALUES(?,?,?,?)',
      [reporterId, targetId, reason, comment || null],
    ),
  list: (status = 'pending') =>
    all(`SELECT ur.*, ru.name AS reporter_name, tu.name AS target_name, tu.email AS target_email
         FROM user_reports ur
         LEFT JOIN users ru ON ru.id = ur.reporter_id
         LEFT JOIN users tu ON tu.id = ur.target_id
         WHERE ur.status=? ORDER BY ur.created_at DESC`, [status]),
  setStatus: (id, status) =>
    run('UPDATE user_reports SET status=? WHERE id=?', [status, id]),
};

// ─── ITEM_PHOTOS ──────────────────────────────────────────
const ItemPhotos = {
  addAll: async (itemId, urls) => {
    for (let i = 0; i < urls.length; i++) {
      await run(
        'INSERT INTO item_photos(item_id, url, sort_order) VALUES(?,?,?)',
        [itemId, urls[i], i],
      );
    }
  },
  list: (itemId) => all(
    'SELECT url FROM item_photos WHERE item_id=? ORDER BY sort_order ASC', [itemId]
  ),
  deleteAll: (itemId) => run('DELETE FROM item_photos WHERE item_id=?', [itemId]),
};

module.exports = { Users, Categories, Items, ItemPhotos, Matches, Claims, Messages, Notifications, Favorites, Ratings, Reports, Subscriptions, UserReports };

