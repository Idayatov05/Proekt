const fs      = require('fs');
const path    = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt  = require('bcryptjs');

const DB_PATH     = path.join(__dirname, '..', '..', 'database', 'findit.db');
const SCHEMA_PATH = path.join(__dirname, '..', '..', 'database', 'schema.sql');

const db = new sqlite3.Database(DB_PATH);

const run = (sql, p = []) => new Promise((res, rej) =>
  db.run(sql, p, function (e) { e ? rej(e) : res({ id: this.lastID, changes: this.changes }); }));

const get = (sql, p = []) => new Promise((res, rej) =>
  db.get(sql, p, (e, row) => e ? rej(e) : res(row)));

const all = (sql, p = []) => new Promise((res, rej) =>
  db.all(sql, p, (e, rows) => e ? rej(e) : res(rows)));

const exec = sql => new Promise((res, rej) =>
  db.exec(sql, e => e ? rej(e) : res()));

async function seed() {
  const cats = await get('SELECT COUNT(*) AS n FROM categories');
  if (!cats.n) {
    const list = [
      ['electronics','Электроника','📱'],
      ['documents','Документы','📄'],
      ['keys','Ключи','🔑'],
      ['bags','Сумки','👜'],
      ['clothes','Одежда','👕'],
      ['jewelry','Украшения','💍'],
      ['pets','Животные','🐾'],
      ['cards','Карты/Пропуска','💳'],
      ['money','Кошельки/Деньги','💰'],
      ['other','Другое','📦'],
    ];
    for (const [slug, name, icon] of list)
      await run('INSERT INTO categories(slug,name,icon) VALUES(?,?,?)', [slug, name, icon]);
  }

  const us = await get('SELECT COUNT(*) AS n FROM users');
  if (!us.n) {
    const adminHash = bcrypt.hashSync('admin123', 10);
    const userHash  = bcrypt.hashSync('user123',  10);
    await run('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',
      ['Администратор','admin@findit.kz', adminHash, 'admin']);
    await run('INSERT INTO users(name,email,password_hash,role,phone) VALUES(?,?,?,?,?)',
      ['Айдар Сейткали','user@findit.kz', userHash, 'user', '+7 701 123 45 67']);

    const docs  = await get("SELECT id FROM categories WHERE slug='documents'");
    const elec  = await get("SELECT id FROM categories WHERE slug='electronics'");
    const keys  = await get("SELECT id FROM categories WHERE slug='keys'");
    const bags  = await get("SELECT id FROM categories WHERE slug='bags'");

    const items = [
      [2,'lost','Потерян студенческий билет','Синий студенческий билет НУ, имя Айдар Сейткали, предположительно оставил в автобусе №18.',
        docs.id,'','синий','Автобус №18, ул. Кабанбай батыра',51.1605,71.4704,'2026-03-15','','','Вознаграждение 5000 тг'],
      [1,'found','Найден студенческий билет','Найден студенческий билет синего цвета возле остановки «Байтерек».',
        docs.id,'','синий','Остановка Байтерек, пр. Туран',51.1280,71.4307,'2026-03-16','','',''],
      [2,'lost','Потерян iPhone 14 Pro','Чёрный iPhone 14 Pro в чёрном чехле. Есть трещина на правом углу экрана.',
        elec.id,'Apple','чёрный','ТРЦ Мега, 1 этаж',51.1697,71.4491,'2026-03-18','','APL-IP14-2024','Вознаграждение 20000 тг'],
      [1,'found','Найдены ключи с брелоком','Связка из 3 ключей с оранжевым брелоком в виде машины.',
        keys.id,'','серебристый','Парк Жасыл аймак',51.1793,71.4462,'2026-03-19','','',''],
      [2,'lost','Потеряна чёрная сумка','Чёрная кожаная сумка через плечо, внутри ноутбук и зарядка.',
        bags.id,'Zara','чёрный','Кинотеатр Арман',51.1622,71.4306,'2026-03-20','','','Вознаграждение 10000 тг'],
    ];

    for (const [oid,type,title,desc,catId,brand,color,loc,lat,lon,date,img,serial,reward] of items) {
      await run(`INSERT INTO items(owner_id,type,title,description,category_id,brand,color,
        location_text,latitude,longitude,event_date,image_url,serial_number,reward,status,moderation_status)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'open','approved')`,
        [oid,type,title,desc,catId,brand,color,loc,lat,lon,date,img,serial,reward]);
    }

    await run("INSERT INTO notifications(user_id,type,title,body) VALUES(?,?,?,?)",
      [2,'info','Добро пожаловать в FindIt!',
       'Создавайте объявления о потерянных и найденных вещах. Система автоматически найдёт совпадения.']);
  }
}

async function initDb() {
  await exec('PRAGMA foreign_keys = ON;');
  await exec('PRAGMA journal_mode = WAL;');
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  await exec(schema);

  // ── Миграции (добавляем колонки если их нет) ─────────────
  try { await run('ALTER TABLE users ADD COLUMN reset_token TEXT'); } catch {}
  try { await run('ALTER TABLE users ADD COLUMN reset_token_expires TEXT'); } catch {}
  try { await run('ALTER TABLE items ADD COLUMN archive_warned INTEGER NOT NULL DEFAULT 0'); } catch {}
  try { await run('ALTER TABLE users ADD COLUMN email_verified INTEGER NOT NULL DEFAULT 0'); } catch {}
  try { await run('ALTER TABLE users ADD COLUMN email_verify_token TEXT'); } catch {}
  try { await run('ALTER TABLE items ADD COLUMN status TEXT CHECK(status IN(\'open\',\'closed\',\'returned\',\'archived\')) WHERE status IS NULL'); } catch {}
  // v7 migrations
  try { await run('ALTER TABLE users ADD COLUMN city TEXT'); } catch {}
  try { await run(`CREATE TABLE IF NOT EXISTS item_photos (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id    INTEGER NOT NULL,
    url        TEXT    NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
  )`); } catch {}
  try { await run('CREATE INDEX IF NOT EXISTS idx_item_photos_item ON item_photos(item_id)'); } catch {}

  // Новые таблицы (если БД старая — создаём)
  await exec(`CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    category_slug TEXT,
    location_keyword TEXT,
    item_type TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`);
  await exec(`CREATE TABLE IF NOT EXISTS user_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reporter_id INTEGER NOT NULL,
    target_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    comment TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(reporter_id, target_id)
  )`);

  // ── FTS5 полнотекстовый поиск ─────────────────────────────
  // Создаём виртуальную таблицу один раз; unicode61 понимает кириллицу
  await exec(`CREATE VIRTUAL TABLE IF NOT EXISTS items_fts USING fts5(
    title, description, brand, color, location_text,
    tokenize='unicode61 remove_diacritics 1'
  )`);

  // Триггеры синхронизации FTS ↔ items
  await exec(`CREATE TRIGGER IF NOT EXISTS items_fts_ai
    AFTER INSERT ON items BEGIN
      INSERT INTO items_fts(rowid, title, description, brand, color, location_text)
      VALUES(new.id,
        COALESCE(new.title,''), COALESCE(new.description,''),
        COALESCE(new.brand,''), COALESCE(new.color,''),
        COALESCE(new.location_text,''));
    END`);

  await exec(`CREATE TRIGGER IF NOT EXISTS items_fts_au
    AFTER UPDATE ON items BEGIN
      DELETE FROM items_fts WHERE rowid = old.id;
      INSERT INTO items_fts(rowid, title, description, brand, color, location_text)
      VALUES(new.id,
        COALESCE(new.title,''), COALESCE(new.description,''),
        COALESCE(new.brand,''), COALESCE(new.color,''),
        COALESCE(new.location_text,''));
    END`);

  await exec(`CREATE TRIGGER IF NOT EXISTS items_fts_ad
    AFTER DELETE ON items BEGIN
      DELETE FROM items_fts WHERE rowid = old.id;
    END`);

  // Заполняем FTS для уже существующих записей (idempotent)
  await exec(`INSERT OR IGNORE INTO items_fts(rowid, title, description, brand, color, location_text)
    SELECT id, COALESCE(title,''), COALESCE(description,''),
           COALESCE(brand,''), COALESCE(color,''), COALESCE(location_text,'')
    FROM items`);

  await seed();
}

module.exports = { db, run, get, all, exec, initDb };
