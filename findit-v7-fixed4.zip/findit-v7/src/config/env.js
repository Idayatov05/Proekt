require('dotenv').config();

module.exports = {
  PORT:           Number(process.env.PORT)          || 3000,
  JWT_SECRET:     process.env.JWT_SECRET            || 'dev-secret-change-in-production-32chars!!',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN        || '7d',
  NODE_ENV:       process.env.NODE_ENV              || 'development',

  // Email / SMTP (nodemailer)
  // Set these in .env to enable real email sending.
  // Without them the app falls back to console.log (dev mode).
  SMTP_HOST:   process.env.SMTP_HOST   || '',   // e.g. smtp.resend.com or smtp.gmail.com
  SMTP_PORT:   Number(process.env.SMTP_PORT) || 465,
  SMTP_SECURE: process.env.SMTP_SECURE !== 'false', // true by default (SSL/TLS)
  SMTP_USER:   process.env.SMTP_USER   || '',   // SMTP login / API key
  SMTP_PASS:   process.env.SMTP_PASS   || '',   // SMTP password
  EMAIL_FROM:  process.env.EMAIL_FROM  || 'FindIt <noreply@findit.kz>',
};
