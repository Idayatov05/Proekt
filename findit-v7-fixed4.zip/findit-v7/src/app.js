const path    = require('path');
const express = require('express');
const helmet  = require('helmet');
const cors    = require('cors');
const rateLimit = require('express-rate-limit');
const { notFound, errorHandler } = require('./middleware/error');
const routes  = require('./routes');

const app = express();
const pub = path.join(__dirname, '..', 'public');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: '*' }));

// Строгий лимит только для сброса пароля — защита от спама письмами
app.use('/api/auth/forgot-password', rateLimit({
  windowMs: 60 * 60 * 1000, max: 5,
  message: { error: 'Слишком много попыток сброса пароля. Попробуйте через час.' },
}));
// Лимит для всей авторизации (логин, регистрация)
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 30,
  message: { error: 'Слишком много запросов. Попробуйте через 15 минут.' } }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 300 }));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

app.use(express.static(pub));

app.use('/api', routes);

// BUG FIX: regex /^\/(\\w+).*/ requires at least one word-char after '/',
// so path '/' produced file='/.html' (no match → returned '/' unchanged) and
// fell through to the error callback every time. Now '/' is handled explicitly.
const pages = ['/', '/auth', '/dashboard', '/admin', '/item', '/map'];
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  if (req.path === '/') return res.sendFile(path.join(pub, 'index.html'));
  const matched = pages.find(p => req.path === p || req.path.startsWith(p + '/'));
  const file = matched
    ? req.path.replace(/^\/(\w+).*/, '$1') + '.html'
    : 'index.html';
  const fp = path.join(pub, file);
  res.sendFile(fp, err => err ? res.sendFile(path.join(pub, 'index.html')) : null);
});

app.use(notFound);
app.use(errorHandler);

module.exports = app;
