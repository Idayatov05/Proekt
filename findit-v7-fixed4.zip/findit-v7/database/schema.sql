PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE,
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  avatar        TEXT,
  phone         TEXT,
  bio           TEXT,
  city          TEXT,
  rating        REAL    NOT NULL DEFAULT 5.0,
  rating_count  INTEGER NOT NULL DEFAULT 0,
  total_points  INTEGER NOT NULL DEFAULT 0,
  is_banned           INTEGER NOT NULL DEFAULT 0,
  created_at          TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reset_token         TEXT,
  reset_token_expires TEXT
);

CREATE TABLE IF NOT EXISTS categories (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  icon TEXT
);

CREATE TABLE IF NOT EXISTS items (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id          INTEGER NOT NULL,
  type              TEXT    NOT NULL CHECK (type IN ('lost','found')),
  title             TEXT    NOT NULL,
  description       TEXT    NOT NULL,
  category_id       INTEGER NOT NULL,
  brand             TEXT,
  color             TEXT,
  location_text     TEXT    NOT NULL,
  latitude          REAL,
  longitude         REAL,
  event_date        TEXT    NOT NULL,
  image_url         TEXT,
  serial_number     TEXT,
  reward            TEXT,
  contact_info      TEXT,
  views             INTEGER NOT NULL DEFAULT 0,
  status            TEXT    NOT NULL DEFAULT 'open'   CHECK (status IN ('open','closed','returned')),
  moderation_status TEXT    NOT NULL DEFAULT 'pending' CHECK (moderation_status IN ('pending','approved','rejected')),
  reject_reason     TEXT,
  created_at        TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id)    REFERENCES users(id)      ON DELETE CASCADE,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS matches (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  lost_item_id  INTEGER NOT NULL,
  found_item_id INTEGER NOT NULL,
  score         INTEGER NOT NULL,
  status        TEXT    NOT NULL DEFAULT 'suggested' CHECK (status IN ('suggested','confirmed','rejected')),
  created_at    TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (lost_item_id)  REFERENCES items(id) ON DELETE CASCADE,
  FOREIGN KEY (found_item_id) REFERENCES items(id) ON DELETE CASCADE,
  UNIQUE(lost_item_id, found_item_id)
);

CREATE TABLE IF NOT EXISTS claims (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id      INTEGER NOT NULL,
  requester_id INTEGER NOT NULL,
  proof        TEXT    NOT NULL,
  status       TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  admin_note   TEXT,
  created_at   TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id)      REFERENCES items(id) ON DELETE CASCADE,
  FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id   INTEGER NOT NULL,
  receiver_id INTEGER NOT NULL,
  item_id     INTEGER,
  body        TEXT    NOT NULL,
  is_read     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id)     REFERENCES items(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  type       TEXT    NOT NULL DEFAULT 'info',
  title      TEXT    NOT NULL,
  body       TEXT    NOT NULL,
  link       TEXT,
  is_read    INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS favorites (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  item_id    INTEGER NOT NULL,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
  UNIQUE(user_id, item_id)
);

CREATE TABLE IF NOT EXISTS ratings (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id    INTEGER NOT NULL,
  to_id      INTEGER NOT NULL,
  score      INTEGER NOT NULL CHECK (score BETWEEN 1 AND 5),
  comment    TEXT,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (from_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (to_id)   REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(from_id, to_id)
);

CREATE INDEX IF NOT EXISTS idx_items_owner      ON items(owner_id);
CREATE INDEX IF NOT EXISTS idx_items_type       ON items(type);
CREATE INDEX IF NOT EXISTS idx_items_moderation ON items(moderation_status);
CREATE INDEX IF NOT EXISTS idx_items_status     ON items(status);
CREATE INDEX IF NOT EXISTS idx_matches_lost     ON matches(lost_item_id);
CREATE INDEX IF NOT EXISTS idx_matches_found    ON matches(found_item_id);
CREATE INDEX IF NOT EXISTS idx_notif_user       ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_messages_recv    ON messages(receiver_id, is_read);
CREATE INDEX IF NOT EXISTS idx_favorites        ON favorites(user_id);

-- ─── GAMIFICATION ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_points (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  action     TEXT    NOT NULL,
  points     INTEGER NOT NULL DEFAULT 0,
  ref_id     INTEGER,
  note       TEXT,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_badges (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  badge_slug TEXT    NOT NULL,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(user_id, badge_slug)
);

-- ─── PUSH SUBSCRIPTIONS ──────────────────────────────────
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  endpoint   TEXT    NOT NULL UNIQUE,
  p256dh     TEXT    NOT NULL,
  auth       TEXT    NOT NULL,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_points_user  ON user_points(user_id);
CREATE INDEX IF NOT EXISTS idx_badges_user  ON user_badges(user_id);
CREATE INDEX IF NOT EXISTS idx_push_user    ON push_subscriptions(user_id);

-- ─── REPORTS (жалобы) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS reports (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id    INTEGER NOT NULL,
  user_id    INTEGER NOT NULL,
  reason     TEXT    NOT NULL CHECK (reason IN ('spam','inappropriate','duplicate','fake','other')),
  comment    TEXT,
  status     TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','reviewed','dismissed')),
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id)  REFERENCES items(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(item_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_reports_item   ON reports(item_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);

-- ─── SUBSCRIPTIONS (подписки на категорию/район) ─────────
CREATE TABLE IF NOT EXISTS subscriptions (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL,
  category_slug    TEXT,
  location_keyword TEXT,
  item_type        TEXT CHECK (item_type IN ('lost','found',NULL)),
  created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_subs_user ON subscriptions(user_id);

-- ─── USER_REPORTS (жалобы на пользователей) ──────────────
CREATE TABLE IF NOT EXISTS user_reports (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  reporter_id INTEGER NOT NULL,
  target_id   INTEGER NOT NULL,
  reason      TEXT NOT NULL CHECK (reason IN ('spam','fraud','abusive','fake','other')),
  comment     TEXT,
  status      TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','reviewed','dismissed')),
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (target_id)   REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE(reporter_id, target_id)
);
CREATE INDEX IF NOT EXISTS idx_user_reports_target ON user_reports(target_id);
CREATE INDEX IF NOT EXISTS idx_user_reports_status ON user_reports(status);

-- ─── ITEM_PHOTOS (галерея фотографий к объявлению) ─────────
CREATE TABLE IF NOT EXISTS item_photos (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  item_id    INTEGER NOT NULL,
  url        TEXT    NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_item_photos_item ON item_photos(item_id);
