/**
 * FindIt — i18n · RU / KZ / EN
 * ─────────────────────────────
 * API:
 *   t(key)           → переведённая строка (fallback → RU → key)
 *   setLang(lang)    → сменить язык, сохранить в localStorage, обновить DOM
 *   getLang()        → текущий код языка
 *   applyI18n()      → принудительно обновить все [data-i18n] элементы
 *
 * HTML-атрибуты:
 *   data-i18n="key"           → innerHTML = t(key)
 *   data-i18n-attr="title"    → el.setAttribute('title', t(key))
 *   data-i18n-ph="key"        → el.placeholder = t(key)
 *   data-i18n-title="key"     → el.title = t(key)
 */

const TRANSLATIONS = {
  /* ─────────────── РУССКИЙ ─────────────── */
  ru: {
    // навигация
    nav_home: 'Главная', nav_map: 'Карта', nav_cabinet: 'Кабинет',
    nav_login: 'Войти', nav_logout: 'Выйти', nav_admin: 'Админ',
    lang_switcher_label: 'Язык',

    // hero
    hero_tag: '🔍 Бюро находок Казахстана',
    hero_title: 'Найдите потерянное. Верните найденное.',
    hero_sub: 'Платформа для поиска потерянных вещей. Создайте объявление — система автоматически найдёт совпадения.',
    hero_btn_create: '+ Создать объявление', hero_btn_browse: 'Смотреть объявления',
    hero_lost: '🔴 Потерял вещь', hero_found: '🟢 Нашёл вещь',

    // статистика
    stat_lost: 'Потеряно', stat_found: 'Найдено', stat_returned: 'Возвращено', stat_users: 'Пользователей',

    // фильтры
    search_ph: 'Поиск по названию…', filter_all_types: 'Все типы', filter_all_cats: 'Все категории',
    filter_all: 'Все', filter_lost: 'Потеряно', filter_found: 'Найдено',
    filter_open: 'Открытые', filter_closed: 'Закрытые', filter_color_ph: 'Цвет',
    btn_search: 'Найти', btn_reset: 'Сбросить',
    sort_label: 'Сортировка:', sort_new: 'Сначала новые', sort_event_date: 'По дате потери', sort_old: 'Сначала старые',
    no_items: 'Ничего не найдено', ads_title: 'Объявления',
    btn_prev: '← Назад', btn_next: 'Вперёд →', page_of: 'из', page_label: 'Стр.',

    // создание объявления
    create_title: 'Создать объявление',
    create_login_msg: 'Чтобы создать объявление, <a href="/auth.html">войдите или зарегистрируйтесь</a>.',
    form_type: 'Тип *', form_type_lost: '🔴 Потеряно', form_type_found: '🟢 Найдено',
    form_category: 'Категория *', form_title: 'Название *',
    form_title_ph: 'Например: Чёрный кошелёк с монограммой',
    form_desc: 'Описание *', form_desc_ph: 'Подробно опишите предмет — особые приметы, содержимое…',
    form_color: 'Цвет', form_color_ph: 'Чёрный, синий…',
    form_brand: 'Бренд/марка', form_brand_ph: 'Apple, Nike…',
    form_location: 'Место (улица, район) *', form_location_ph: 'ул. Кабанбай батыра, ТРЦ Мега…',
    form_date: 'Дата события *', form_serial: 'Серийный номер (если есть)', form_serial_ph: 'IMEI, S/N…',
    form_reward: 'Вознаграждение', form_reward_ph: '5000 тг или по договорённости',
    form_contact: 'Контактные данные', form_contact_ph: '+7 777 123 45 67 или @telegram',
    form_photo: 'Фото предмета', form_submit: 'Отправить на модерацию',
    form_moderation_note: 'Объявление появится после проверки администратором.',

    // карточки объявлений
    items_lost: 'Потеряно', items_found: 'Найдено', items_returned: 'Возвращено',
    item_views: 'просмотров', item_date: 'Дата', item_place: 'Место',
    item_category: 'Категория', item_color: 'Цвет', item_brand: 'Бренд',
    item_serial: 'Серийный №', item_contact: 'Контакт',
    item_reward: 'Вознаграждение', item_author: 'Автор',
    item_matches: '🔍 Похожие совпадения', item_actions: 'Действия',
    btn_msg: '💬 Написать автору', btn_fav_add: '🤍 В избранное', btn_fav_rm: '❤️ В избранном',
    btn_claim: '🔐 Подтвердить владение', btn_share: '🔗 Поделиться', btn_report: '🚩 Пожаловаться',
    back: '← Назад', login_to_act: 'Войдите чтобы связаться',
    share_copied: 'Ссылка скопирована!', share_error: 'Не удалось скопировать ссылку',

    // жалоба
    report_title: '🚩 Жалоба на объявление', report_reason: 'Причина',
    report_spam: 'Спам', report_inapp: 'Неприемлемый контент',
    report_dup: 'Дубликат', report_fake: 'Мошенничество', report_other: 'Другое',
    report_comment: 'Комментарий (необязательно)', report_ph: 'Опишите проблему подробнее…',
    report_send: 'Отправить жалобу', report_cancel: 'Отмена', report_ok: 'Жалоба принята!',

    // авторизация
    login_title: 'Вход', reg_title: 'Регистрация',
    tab_login: 'Войти', tab_register: 'Регистрация',
    email_label: 'Email', email_ph: 'your@email.com',
    pass_label: 'Пароль', pass_ph: '••••••••',
    name_label: 'Имя', name_ph: 'Ваше имя',
    btn_login: 'Войти', btn_register: 'Зарегистрироваться',
    no_acc: 'Нет аккаунта?', has_acc: 'Уже есть аккаунт?', forgot_pass: 'Забыл пароль?',

    // дашборд / сайдбар
    sidebar_role_user: 'Пользователь', sidebar_role_admin: 'Администратор',
    dash_myitems: '📋 Мои объявления', dash_matches: '🔍 Совпадения',
    dash_msgs: '💬 Сообщения', dash_notifs: '🔔 Уведомления',
    dash_fav: '❤️ Избранное', dash_claims: '📬 Заявки',
    dash_game: '🏆 Достижения', dash_leaders: '📊 Лидеры',
    dash_profile: '⚙️ Профиль', dash_adminlink: '🛡 Админ-панель', new_item: '+ Новое',

    // панели дашборда
    pane_myitems: 'Мои объявления', pane_matches: 'Совпадения',
    pane_matches_sub: 'Алгоритм нашёл похожие объявления. Чем выше %, тем выше вероятность.',
    pane_msgs: 'Сообщения', pane_msgs_empty: 'Выберите диалог',
    pane_notifs: 'Уведомления', pane_notifs_readall: 'Прочитать все',
    pane_fav: 'Избранное', pane_claims: 'Мои заявки',
    pane_claims_sub: 'Подайте заявку на найденный предмет с доказательством владения.',
    pane_game: '🏆 Достижения', pane_game_sub: 'Зарабатывайте очки и получайте бейджи за активность.',
    pane_badges: '🎖 Бейджи', pane_points_hist: '📜 История очков',
    pane_leaders: '📊 Таблица лидеров', pane_leaders_sub: 'Топ пользователей по активности и возвратам.',
    pane_profile: 'Профиль',

    // профиль
    prof_name: 'Имя', prof_phone: 'Телефон', prof_phone_ph: '+7 777 000 00 00',
    prof_bio: 'О себе', prof_bio_ph: 'Пара слов о вас…', prof_save: 'Сохранить',

    // заявки
    claim_item_id: 'ID объявления', claim_item_ph: 'Например: 3',
    claim_proof: 'Доказательство владения',
    claim_proof_ph: 'Опишите содержимое, серийный номер, фото чека…',
    claim_submit: 'Отправить заявку',

    // push
    push_title: '🔔 Push-уведомления', push_sub: 'Получайте уведомления о совпадениях',
    push_checking: 'Проверка…', push_loading: 'Загрузка…',
    push_enabled_status: '✅ Push-уведомления включены',
    push_disabled_status: '🔕 Push-уведомления выключены',
    push_blocked_status: '🚫 Уведомления заблокированы в браузере. Разрешите в настройках.',
    push_enable: 'Включить уведомления',
    push_disable: 'Отключить уведомления',
    push_enable_toast: 'Push-уведомления включены!',
    push_disable_toast: 'Push-уведомления отключены',
    push_enable_err: 'Не удалось включить уведомления',

    // статусы
    status_open: 'Активно', status_closed: 'Закрыто', status_returned: 'Возвращено',
    status_lost: 'Потеряно', status_found: 'Найдено', status_pending: 'На модерации',

    // карта
    map_legend_lost: 'Потеряно', map_legend_found: 'Найдено',
    map_subtitle: 'Места потерь и находок на карте Казахстана',
    map_filter_title: 'Фильтр',
    map_filter_all: 'Все объявления',
    map_filter_lost: 'Только потеряно',
    map_filter_found: 'Только найдено',
    map_filter_all_cats: 'Все категории',
    map_filter_apply: 'Применить',
    map_legend_title: 'Легенда',
    map_loading: 'Загрузка…',
    map_count: 'объявлений',
    map_open_item: 'Открыть объявление →',

    // пустые состояния дашборда
    matches_empty: 'Совпадений пока нет',
    msgs_no_threads: 'Нет диалогов',
    notifs_empty: 'Нет уведомлений',
    fav_empty: 'Нет избранного',
    my_claims_empty: 'Вы ещё не подавали заявок.',
    points_history_empty: 'Пока нет активности',

    // админ — жёстко прописанные строки
    admin_tab_user_reports: '👤 Жалобы на пользователей',
    admin_tab_analytics: '📊 Аналитика',
    admin_bulk_approve: '✅ Одобрить выбранные',
    admin_bulk_reject: '❌ Отклонить выбранные',
    admin_user_reports_h2: '👤 Жалобы на пользователей',
    admin_all_clear: 'Все проверено!',
    admin_claims_empty: 'Нет заявок',
    admin_analytics_title: '📊 Аналитика за 30 дней',
    admin_chart_items: 'Новые объявления',
    admin_chart_returns: 'Возвраты',
    admin_chart_users: 'Регистрации',

    // тема / общее
    theme_dark: '🌙', theme_light: '☀️',
    loading: 'Загрузка…', error_generic: 'Что-то пошло не так',
    saved: 'Сохранено', deleted: 'Удалено', sent: 'Отправлено!',
    cancel: 'Отмена', close: 'Закрыть', yes: 'Да', no: 'Нет',
    reject_reason: 'Причина отклонения (необязательно):',
    reject_reason_req: 'Причина отклонения:',

    // страница пользователя
    user_profile: 'Профиль пользователя',
    user_items: 'Объявления пользователя',
    user_ratings: 'Отзывы',
    user_report: 'Пожаловаться на пользователя',
    user_report_reason_ph: '— Причина —',
    user_report_spam: 'Спам', user_report_fraud: 'Мошенничество',
    user_report_abusive: 'Оскорбления', user_report_fake: 'Фейк / поддельный аккаунт',
    user_report_other: 'Другое',
    user_report_comment_ph: 'Комментарий (необязательно)',
    user_report_submit: 'Отправить', user_loading: 'Загрузка профиля…',

    // email подтверждение
    verify_title: 'Подтверждение email…',
    verify_no_token: 'Неверная ссылка',
    verify_no_token_msg: 'Токен подтверждения отсутствует.',
    verify_success_title: 'Email подтверждён!',
    verify_success_msg: 'Теперь вы можете пользоваться всеми функциями FindIt.',
    verify_error_title: 'Ошибка подтверждения',
    verify_home: 'На главную',

    // дашборд — поиск
    myitems_search_ph: 'Поиск по названию…',
    fav_search_ph: 'Поиск в избранном…',

    // дашборд — мои заявки
    my_claims_title: '📬 Мои поданные заявки',

    // дашборд — подписки (сайдбар + панель)
    dash_subscriptions: '🔔 Подписки',
    pane_subscriptions: '🔔 Подписки',
    sub_pane_desc: 'Получайте уведомления, когда появляются новые объявления по вашим критериям',
    sub_new_title: 'Новая подписка',
    sub_type_any: 'Любой тип',
    sub_type_lost_label: '🔍 Потеряно',
    sub_type_found_label: '📦 Найдено',
    sub_location_ph: 'Район/место (например: Алмалинский)',
    sub_cat_any: 'Любая категория',
    sub_add_btn: '+ Добавить подписку',
    sub_empty: 'Нет подписок. Добавьте первую выше.',
    sub_fill_error: 'Укажите хотя бы один критерий',
    sub_added: 'Подписка добавлена!',

    // дашборд — аватар
    prof_avatar_label: 'Фото профиля',
    prof_avatar_upload: '📷 Загрузить фото',
    prof_avatar_hint: 'JPG, PNG, WEBP · до 5 МБ',

    // дашборд — безопасность
    security_title: '🔒 Безопасность',
    cur_pass: 'Текущий пароль',
    cur_pass_ph: 'Введите текущий пароль',
    new_pass: 'Новый пароль',
    new_pass_ph: 'Минимум 6 символов',
    new_pass2: 'Повторите новый пароль',
    new_pass2_ph: 'Повторите пароль',
    change_pass_btn: 'Сменить пароль',

    // статусы заявок / совпадений
    status_pending: '🕐 Ожидает',
    status_approved_claim: '✅ Одобрена',
    status_rejected_claim: '❌ Отклонена',
    match_rejected: 'Совпадение отклонено',

    // админ
    admin_title: '🛡 Административная панель', admin_refresh: '↻ Обновить',
    admin_stats_total: 'Всего', admin_stats_lost: 'Потеряно',
    admin_stats_found: 'Найдено', admin_stats_pending: 'На модерации', admin_stats_users: 'Пользователей',
    admin_tab_mod: 'Модерация', admin_tab_all: 'Все объявления',
    admin_tab_users: 'Пользователи', admin_tab_claims: 'Заявки', admin_tab_reports: '🚩 Жалобы',
    admin_pend_h2: 'Ожидают модерации', admin_all_h2: 'Все объявления',
    admin_users_h2: 'Пользователи', admin_claims_h2: 'Заявки на возврат',
    admin_reports_h2: '🚩 Жалобы на объявления',
    admin_filter_all_status: 'Все статусы', admin_filter_pending: 'На модерации',
    admin_filter_approved: 'Одобренные', admin_filter_rejected: 'Отклонённые',
    admin_filter_all_types: 'Все типы', admin_filter_lost: 'Потеряно',
    admin_filter_found: 'Найдено', admin_filter_apply: 'Применить',
    admin_rep_new: 'Новые', admin_rep_reviewed: 'Рассмотрены', admin_rep_dismissed: 'Отклонены',
    mod_approved: '✅ Одобрено', mod_rejected: '❌ Отклонено',
    mod_approve_toast: 'Одобрено ✅', mod_reject_toast: 'Отклонено ❌', mod_return_toast: 'Отмечено 🎉',
    mod_bulk_approve_toast: '✅ Одобрено', mod_bulk_reject_toast: 'Отклонено',

    // профиль — город
    prof_city: 'Город / район', prof_city_ph: 'Алматы, Казахстан',
    prof_city_detect: 'Определить по GPS',

    // профиль пользователя — статистика и бейджи
    user_stat_items: 'Объявлений', user_stat_returned: 'Возвращено',
    user_stat_rating: 'Рейтинг', user_stat_points: 'Очков',
    user_badge_legend: 'Легенда', user_badge_active: 'Активный',
    user_badge_patron: 'Меценат', user_badge_helper: 'Помог вернуть',
    user_badge_expert: 'Опытный', user_badge_pioneer: 'Первооткрыватель',
    user_level_next: 'До уровня', user_level_max: '🏆 Максимальный уровень достигнут!',
    user_reviews: 'Отзывы',

    // геолокация
    geo_detecting: '⏳ Определяем…',
    geo_nearby_btn: '📍 Рядом со мной',
    geo_nearby_hide: '📍 Скрыть моё место',
    geo_my_location: '🎯 Моё местоположение',
    geo_radius_label: 'Радиус:',
    geo_found: 'Найдено {n} объявлений в радиусе {r} км',
    geo_empty: 'Объявлений в радиусе {r} км не найдено',
    geo_here: '📍 Вы здесь',
    geo_no_support: 'Геолокация не поддерживается вашим браузером.',
    geo_denied: 'Доступ к геолокации запрещён. Разрешите в настройках браузера.',
    geo_unavailable: 'Не удалось определить местоположение. Проверьте GPS.',
    geo_timeout: 'Время ожидания геолокации истекло.',
    geo_addr_not_found: '⚠️ Адрес не найден — введите вручную.',

    // галерея
    gallery_photo_of: 'фото {cur} из {total}',

    // email уведомления (метки в настройках)
    notif_email_match: 'Email при совпадении',
    notif_email_claim: 'Email при решении по заявке',
    notif_email_msg:   'Email при новом сообщении',

    // категории
    cat_electronics: 'Электроника', cat_documents: 'Документы', cat_keys: 'Ключи',
    cat_bags: 'Сумки', cat_clothes: 'Одежда', cat_jewelry: 'Украшения',
    cat_pets: 'Животные', cat_cards: 'Карты/Пропуска', cat_other: 'Другое',
  },

  /* ─────────────── ҚАЗАҚША ─────────────── */
  kz: {
    nav_home: 'Басты бет', nav_map: 'Карта', nav_cabinet: 'Кабинет',
    nav_login: 'Кіру', nav_logout: 'Шығу', nav_admin: 'Әкімші',
    lang_switcher_label: 'Тіл',

    hero_tag: '🔍 Қазақстанның табылған заттар бюросы',
    hero_title: 'Жоғалғанды табыңыз. Табылғанды қайтарыңыз.',
    hero_sub: 'Жоғалған заттарды іздеуге арналған платформа. Хабарландыру жасаңыз — жүйе сәйкестікті автоматты түрде табады.',
    hero_btn_create: '+ Хабарландыру жасау', hero_btn_browse: 'Хабарландыруларды көру',
    hero_lost: '🔴 Жоғалттым', hero_found: '🟢 Таптым',

    stat_lost: 'Жоғалған', stat_found: 'Табылған', stat_returned: 'Қайтарылған', stat_users: 'Пайдаланушы',

    search_ph: 'Атауы бойынша іздеу…', filter_all_types: 'Барлық түрлер', filter_all_cats: 'Барлық санаттар',
    filter_all: 'Барлығы', filter_lost: 'Жоғалған', filter_found: 'Табылған',
    filter_open: 'Ашық', filter_closed: 'Жабық', filter_color_ph: 'Түс',
    btn_search: 'Іздеу', btn_reset: 'Тазалау',
    sort_label: 'Сұрыптау:', sort_new: 'Алдымен жаңалар', sort_event_date: 'Жоғалған күні бойынша', sort_old: 'Алдымен ескілер',
    no_items: 'Ештеңе табылмады', ads_title: 'Хабарландырулар',
    btn_prev: '← Артқа', btn_next: 'Алға →', page_of: 'ішінен', page_label: 'Бет',

    create_title: 'Хабарландыру жасау',
    create_login_msg: 'Хабарландыру жасау үшін <a href="/auth.html">кіріңіз немесе тіркеліңіз</a>.',
    form_type: 'Түрі *', form_type_lost: '🔴 Жоғалған', form_type_found: '🟢 Табылған',
    form_category: 'Санат *', form_title: 'Атауы *',
    form_title_ph: 'Мысалы: Монограммалы қара әмиян',
    form_desc: 'Сипаттама *', form_desc_ph: 'Затты толық сипаттаңыз — ерекше белгілер, мазмұны…',
    form_color: 'Түс', form_color_ph: 'Қара, көк…',
    form_brand: 'Бренд/маркасы', form_brand_ph: 'Apple, Nike…',
    form_location: 'Орын (көше, аудан) *', form_location_ph: 'Қабанбай батыр к-сі, Мега СТО…',
    form_date: 'Оқиға күні *', form_serial: 'Сериялық нөмір (бар болса)', form_serial_ph: 'IMEI, S/N…',
    form_reward: 'Сыйақы', form_reward_ph: '5000 теңге немесе келісім бойынша',
    form_contact: 'Байланыс деректері', form_contact_ph: '+7 777 123 45 67 немесе @telegram',
    form_photo: 'Заттың фотосы', form_submit: 'Модерацияға жіберу',
    form_moderation_note: 'Хабарландыру әкімші тексергеннен кейін пайда болады.',

    items_lost: 'Жоғалған', items_found: 'Табылған', items_returned: 'Қайтарылған',
    item_views: 'қаралым', item_date: 'Күні', item_place: 'Орын',
    item_category: 'Санат', item_color: 'Түс', item_brand: 'Бренд',
    item_serial: 'Сериялық №', item_contact: 'Байланыс',
    item_reward: 'Сыйақы', item_author: 'Автор',
    item_matches: '🔍 Ұқсас сәйкестіктер', item_actions: 'Әрекеттер',
    btn_msg: '💬 Авторға жазу', btn_fav_add: '🤍 Таңдаулыға қосу', btn_fav_rm: '❤️ Таңдаулыда',
    btn_claim: '🔐 Иелікті растау', btn_share: '🔗 Бөлісу', btn_report: '🚩 Шағым білдіру',
    back: '← Артқа', login_to_act: 'Байланысу үшін кіріңіз',
    share_copied: 'Сілтеме көшірілді!', share_error: 'Сілтемені көшіру мүмкін болмады',

    report_title: '🚩 Хабарландыруға шағым', report_reason: 'Себебі',
    report_spam: 'Спам', report_inapp: 'Қолайсыз мазмұн',
    report_dup: 'Қайталану', report_fake: 'Алаяқтық', report_other: 'Басқа',
    report_comment: 'Түсініктеме (міндетті емес)', report_ph: 'Мәселені толығырақ сипаттаңыз…',
    report_send: 'Шағым жіберу', report_cancel: 'Болдырмау', report_ok: 'Шағым қабылданды!',

    login_title: 'Кіру', reg_title: 'Тіркелу',
    tab_login: 'Кіру', tab_register: 'Тіркелу',
    email_label: 'Email', email_ph: 'your@email.com',
    pass_label: 'Құпия сөз', pass_ph: '••••••••',
    name_label: 'Аты-жөні', name_ph: 'Сіздің атыңыз',
    btn_login: 'Кіру', btn_register: 'Тіркелу',
    no_acc: 'Тіркелмеген бе?', has_acc: 'Тіркелгені бар ма?', forgot_pass: 'Құпия сөзді ұмыттым',

    sidebar_role_user: 'Пайдаланушы', sidebar_role_admin: 'Әкімші',
    dash_myitems: '📋 Менің хабарландыруларым', dash_matches: '🔍 Сәйкестіктер',
    dash_msgs: '💬 Хабарлар', dash_notifs: '🔔 Хабарламалар',
    dash_fav: '❤️ Таңдаулылар', dash_claims: '📬 Өтінімдер',
    dash_game: '🏆 Жетістіктер', dash_leaders: '📊 Көшбасшылар',
    dash_profile: '⚙️ Профиль', dash_adminlink: '🛡 Әкімші панелі', new_item: '+ Жаңа',

    pane_myitems: 'Менің хабарландыруларым', pane_matches: 'Сәйкестіктер',
    pane_matches_sub: 'Алгоритм ұқсас хабарландыруларды тапты. % неғұрлым жоғары — сәйкестік мүмкіндігі де жоғары.',
    pane_msgs: 'Хабарлар', pane_msgs_empty: 'Диалогты таңдаңыз',
    pane_notifs: 'Хабарламалар', pane_notifs_readall: 'Барлығын оқылды деп белгілеу',
    pane_fav: 'Таңдаулылар', pane_claims: 'Менің өтінімдерім',
    pane_claims_sub: 'Табылған затқа иелік дәлелін көрсете отырып өтінім жіберіңіз.',
    pane_game: '🏆 Жетістіктер', pane_game_sub: 'Белсенділік үшін ұпай жинап, белгі алыңыз.',
    pane_badges: '🎖 Белгілер', pane_points_hist: '📜 Ұпайлар тарихы',
    pane_leaders: '📊 Көшбасшылар кестесі', pane_leaders_sub: 'Белсенділік бойынша топ пайдаланушылар.',
    pane_profile: 'Профиль',

    prof_name: 'Аты-жөні', prof_phone: 'Телефон', prof_phone_ph: '+7 777 000 00 00',
    prof_bio: 'Өзі туралы', prof_bio_ph: 'Өзіңіз туралы бірнеше сөз…', prof_save: 'Сақтау',

    claim_item_id: 'Хабарландыру ID', claim_item_ph: 'Мысалы: 3',
    claim_proof: 'Иелік дәлелі',
    claim_proof_ph: 'Мазмұнды, сериялық нөмірді, чек фотосын сипаттаңыз…',
    claim_submit: 'Өтінім жіберу',

    push_title: '🔔 Push-хабарламалар', push_sub: 'Сәйкестіктер туралы хабарлама алыңыз',
    push_checking: 'Тексерілуде…', push_loading: 'Жүктелуде…',
    push_enabled_status: '✅ Push-хабарламалар қосылды',
    push_disabled_status: '🔕 Push-хабарламалар өшірілген',
    push_blocked_status: '🚫 Хабарламалар браузерде бұғатталған. Параметрлерде рұқсат беріңіз.',
    push_enable: 'Хабарламаларды қосу',
    push_disable: 'Хабарламаларды өшіру',
    push_enable_toast: 'Push-хабарламалар қосылды!',
    push_disable_toast: 'Push-хабарламалар өшірілді',
    push_enable_err: 'Хабарламаларды қосу мүмкін болмады',

    status_open: 'Белсенді', status_closed: 'Жабық', status_returned: 'Қайтарылған',
    status_lost: 'Жоғалған', status_found: 'Табылған', status_pending: 'Модерацияда',

    map_legend_lost: 'Жоғалған', map_legend_found: 'Табылған',
    map_subtitle: 'Қазақстан картасындағы жоғалту және табу орындары',
    map_filter_title: 'Сүзгі',
    map_filter_all: 'Барлық хабарландырулар',
    map_filter_lost: 'Тек жоғалған',
    map_filter_found: 'Тек табылған',
    map_filter_all_cats: 'Барлық санаттар',
    map_filter_apply: 'Қолдану',
    map_legend_title: 'Аңыз',
    map_loading: 'Жүктелуде…',
    map_count: 'хабарландыру',
    map_open_item: 'Хабарландыруды ашу →',

    // бос күйлер
    matches_empty: 'Сәйкестіктер әзірге жоқ',
    msgs_no_threads: 'Диалогтар жоқ',
    notifs_empty: 'Хабарламалар жоқ',
    fav_empty: 'Таңдаулылар жоқ',
    my_claims_empty: 'Сіз әлі өтінім берген жоқсыз.',
    points_history_empty: 'Белсенділік жоқ',

    // әкімші
    admin_tab_user_reports: '👤 Пайдаланушылар туралы шағымдар',
    admin_tab_analytics: '📊 Аналитика',
    admin_bulk_approve: '✅ Таңдалғандарды мақұлдау',
    admin_bulk_reject: '❌ Таңдалғандарды қабылдамау',
    admin_user_reports_h2: '👤 Пайдаланушылар туралы шағымдар',
    admin_all_clear: 'Барлығы тексерілді!',
    admin_claims_empty: 'Өтінімдер жоқ',
    admin_analytics_title: '📊 30 күндік аналитика',
    admin_chart_items: 'Жаңа хабарландырулар',
    admin_chart_returns: 'Қайтарулар',
    admin_chart_users: 'Тіркелулер',

    theme_dark: '🌙', theme_light: '☀️',
    loading: 'Жүктелуде…', error_generic: 'Бірдеңе дұрыс болмады',
    saved: 'Сақталды', deleted: 'Жойылды', sent: 'Жіберілді!',
    cancel: 'Болдырмау', close: 'Жабу', yes: 'Иә', no: 'Жоқ',
    reject_reason: 'Бас тарту себебі (міндетті емес):',
    reject_reason_req: 'Бас тарту себебі:',

    user_profile: 'Пайдаланушы профилі',
    user_items: 'Пайдаланушының хабарландырулары',
    user_ratings: 'Пікірлер',
    user_report: 'Пайдаланушыға шағым білдіру',
    user_report_reason_ph: '— Себебі —',
    user_report_spam: 'Спам', user_report_fraud: 'Алаяқтық',
    user_report_abusive: 'Қорлау', user_report_fake: 'Жалған аккаунт',
    user_report_other: 'Басқа',
    user_report_comment_ph: 'Түсініктеме (міндетті емес)',
    user_report_submit: 'Жіберу', user_loading: 'Профиль жүктелуде…',

    verify_title: 'Email растауы…',
    verify_no_token: 'Жарамсыз сілтеме',
    verify_no_token_msg: 'Растау токені жоқ.',
    verify_success_title: 'Email расталды!',
    verify_success_msg: 'Енді FindIt-тің барлық мүмкіндіктерін пайдалана аласыз.',
    verify_error_title: 'Растау қатесі',
    verify_home: 'Басты бетке',

    // дашборд — поиск
    myitems_search_ph: 'Атауы бойынша іздеу…',
    fav_search_ph: 'Таңдаулыларды іздеу…',

    // дашборд — мои заявки
    my_claims_title: '📬 Менің жіберген өтінімдерім',

    // дашборд — подписки
    dash_subscriptions: '🔔 Жазылымдар',
    pane_subscriptions: '🔔 Жазылымдар',
    sub_pane_desc: 'Критерийлеріңіз бойынша жаңа хабарландырулар пайда болғанда хабар алыңыз',
    sub_new_title: 'Жаңа жазылым',
    sub_type_any: 'Кез келген тип',
    sub_type_lost_label: '🔍 Жоғалған',
    sub_type_found_label: '📦 Табылған',
    sub_location_ph: 'Аудан/жер (мысалы: Алмалы)',
    sub_cat_any: 'Кез келген санат',
    sub_add_btn: '+ Жазылым қосу',
    sub_empty: 'Жазылымдар жоқ. Жоғарыда бірінші қосыңыз.',
    sub_fill_error: 'Кемінде бір өрісті толтырыңыз',
    sub_added: 'Жазылым қосылды!',

    // дашборд — аватар
    prof_avatar_label: 'Профиль суреті',
    prof_avatar_upload: '📷 Фото жүктеу',
    prof_avatar_hint: 'JPG, PNG, WEBP · 5 МБ дейін',

    // дашборд — безопасность
    security_title: '🔒 Қауіпсіздік',
    cur_pass: 'Ағымдағы құпия сөз',
    cur_pass_ph: 'Ағымдағы құпия сөзді енгізіңіз',
    new_pass: 'Жаңа құпия сөз',
    new_pass_ph: 'Кемінде 6 таңба',
    new_pass2: 'Жаңа құпия сөзді қайталаңыз',
    new_pass2_ph: 'Құпия сөзді қайталаңыз',
    change_pass_btn: 'Құпия сөзді өзгерту',

    // статусы заявок
    status_pending: '🕐 Күтілуде',
    status_approved_claim: '✅ Мақұлданды',
    status_rejected_claim: '❌ Қабылданбады',
    match_rejected: 'Сәйкестік қабылданбады',

    admin_title: '🛡 Әкімші панелі', admin_refresh: '↻ Жаңарту',
    admin_stats_total: 'Барлығы', admin_stats_lost: 'Жоғалған',
    admin_stats_found: 'Табылған', admin_stats_pending: 'Модерацияда', admin_stats_users: 'Пайдаланушылар',
    admin_tab_mod: 'Модерация', admin_tab_all: 'Барлық хабарландырулар',
    admin_tab_users: 'Пайдаланушылар', admin_tab_claims: 'Өтінімдер', admin_tab_reports: '🚩 Шағымдар',
    admin_pend_h2: 'Модерация күтуде', admin_all_h2: 'Барлық хабарландырулар',
    admin_users_h2: 'Пайдаланушылар', admin_claims_h2: 'Қайтару өтінімдері',
    admin_reports_h2: '🚩 Хабарландыруларға шағымдар',
    admin_filter_all_status: 'Барлық мәртебелер', admin_filter_pending: 'Модерацияда',
    admin_filter_approved: 'Мақұлданған', admin_filter_rejected: 'Қабылданбаған',
    admin_filter_all_types: 'Барлық түрлер', admin_filter_lost: 'Жоғалған',
    admin_filter_found: 'Табылған', admin_filter_apply: 'Қолдану',
    admin_rep_new: 'Жаңалар', admin_rep_reviewed: 'Қаралған', admin_rep_dismissed: 'Қабылданбаған',
    mod_approved: '✅ Мақұлданды', mod_rejected: '❌ Қабылданбады',
    mod_approve_toast: 'Мақұлданды ✅', mod_reject_toast: 'Қабылданбады ❌', mod_return_toast: 'Белгіленді 🎉',
    mod_bulk_approve_toast: '✅ Мақұлданды', mod_bulk_reject_toast: 'Қабылданбады',

    cat_electronics: 'Электроника', cat_documents: 'Құжаттар', cat_keys: 'Кілттер',
    cat_bags: 'Сөмкелер', cat_clothes: 'Киім', cat_jewelry: 'Зергерлік бұйымдар',
    cat_pets: 'Жануарлар', cat_cards: 'Карталар/Жіберілімдер', cat_other: 'Басқа',

    // профиль — қала
    prof_city: 'Қала / аудан', prof_city_ph: 'Алматы, Қазақстан',
    prof_city_detect: 'GPS арқылы анықтау',

    // пайдаланушы профилі — статистика
    user_stat_items: 'Хабарландырулар', user_stat_returned: 'Қайтарылған',
    user_stat_rating: 'Рейтинг', user_stat_points: 'Ұпайлар',
    user_badge_legend: 'Аңыз', user_badge_active: 'Белсенді',
    user_badge_patron: 'Меценат', user_badge_helper: 'Қайтаруға көмектесті',
    user_badge_expert: 'Тәжірибелі', user_badge_pioneer: 'Ашушы',
    user_level_next: 'Деңгейге дейін', user_level_max: '🏆 Максималды деңгейге жетті!',
    user_reviews: 'Пікірлер',

    // геолокация
    geo_detecting: '⏳ Анықталуда…',
    geo_nearby_btn: '📍 Маған жақын',
    geo_nearby_hide: '📍 Менің орнымды жасыру',
    geo_my_location: '🎯 Менің орным',
    geo_radius_label: 'Радиус:',
    geo_found: '{r} км радиусында {n} хабарландыру табылды',
    geo_empty: '{r} км радиусында хабарландырулар жоқ',
    geo_here: '📍 Сіз осындасыз',
    geo_no_support: 'Геолокация браузеріңізде қолданылмайды.',
    geo_denied: 'Геолокацияға рұқсат жоқ. Браузер параметрлерінде рұқсат беріңіз.',
    geo_unavailable: 'Орынды анықтау мүмкін болмады. GPS тексеріңіз.',
    geo_timeout: 'Геолокация уақыты аяқталды.',
    geo_addr_not_found: '⚠️ Мекенжай табылмады — қолмен енгізіңіз.',

    // галерея
    gallery_photo_of: '{total} ішінен {cur} фото',

    // email
    notif_email_match: 'Сәйкестік кезінде email',
    notif_email_claim: 'Өтінім шешімінде email',
    notif_email_msg:   'Жаңа хабарда email',
  },

  /* ─────────────── ENGLISH ─────────────── */
  en: {
    nav_home: 'Home', nav_map: 'Map', nav_cabinet: 'Dashboard',
    nav_login: 'Sign in', nav_logout: 'Sign out', nav_admin: 'Admin',
    lang_switcher_label: 'Language',

    hero_tag: '🔍 Kazakhstan Lost & Found Bureau',
    hero_title: "Find what's lost. Return what's found.",
    hero_sub: 'A platform for lost items. Post a listing — the system will automatically find matches.',
    hero_btn_create: '+ Create listing', hero_btn_browse: 'Browse listings',
    hero_lost: '🔴 I Lost Something', hero_found: '🟢 I Found Something',

    stat_lost: 'Lost', stat_found: 'Found', stat_returned: 'Returned', stat_users: 'Users',

    search_ph: 'Search by title…', filter_all_types: 'All types', filter_all_cats: 'All categories',
    filter_all: 'All', filter_lost: 'Lost', filter_found: 'Found',
    filter_open: 'Open', filter_closed: 'Closed', filter_color_ph: 'Color',
    btn_search: 'Search', btn_reset: 'Reset',
    sort_label: 'Sort by:', sort_new: 'Newest first', sort_event_date: 'By loss date', sort_old: 'Oldest first',
    no_items: 'Nothing found', ads_title: 'Listings',
    btn_prev: '← Previous', btn_next: 'Next →', page_of: 'of', page_label: 'Page',

    create_title: 'Create listing',
    create_login_msg: 'To create a listing, <a href="/auth.html">sign in or register</a>.',
    form_type: 'Type *', form_type_lost: '🔴 Lost', form_type_found: '🟢 Found',
    form_category: 'Category *', form_title: 'Title *',
    form_title_ph: 'E.g.: Black wallet with monogram',
    form_desc: 'Description *', form_desc_ph: 'Describe the item in detail — distinctive features, contents…',
    form_color: 'Color', form_color_ph: 'Black, blue…',
    form_brand: 'Brand', form_brand_ph: 'Apple, Nike…',
    form_location: 'Location (street, district) *', form_location_ph: 'Kabanbay Batyr St., Mega Mall…',
    form_date: 'Date of incident *', form_serial: 'Serial number (if any)', form_serial_ph: 'IMEI, S/N…',
    form_reward: 'Reward', form_reward_ph: '5000 KZT or negotiable',
    form_contact: 'Contact details', form_contact_ph: '+7 777 123 45 67 or @telegram',
    form_photo: 'Item photo', form_submit: 'Submit for moderation',
    form_moderation_note: 'Listing will appear after admin review.',

    items_lost: 'Lost', items_found: 'Found', items_returned: 'Returned',
    item_views: 'views', item_date: 'Date', item_place: 'Location',
    item_category: 'Category', item_color: 'Color', item_brand: 'Brand',
    item_serial: 'Serial #', item_contact: 'Contact',
    item_reward: 'Reward', item_author: 'Posted by',
    item_matches: '🔍 Similar matches', item_actions: 'Actions',
    btn_msg: '💬 Message author', btn_fav_add: '🤍 Save', btn_fav_rm: '❤️ Saved',
    btn_claim: '🔐 Verify ownership', btn_share: '🔗 Share', btn_report: '🚩 Report',
    back: '← Back', login_to_act: 'Sign in to contact',
    share_copied: 'Link copied!', share_error: 'Could not copy link',

    report_title: '🚩 Report listing', report_reason: 'Reason',
    report_spam: 'Spam', report_inapp: 'Inappropriate content',
    report_dup: 'Duplicate', report_fake: 'Fraud / scam', report_other: 'Other',
    report_comment: 'Comment (optional)', report_ph: 'Describe the issue in more detail…',
    report_send: 'Submit report', report_cancel: 'Cancel', report_ok: 'Report submitted!',

    login_title: 'Sign in', reg_title: 'Register',
    tab_login: 'Sign in', tab_register: 'Register',
    email_label: 'Email', email_ph: 'your@email.com',
    pass_label: 'Password', pass_ph: '••••••••',
    name_label: 'Name', name_ph: 'Your name',
    btn_login: 'Sign in', btn_register: 'Create account',
    no_acc: 'No account?', has_acc: 'Already have an account?', forgot_pass: 'Forgot password?',

    sidebar_role_user: 'User', sidebar_role_admin: 'Administrator',
    dash_myitems: '📋 My listings', dash_matches: '🔍 Matches',
    dash_msgs: '💬 Messages', dash_notifs: '🔔 Notifications',
    dash_fav: '❤️ Favourites', dash_claims: '📬 Claims',
    dash_game: '🏆 Achievements', dash_leaders: '📊 Leaderboard',
    dash_profile: '⚙️ Profile', dash_adminlink: '🛡 Admin panel', new_item: '+ New',

    pane_myitems: 'My listings', pane_matches: 'Matches',
    pane_matches_sub: 'The algorithm found similar listings. The higher the %, the more likely the match.',
    pane_msgs: 'Messages', pane_msgs_empty: 'Select a conversation',
    pane_notifs: 'Notifications', pane_notifs_readall: 'Mark all as read',
    pane_fav: 'Favourites', pane_claims: 'My item claims',
    pane_claims_sub: 'Submit a claim for a found item by providing proof of ownership.',
    pane_game: '🏆 Achievements', pane_game_sub: 'Earn points and badges for activity on the platform.',
    pane_badges: '🎖 Badges', pane_points_hist: '📜 Points history',
    pane_leaders: '📊 Leaderboard', pane_leaders_sub: 'Top users by activity and item returns.',
    pane_profile: 'Profile',

    prof_name: 'Name', prof_phone: 'Phone', prof_phone_ph: '+7 777 000 00 00',
    prof_bio: 'About me', prof_bio_ph: 'A few words about yourself…', prof_save: 'Save',

    claim_item_id: 'Listing ID', claim_item_ph: 'E.g.: 3',
    claim_proof: 'Proof of ownership',
    claim_proof_ph: 'Describe contents, serial number, receipt photo…',
    claim_submit: 'Submit claim',

    push_title: '🔔 Push notifications', push_sub: 'Get notified about matches',
    push_checking: 'Checking…', push_loading: 'Loading…',
    push_enabled_status: '✅ Push notifications enabled',
    push_disabled_status: '🔕 Push notifications disabled',
    push_blocked_status: '🚫 Notifications blocked in browser. Allow them in settings.',
    push_enable: 'Enable notifications',
    push_disable: 'Disable notifications',
    push_enable_toast: 'Push notifications enabled!',
    push_disable_toast: 'Push notifications disabled',
    push_enable_err: 'Could not enable notifications',

    status_open: 'Active', status_closed: 'Closed', status_returned: 'Returned',
    status_lost: 'Lost', status_found: 'Found', status_pending: 'Pending review',

    map_legend_lost: 'Lost', map_legend_found: 'Found',
    map_subtitle: 'Loss and find locations on the map of Kazakhstan',
    map_filter_title: 'Filter',
    map_filter_all: 'All listings',
    map_filter_lost: 'Lost only',
    map_filter_found: 'Found only',
    map_filter_all_cats: 'All categories',
    map_filter_apply: 'Apply',
    map_legend_title: 'Legend',
    map_loading: 'Loading…',
    map_count: 'listings',
    map_open_item: 'Open listing →',

    // empty states
    matches_empty: 'No matches yet',
    msgs_no_threads: 'No conversations',
    notifs_empty: 'No notifications',
    fav_empty: 'No favourites',
    my_claims_empty: 'You have not submitted any claims yet.',
    points_history_empty: 'No activity yet',

    // admin
    admin_tab_user_reports: '👤 User reports',
    admin_tab_analytics: '📊 Analytics',
    admin_bulk_approve: '✅ Approve selected',
    admin_bulk_reject: '❌ Reject selected',
    admin_user_reports_h2: '👤 User reports',
    admin_all_clear: 'All clear!',
    admin_claims_empty: 'No claims',
    admin_analytics_title: '📊 Analytics — last 30 days',
    admin_chart_items: 'New listings',
    admin_chart_returns: 'Returns',
    admin_chart_users: 'Registrations',

    theme_dark: '🌙', theme_light: '☀️',
    loading: 'Loading…', error_generic: 'Something went wrong',
    saved: 'Saved', deleted: 'Deleted', sent: 'Sent!',
    cancel: 'Cancel', close: 'Close', yes: 'Yes', no: 'No',
    reject_reason: 'Rejection reason (optional):',
    reject_reason_req: 'Rejection reason:',

    user_profile: 'User profile',
    user_items: "User's listings",
    user_ratings: 'Reviews',
    user_report: 'Report user',
    user_report_reason_ph: '— Reason —',
    user_report_spam: 'Spam', user_report_fraud: 'Fraud',
    user_report_abusive: 'Abusive behaviour', user_report_fake: 'Fake account',
    user_report_other: 'Other',
    user_report_comment_ph: 'Comment (optional)',
    user_report_submit: 'Submit', user_loading: 'Loading profile…',

    verify_title: 'Verifying email…',
    verify_no_token: 'Invalid link',
    verify_no_token_msg: 'Verification token is missing.',
    verify_success_title: 'Email verified!',
    verify_success_msg: 'You can now use all features of FindIt.',
    verify_error_title: 'Verification error',
    verify_home: 'Go to home',

    // dashboard — search
    myitems_search_ph: 'Search by title…',
    fav_search_ph: 'Search in favourites…',

    // dashboard — my claims
    my_claims_title: '📬 My submitted claims',

    // dashboard — subscriptions
    dash_subscriptions: '🔔 Subscriptions',
    pane_subscriptions: '🔔 Subscriptions',
    sub_pane_desc: 'Get notified when new listings matching your criteria appear',
    sub_new_title: 'New subscription',
    sub_type_any: 'Any type',
    sub_type_lost_label: '🔍 Lost',
    sub_type_found_label: '📦 Found',
    sub_location_ph: 'Area/location (e.g. Almaly district)',
    sub_cat_any: 'Any category',
    sub_add_btn: '+ Add subscription',
    sub_empty: 'No subscriptions yet. Add the first one above.',
    sub_fill_error: 'Please fill in at least one field',
    sub_added: 'Subscription added!',

    // dashboard — avatar
    prof_avatar_label: 'Profile photo',
    prof_avatar_upload: '📷 Upload photo',
    prof_avatar_hint: 'JPG, PNG, WEBP · up to 5 MB',

    // dashboard — security
    security_title: '🔒 Security',
    cur_pass: 'Current password',
    cur_pass_ph: 'Enter current password',
    new_pass: 'New password',
    new_pass_ph: 'Minimum 6 characters',
    new_pass2: 'Confirm new password',
    new_pass2_ph: 'Repeat password',
    change_pass_btn: 'Change password',

    // claim / match statuses
    status_pending: '🕐 Pending',
    status_approved_claim: '✅ Approved',
    status_rejected_claim: '❌ Rejected',
    match_rejected: 'Match rejected',

    admin_title: '🛡 Administration Panel', admin_refresh: '↻ Refresh',
    admin_stats_total: 'Total', admin_stats_lost: 'Lost',
    admin_stats_found: 'Found', admin_stats_pending: 'Pending review', admin_stats_users: 'Users',
    admin_tab_mod: 'Moderation', admin_tab_all: 'All listings',
    admin_tab_users: 'Users', admin_tab_claims: 'Claims', admin_tab_reports: '🚩 Reports',
    admin_pend_h2: 'Awaiting moderation', admin_all_h2: 'All listings',
    admin_users_h2: 'Users', admin_claims_h2: 'Return claims',
    admin_reports_h2: '🚩 Reported listings',
    admin_filter_all_status: 'All statuses', admin_filter_pending: 'Pending',
    admin_filter_approved: 'Approved', admin_filter_rejected: 'Rejected',
    admin_filter_all_types: 'All types', admin_filter_lost: 'Lost',
    admin_filter_found: 'Found', admin_filter_apply: 'Apply',
    admin_rep_new: 'New', admin_rep_reviewed: 'Reviewed', admin_rep_dismissed: 'Dismissed',
    mod_approved: '✅ Approved', mod_rejected: '❌ Rejected',
    mod_approve_toast: 'Approved ✅', mod_reject_toast: 'Rejected ❌', mod_return_toast: 'Marked 🎉',
    mod_bulk_approve_toast: '✅ Approved', mod_bulk_reject_toast: 'Rejected',

    cat_electronics: 'Electronics', cat_documents: 'Documents', cat_keys: 'Keys',
    cat_bags: 'Bags', cat_clothes: 'Clothing', cat_jewelry: 'Jewellery',
    cat_pets: 'Animals / Pets', cat_cards: 'Cards / Passes', cat_other: 'Other',

    // profile — city
    prof_city: 'City / District', prof_city_ph: 'Almaty, Kazakhstan',
    prof_city_detect: 'Detect via GPS',

    // public profile — stats & badges
    user_stat_items: 'Listings', user_stat_returned: 'Returned',
    user_stat_rating: 'Rating', user_stat_points: 'Points',
    user_badge_legend: 'Legend', user_badge_active: 'Active',
    user_badge_patron: 'Patron', user_badge_helper: 'Return helper',
    user_badge_expert: 'Expert', user_badge_pioneer: 'Pioneer',
    user_level_next: 'Until level', user_level_max: '🏆 Max level reached!',
    user_reviews: 'Reviews',

    // geolocation
    geo_detecting: '⏳ Detecting…',
    geo_nearby_btn: '📍 Near me',
    geo_nearby_hide: '📍 Hide my location',
    geo_my_location: '🎯 My location',
    geo_radius_label: 'Radius:',
    geo_found: 'Found {n} listings within {r} km',
    geo_empty: 'No listings within {r} km',
    geo_here: '📍 You are here',
    geo_no_support: 'Geolocation is not supported by your browser.',
    geo_denied: 'Location access denied. Enable it in browser settings.',
    geo_unavailable: 'Could not determine location. Check your GPS.',
    geo_timeout: 'Geolocation request timed out.',
    geo_addr_not_found: '⚠️ Address not found — please enter manually.',

    // gallery
    gallery_photo_of: 'photo {cur} of {total}',

    // email notifications
    notif_email_match: 'Email on match',
    notif_email_claim: 'Email on claim decision',
    notif_email_msg:   'Email on new message',
  },
};

/* ─── Runtime ─────────────────────────────────────────── */

const SUPPORTED_LANGS = Object.keys(TRANSLATIONS); // ['ru','kz','en']

/** Читаем сохранённый язык; по умолчанию — русский */
let _lang = localStorage.getItem('fi_lang') || 'ru';
if (!TRANSLATIONS[_lang]) _lang = 'ru';

/** Перевод по ключу. Fallback: RU → сам ключ */
function t(key) {
  return TRANSLATIONS[_lang]?.[key] ?? TRANSLATIONS['ru']?.[key] ?? key;
}

/** Текущий язык */
function getLang() { return _lang; }

/**
 * Сменить язык, сохранить в localStorage и обновить весь DOM.
 * Вызывается кнопками переключателя.
 */
function setLang(lang) {
  if (!TRANSLATIONS[lang]) return;
  _lang = lang;
  localStorage.setItem('fi_lang', lang);

  // lang-атрибут документа (для CSS :lang и screen readers)
  document.documentElement.lang = lang === 'kz' ? 'kk' : lang;

  // Обновляем активную кнопку и текст
  applyI18n();

  // Вызываем пользовательские callback'и (если подписались через onLangChange)
  _langChangeCallbacks.forEach(fn => fn(lang));
}

/** Список подписчиков на смену языка */
const _langChangeCallbacks = [];

/**
 * Подписаться на смену языка (для кода в app.js и других скриптах).
 * @example onLangChange(lang => renderCategoryOptions())
 */
function onLangChange(fn) {
  _langChangeCallbacks.push(fn);
}

/**
 * Обходит все [data-i18n*] элементы и применяет переводы.
 * Безопасно вызывать повторно — идемпотентна.
 */
function applyI18n() {
  // data-i18n → innerHTML
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.dataset.i18n;
    const val = t(key);
    if (el.dataset.i18nAttr) {
      el.setAttribute(el.dataset.i18nAttr, val);
    } else {
      el.innerHTML = val;
    }
  });

  // data-i18n-ph → placeholder
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    el.placeholder = t(el.dataset.i18nPh);
  });

  // data-i18n-title → title-атрибут (tooltip)
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = t(el.dataset.i18nTitle);
  });

  // Активная кнопка переключателя
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('lang-btn--active', btn.dataset.lang === _lang);
    btn.setAttribute('aria-pressed', btn.dataset.lang === _lang ? 'true' : 'false');
  });

  // Переводим <option data-cat-slug="…"> категорий
  document.querySelectorAll('option[data-cat-slug]').forEach(opt => {
    const slug = opt.dataset.catSlug;
    const icon = opt.dataset.catIcon || '';
    const translated = t('cat_' + slug);
    if (translated !== 'cat_' + slug) {
      opt.textContent = icon ? icon + ' ' + translated : translated;
    }
  });
}

// Применяем сразу при загрузке
document.addEventListener('DOMContentLoaded', applyI18n);
