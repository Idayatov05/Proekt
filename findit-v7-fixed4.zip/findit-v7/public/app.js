/* ═══════════════════════════════════════════════════════
   FindIt — Client Application v3
   ═══════════════════════════════════════════════════════ */

/* ─── Theme bootstrap (before DOM paint to avoid flash) ─ */
(function () {
  if (localStorage.getItem('fi_theme') === 'light')
    document.documentElement.classList.add('light');
})();

function toggleTheme() {
  const isLight = document.documentElement.classList.toggle('light');
  localStorage.setItem('fi_theme', isLight ? 'light' : 'dark');
  const btn = document.getElementById('btnTheme');
  if (btn) btn.textContent = isLight ? '🌙' : '☀️';
}

function initThemeBtn() {
  const btn = document.getElementById('btnTheme');
  if (!btn) return;
  btn.textContent = document.documentElement.classList.contains('light') ? '🌙' : '☀️';
}

// ─── State ────────────────────────────────────────────────
const state = {
  token: localStorage.getItem('fi_token'),
  user:  JSON.parse(localStorage.getItem('fi_user') || 'null'),
  currentPage: 1,
  totalPages:  1,
  totalItems:  0,
  currentSort: 'newest',
  currentFilters: {},
  activeChatUser: null,
};

// ─── API helper ───────────────────────────────────────────
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers['Authorization'] = `Bearer ${state.token}`;
  if (opts.body instanceof FormData) delete headers['Content-Type'];

  const res = await fetch('/api' + path, { ...opts, headers: { ...headers, ...opts.headers } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Ошибка ${res.status}`);
  return data;
}

// ─── Auth helpers ─────────────────────────────────────────
function saveAuth(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem('fi_token', token);
  localStorage.setItem('fi_user', JSON.stringify(user));
}
function clearAuth() {
  state.token = null; state.user = null;
  localStorage.removeItem('fi_token');
  localStorage.removeItem('fi_user');
}
function isLoggedIn() { return !!state.token && !!state.user; }
function requireAuth() { if (!isLoggedIn()) { location.href = '/auth.html'; return false; } return true; }
function requireAdmin() { if (state.user?.role !== 'admin') { location.href = '/'; return false; } return true; }

// ─── Toast ────────────────────────────────────────────────
function toast(msg, type = 'info') {
  const box = document.getElementById('toast');
  if (!box) return;
  const el = document.createElement('div');
  el.className = `toast-msg ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warn: '⚠️' };
  el.innerHTML = `<span>${icons[type] || ''}</span> ${msg}`;
  box.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// ─── Date formatter ───────────────────────────────────────
function fmtDate(d) { return d ? new Date(d).toLocaleDateString('ru-KZ', { day:'2-digit', month:'short', year:'numeric' }) : '—'; }
function timeAgo(d) {
  const s = (Date.now() - new Date(d)) / 1000;
  if (s < 60) return 'только что';
  if (s < 3600) return `${Math.floor(s/60)} мин назад`;
  if (s < 86400) return `${Math.floor(s/3600)} ч назад`;
  return fmtDate(d);
}

// FIX-5 XSS: escape all user-supplied content before inserting into innerHTML.
// Without this, an item titled <script>alert(1)</script> would execute.
function esc(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ─── Геолокация — единая утилита ──────────────────────────
/**
 * Возвращает { lat, lng } текущего пользователя.
 * Кэширует результат на 60 секунд в window._geoCache.
 * opts.onStart(btn)  — вызывается перед запросом (можно поставить спиннер)
 * opts.onEnd(btn)    — вызывается после (успех или ошибка)
 */
async function getMyLocation(opts = {}) {
  const { onStart, onEnd, timeout = 8000 } = opts;

  // 60-секундный кэш
  const cache = window._geoCache;
  if (cache && Date.now() - cache.ts < 60_000) return cache;

  if (!navigator.geolocation)
    throw new Error('Геолокация не поддерживается вашим браузером.');

  if (onStart) onStart();

  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      pos => {
        const result = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          ts: Date.now(),
        };
        window._geoCache = result;
        if (onEnd) onEnd();
        resolve(result);
      },
      err => {
        if (onEnd) onEnd();
        const msgs = {
          1: 'Доступ к геолокации запрещён. Разрешите в настройках браузера.',
          2: 'Не удалось определить местоположение. Проверьте GPS.',
          3: 'Время ожидания геолокации истекло.',
        };
        reject(new Error(msgs[err.code] || 'Ошибка геолокации.'));
      },
      { enableHighAccuracy: true, timeout, maximumAge: 60_000 }
    );
  });
}

/**
 * Получает адрес по координатам через Nominatim.
 */
async function reverseGeocode(lat, lng) {
  try {
    const res  = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
      { headers: { 'Accept-Language': 'ru' } }
    );
    const data = await res.json();
    const a = data.address || {};
    const parts = [];
    if (a.road)        parts.push(a.road + (a.house_number ? ' ' + a.house_number : ''));
    if (a.neighbourhood || a.suburb) parts.push(a.neighbourhood || a.suburb);
    if (a.city || a.town || a.village) parts.push(a.city || a.town || a.village);
    return parts.join(', ') || data.display_name?.split(',').slice(0, 3).join(', ') || '';
  } catch {
    return '';
  }
}

// ─── Item card ────────────────────────────────────────────
function itemCard(item, extras = '') {
  const typeLabel = item.type === 'lost' ? t('items_lost') : t('items_found');
  const img = item.image_url
    ? `<img class="card-img" src="${esc(item.image_url)}" alt="${esc(item.title)}" loading="lazy" />`
    : `<div class="card-img-placeholder">${item.category_icon || '📦'}</div>`;
  return `
  <article class="card" onclick="location.href='/item.html?id=${item.id}'">
    ${img}
    <div class="card-body">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
        <span class="chip chip-${item.type}">${typeLabel}</span>
        ${item.reward ? `<span class="chip" style="background:rgba(245,158,11,.15);color:#fbbf24">🎁 Награда</span>` : ''}
      </div>
      <div class="card-title">${esc(item.title)}</div>
      <div class="card-meta">
        <span>📂 ${item.category_name || '—'}</span>
        <span>📍 ${esc(item.location_text)}</span>
        <span>📅 ${fmtDate(item.event_date)}</span>
        ${item.color ? `<span>🎨 ${item.color}</span>` : ''}
      </div>
    </div>
    <div class="card-footer">
      <span class="text-muted" style="font-size:.78rem">👁 ${item.views || 0} · ${timeAgo(item.created_at)}</span>
      ${extras}
    </div>
  </article>`;
}

// ─── Tabs helper ──────────────────────────────────────────
function initTabs(scope = document) {
  scope.querySelectorAll('[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.tabs');
      group.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tabVal = btn.dataset.tab;
      const container = group.parentElement;
      container.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
      // Support both id="tab-X" (dashboard) and id="pane-X" (auth)
      const pane = container.querySelector('#tab-' + tabVal)
                || container.querySelector('#pane-' + tabVal)
                || document.getElementById('tab-' + tabVal)
                || document.getElementById('pane-' + tabVal);
      if (pane) pane.classList.add('active');
    });
  });
}

// ─── Page detection ───────────────────────────────────────
const page = () => {
  const p = location.pathname;
  if (p === '/' || p === '/index.html') return 'home';
  if (p.includes('auth'))      return 'auth';
  if (p.includes('dashboard')) return 'dashboard';
  if (p.includes('admin'))     return 'admin';
  if (p.includes('item'))      return 'item';
  return 'other';
};

/* ═══════════════════════════════════════════════════════
   HOME PAGE
   ═══════════════════════════════════════════════════════ */
async function initHome() {
  initThemeBtn();
  if (typeof applyI18n === 'function') applyI18n();
  // Nav
  const navAuth = document.getElementById('navAuth');
  if (isLoggedIn()) {
    navAuth.innerHTML = `<a href="/dashboard.html">👤 ${state.user.name}</a>`;
  } else {
    navAuth.innerHTML = `<a class="btn btn-primary btn-sm" href="/auth.html">Войти</a>`;
  }

  // Stats
  try {
    const { stats } = await api('/stats');
    document.getElementById('statsBar').innerHTML = `
      <div class="stat-card"><strong>${stats.lost}</strong><span>${t('stat_lost')}</span></div>
      <div class="stat-card"><strong>${stats.found}</strong><span>${t('stat_found')}</span></div>
      <div class="stat-card"><strong>${stats.returned}</strong><span>${t('stat_returned')}</span></div>
      <div class="stat-card"><strong>${stats.users}</strong><span>${t('stat_users')}</span></div>`;
  } catch {}

  // Categories for filter + form
  try {
    const { categories } = await api('/categories');
    const catSel = document.getElementById('filterCat');
    const formCat = document.getElementById('formCat');
    categories.forEach(c => {
      const catLabel = (typeof t === 'function' ? t('cat_' + c.slug) : '') || c.name;
      catSel.innerHTML += `<option value="${c.slug}" data-cat-slug="${c.slug}" data-cat-icon="${c.icon}">${c.icon} ${catLabel}</option>`;
      if (formCat) formCat.innerHTML += `<option value="${c.id}" data-cat-slug="${c.slug}" data-cat-icon="${c.icon}">${c.icon} ${catLabel}</option>`;
    });
  } catch {}

  // Load items
  async function loadItems(filters = {}) {
    document.getElementById('itemsGrid').innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const params = new URLSearchParams({ ...filters, page: state.currentPage, limit: 12, sort: state.currentSort });
      const { items, total, pages } = await api('/items?' + params);
      state.totalPages = pages || 1;
      state.totalItems = total || 0;

      const grid = document.getElementById('itemsGrid');
      if (!items.length) {
        grid.innerHTML = `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">🔍</div>${t('no_items')}</div>`;
        document.getElementById('paginationRow').style.display = 'none';
        document.getElementById('pageInfo').style.display = 'none';
        return;
      }
      grid.innerHTML = items.map(i => itemCard(i)).join('');
      renderPagination(state.currentPage, state.totalPages, state.totalItems);
    } catch (e) {
      const g = document.getElementById('itemsGrid');
      if (g) g.innerHTML = `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">⚠️</div>${e.message}</div>`;
      toast(e.message, 'error');
    }
  }

  function renderPagination(page, pages, total) {
    const row      = document.getElementById('paginationRow');
    const numWrap  = document.getElementById('pageNumbers');
    const info     = document.getElementById('pageInfo');
    const btnPrev  = document.getElementById('btnPrev');
    const btnNext  = document.getElementById('btnNext');

    if (pages <= 1) { row.style.display = 'none'; info.style.display = 'none'; return; }

    row.style.display = 'flex';
    info.style.display = 'block';

    btnPrev.disabled = page <= 1;
    btnNext.disabled = page >= pages;

    // Sliding window: show at most 7 page buttons
    const delta = 2;
    const range = [];
    for (let i = Math.max(1, page - delta); i <= Math.min(pages, page + delta); i++) range.push(i);
    if (range[0] > 1) { range.unshift('…'); range.unshift(1); }
    if (range[range.length - 1] < pages) { range.push('…'); range.push(pages); }

    numWrap.innerHTML = range.map(p => {
      if (p === '…') return `<span style="padding:0 4px;color:var(--muted)">…</span>`;
      const active = p === page;
      return `<button class="btn btn-sm ${active ? 'btn-primary' : 'btn-ghost'}"
        style="min-width:34px;padding:0 8px"
        onclick="window._goPage(${p})">${p}</button>`;
    }).join('');

    // "Стр. X из Y · N объявлений"
    info.textContent = `${t('page_label')} ${page} ${t('page_of')} ${pages} · ${total} ${t('ads_title').toLowerCase()}`;
  }

  window._goPage = p => {
    state.currentPage = p;
    loadItems(state.currentFilters);
    document.getElementById('items-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // URL params
  const urlP = new URLSearchParams(location.search);
  if (urlP.get('type')) { document.getElementById('filterType').value = urlP.get('type'); state.currentFilters.type = urlP.get('type'); }
  loadItems(state.currentFilters);

  // 🟢 #12 — История поиска (localStorage, последние 5 запросов)
  const SEARCH_HIST_KEY = 'findit_search_history';
  function getSearchHistory() {
    try { return JSON.parse(localStorage.getItem(SEARCH_HIST_KEY) || '[]'); } catch { return []; }
  }
  function saveSearchQuery(q) {
    if (!q.trim()) return;
    const hist = getSearchHistory().filter(h => h !== q.trim()).slice(0, 4);
    hist.unshift(q.trim());
    try { localStorage.setItem(SEARCH_HIST_KEY, JSON.stringify(hist)); } catch {}
  }
  function renderSearchDropdown() {
    const hist = getSearchHistory();
    let dd = document.getElementById('searchHistDrop');
    if (!dd) {
      dd = document.createElement('div');
      dd.id = 'searchHistDrop';
      dd.style.cssText = 'position:absolute;top:100%;left:0;right:0;background:var(--card);border:1px solid var(--border);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.15);z-index:200;overflow:hidden;margin-top:4px';
      const wrap = document.getElementById('searchQ')?.parentElement;
      if (wrap) { wrap.style.position = 'relative'; wrap.appendChild(dd); }
    }
    if (!hist.length) { dd.style.display = 'none'; return; }
    dd.style.display = 'block';
    dd.innerHTML = `<div style="padding:6px 12px;font-size:.75rem;color:var(--muted);border-bottom:1px solid var(--border)">Последние запросы</div>`
      + hist.map((h, i) => `<div class="search-hist-item" data-idx="${i}" style="padding:9px 14px;cursor:pointer;font-size:.88rem;display:flex;align-items:center;gap:8px">
          <span style="color:var(--muted)">🕐</span><span style="flex:1">${esc(h)}</span>
          <span class="hist-del" data-idx="${i}" style="color:var(--muted);font-size:.8rem;padding:2px 4px">✕</span>
        </div>`).join('');
    dd.querySelectorAll('.search-hist-item').forEach(el => {
      el.addEventListener('mousedown', e => {
        if (e.target.classList.contains('hist-del')) {
          e.preventDefault();
          const hist2 = getSearchHistory();
          hist2.splice(Number(e.target.dataset.idx), 1);
          try { localStorage.setItem(SEARCH_HIST_KEY, JSON.stringify(hist2)); } catch {}
          renderSearchDropdown();
          return;
        }
        e.preventDefault();
        const q = getSearchHistory()[Number(el.dataset.idx)];
        document.getElementById('searchQ').value = q;
        dd.style.display = 'none';
        document.getElementById('btnSearch').click();
      });
    });
  }
  const searchQEl = document.getElementById('searchQ');
  if (searchQEl) {
    searchQEl.addEventListener('focus', renderSearchDropdown);
    searchQEl.addEventListener('input', renderSearchDropdown);
    searchQEl.addEventListener('blur', () => setTimeout(() => {
      const dd = document.getElementById('searchHistDrop');
      if (dd) dd.style.display = 'none';
    }, 200));
  }

  // Search
  document.getElementById('btnSearch').addEventListener('click', () => {
    state.currentPage = 1;
    const q = document.getElementById('searchQ').value;
    saveSearchQuery(q); // 🟢 сохраняем в историю
    state.currentFilters = {
      search:   q,
      type:     document.getElementById('filterType').value,
      category: document.getElementById('filterCat').value,
      color:    document.getElementById('filterColor').value,
    };
    const dd = document.getElementById('searchHistDrop');
    if (dd) dd.style.display = 'none';
    loadItems(state.currentFilters);
  });
  document.getElementById('searchQ').addEventListener('keydown', e => e.key === 'Enter' && document.getElementById('btnSearch').click());
  document.getElementById('btnReset').addEventListener('click', () => {
    document.getElementById('searchQ').value = '';
    document.getElementById('filterType').value = '';
    document.getElementById('filterCat').value = '';
    document.getElementById('filterColor').value = '';
    state.currentFilters = {}; state.currentPage = 1; state.currentSort = 'newest';
    document.querySelectorAll('.sort-btn').forEach((b, i) => b.classList.toggle('active', i === 0));
    document.querySelectorAll('.type-tab').forEach((b, i) => b.classList.toggle('active', i === 0));
    loadItems();
  });

  // Type tabs
  document.querySelectorAll('.type-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.type-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentFilters.type = btn.dataset.t;
      state.currentPage = 1;
      loadItems(state.currentFilters);
    });
  });

  // Sort buttons
  document.querySelectorAll('.sort-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sort-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.currentSort = btn.dataset.sort;
      state.currentPage = 1;
      loadItems(state.currentFilters);
    });
  });

  // Pagination prev / next
  document.getElementById('btnPrev')?.addEventListener('click', () => {
    if (state.currentPage > 1) window._goPage(state.currentPage - 1);
  });
  document.getElementById('btnNext')?.addEventListener('click', () => {
    if (state.currentPage < state.totalPages) window._goPage(state.currentPage + 1);
  });

  // Create form
  const createForm = document.getElementById('createForm');
  const createNotice = document.getElementById('createLoginNotice');
  if (isLoggedIn()) {
    createForm.style.display = 'flex';
    const today = new Date().toISOString().slice(0,10);
    createForm.querySelector('[name=event_date]').value = today;

    // ── Предпросмотр фотографий ───────────────────────────
    const photoInput   = document.getElementById('photoInput');
    const photoPreview = document.getElementById('photoPreview');
    if (photoInput && photoPreview) {
      photoInput.addEventListener('change', () => {
        photoPreview.innerHTML = '';
        const files = Array.from(photoInput.files).slice(0, 5);
        files.forEach(file => {
          const reader = new FileReader();
          reader.onload = e => {
            const wrap = document.createElement('div');
            wrap.style.cssText = 'position:relative;width:80px;height:80px;border-radius:8px;overflow:hidden;border:1px solid var(--border)';
            wrap.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover" />`;
            photoPreview.appendChild(wrap);
          };
          reader.readAsDataURL(file);
        });
      });
    }

    createForm.addEventListener('submit', async e => {
      e.preventDefault();
      const fd = new FormData(createForm);
      const btn = createForm.querySelector('button[type=submit]');
      btn.disabled = true; btn.textContent = 'Отправка…';
      try {
        await api('/items', { method: 'POST', body: fd, headers: {} });
        toast('Объявление отправлено на модерацию!', 'success');
        createForm.reset();
        createForm.querySelector('[name=event_date]').value = today;
        if (photoPreview) photoPreview.innerHTML = '';
        const latF = document.getElementById('locationLat');
        const lngF = document.getElementById('locationLng');
        if (latF) latF.value = '';
        if (lngF) lngF.value = '';
      } catch (err) { toast(err.message, 'error'); }
      finally { btn.disabled = false; btn.textContent = 'Отправить на модерацию'; }
    });
  } else {
    createNotice.style.display = 'block';
    createForm.style.display = 'none';
  }

  // ── Кнопка «Рядом со мной» ────────────────────────────
  const btnNearby = document.getElementById('btnNearby');
  if (btnNearby) {
    btnNearby.addEventListener('click', async () => {
      try {
        const { lat, lng } = await getMyLocation({
          onStart: () => { btnNearby.disabled = true; btnNearby.textContent = '⏳ Определяем…'; },
          onEnd:   () => { btnNearby.disabled = false; btnNearby.textContent = '📍 Рядом со мной'; },
        });
        const radius = document.getElementById('nearbyRadius')?.value || 5;
        const grid   = document.getElementById('itemsGrid');
        grid.innerHTML = `<div class="loading" style="grid-column:1/-1">🔍 Ищем в радиусе ${radius} км…</div>`;
        document.getElementById('paginationRow').style.display = 'none';
        document.getElementById('pageInfo').style.display = 'none';

        const data  = await api(`/items/nearby?lat=${lat}&lng=${lng}&radius=${radius}`);
        const items = data.items || [];
        grid.innerHTML = items.length
          ? items.map(i => itemCard(i)).join('')
          : `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">📍</div>Объявлений в радиусе ${radius} км не найдено</div>`;
        if (items.length) toast(`Найдено ${items.length} объявлений в радиусе ${radius} км`, 'success');
      } catch (err) {
        btnNearby.disabled = false;
        btnNearby.textContent = '📍 Рядом со мной';
        toast(err.message, 'error');
      }
    });
  }

  // Hero button
  document.getElementById('btnCreateHero')?.addEventListener('click', e => {
    if (!isLoggedIn()) { e.preventDefault(); location.href = '/auth.html'; }
  });
}

/* ═══════════════════════════════════════════════════════
   AUTH PAGE
   ═══════════════════════════════════════════════════════ */
async function initAuth() {
  if (isLoggedIn()) { location.href = state.user?.role === 'admin' ? '/admin.html' : '/dashboard.html'; return; }

  initTabs();
  document.querySelectorAll('.tab-switch').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      document.querySelector(`[data-tab="${a.dataset.target}"]`).click();
    });
  });

  // Login
  document.getElementById('loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const errEl = document.getElementById('loginErr');
    errEl.textContent = '';
    try {
      const { token, user } = await api('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: fd.get('email'), password: fd.get('password') }),
      });
      saveAuth(token, user);
      toast('Добро пожаловать!', 'success');
      setTimeout(() => location.href = user?.role === 'admin' ? '/admin.html' : '/dashboard.html', 500);
    } catch (err) { errEl.textContent = err.message; }
  });

  // Register
  document.getElementById('registerForm').addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const errEl = document.getElementById('regErr');
    errEl.textContent = '';
    try {
      const { token, user } = await api('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ name: fd.get('name'), email: fd.get('email'), password: fd.get('password') }),
      });
      saveAuth(token, user);
      toast('Аккаунт создан!', 'success');
      setTimeout(() => location.href = '/dashboard.html', 500);
    } catch (err) { errEl.textContent = err.message; }
  });

  // Forgot password — show/hide block
  const forgotBlock = document.getElementById('forgotBlock');
  const loginFormWrap = document.getElementById('loginForm');

  document.getElementById('showForgot')?.addEventListener('click', e => {
    e.preventDefault();
    loginFormWrap.style.display = 'none';
    document.getElementById('showForgot').style.display = 'none';
    forgotBlock.style.display = 'block';
  });

  document.getElementById('hideForgot')?.addEventListener('click', e => {
    e.preventDefault();
    forgotBlock.style.display = 'none';
    loginFormWrap.style.display = '';
    document.getElementById('showForgot').style.display = '';
  });

  document.getElementById('forgotForm')?.addEventListener('submit', async e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const msgEl = document.getElementById('forgotMsg');
    msgEl.style.display = 'none';
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    try {
      const data = await api('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ email: fd.get('email') }),
      });
      msgEl.style.display = 'block';
      msgEl.style.background = 'var(--success, #1a7a4a22)';
      msgEl.style.color = 'var(--success-text, #4ade80)';
      msgEl.style.border = '1px solid #4ade8044';
      // Show link in UI for dev/demo (in prod this would be sent via email)
      if (data.resetLink) {
        msgEl.innerHTML = `✅ Ссылка для сброса пароля:<br><a href="${data.resetLink}" style="color:var(--primary);word-break:break-all">${data.resetLink}</a>`;
      } else {
        msgEl.textContent = '✅ Если email зарегистрирован — ссылка отправлена.';
      }
    } catch (err) {
      msgEl.style.display = 'block';
      msgEl.style.background = '#ff444422';
      msgEl.style.color = '#f87171';
      msgEl.style.border = '1px solid #f8717144';
      msgEl.textContent = err.message || 'Ошибка. Попробуйте ещё раз.';
    } finally { btn.disabled = false; }
  });

  // Reset password — handle #reset?token=xxx
  const hash = location.hash;
  if (hash.startsWith('#reset?token=')) {
    const token = hash.split('token=')[1];
    if (token) showResetForm(token);
  }

  function showResetForm(token) {
    // Hide all tabs, show reset form
    document.querySelector('.tabs')?.style && (document.querySelector('.tabs').style.display = 'none');
    document.querySelector('.tab-content')?.style && (document.querySelector('.tab-content').style.display = 'none');
    const container = document.querySelector('.auth-card') || document.querySelector('.auth-box') || document.body;
    const resetDiv = document.createElement('div');
    resetDiv.id = 'resetBlock';
    resetDiv.innerHTML = `
      <h2 style="margin-bottom:16px;font-size:1.1rem">🔑 Новый пароль</h2>
      <form id="resetForm" class="auth-form">
        <div class="form-group">
          <label>Новый пароль</label>
          <input type="password" name="password" placeholder="Минимум 6 символов" minlength="6" required />
        </div>
        <div class="form-group">
          <label>Повторите пароль</label>
          <input type="password" name="password2" placeholder="Повторите пароль" minlength="6" required />
        </div>
        <div id="resetMsg" style="display:none;font-size:.85rem;padding:8px 12px;border-radius:6px;margin-bottom:10px"></div>
        <button type="submit" class="btn btn-primary" style="width:100%">Сохранить пароль</button>
      </form>
      <p style="text-align:center;margin-top:12px">
        <a href="/auth.html" style="font-size:.85rem;color:var(--muted)">← Назад ко входу</a>
      </p>
    `;
    container.appendChild(resetDiv);

    document.getElementById('resetForm').addEventListener('submit', async e => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const msgEl = document.getElementById('resetMsg');
      if (fd.get('password') !== fd.get('password2')) {
        msgEl.style.display = 'block';
        msgEl.style.background = '#ff444422';
        msgEl.style.color = '#f87171';
        msgEl.textContent = 'Пароли не совпадают.';
        return;
      }
      const btn = e.target.querySelector('button');
      btn.disabled = true;
      try {
        const { token: jwt, user } = await api('/auth/reset-password', {
          method: 'POST',
          body: JSON.stringify({ token, password: fd.get('password') }),
        });
        saveAuth(jwt, user);
        toast('Пароль успешно изменён!', 'success');
        setTimeout(() => location.href = '/dashboard.html', 800);
      } catch (err) {
        msgEl.style.display = 'block';
        msgEl.style.background = '#ff444422';
        msgEl.style.color = '#f87171';
        msgEl.textContent = err.message || 'Ошибка. Попробуйте заново.';
        btn.disabled = false;
      }
    });
  }
}

/* ═══════════════════════════════════════════════════════
   GALLERY SLIDER
   ═══════════════════════════════════════════════════════ */
function initGallerySlider(photos) {
  let cur = 0;
  const track  = document.getElementById('galleryTrack');
  const dots   = document.querySelectorAll('.gallery-dot');
  const counter = document.getElementById('galleryCounter');
  const total  = photos.length;

  function goTo(idx) {
    cur = (idx + total) % total;
    track.style.transform = `translateX(-${cur * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === cur));
    if (counter) counter.textContent = `${cur + 1} / ${total}`;
  }

  document.getElementById('galleryPrev')?.addEventListener('click', () => goTo(cur - 1));
  document.getElementById('galleryNext')?.addEventListener('click', () => goTo(cur + 1));
  dots.forEach(d => d.addEventListener('click', () => goTo(Number(d.dataset.idx))));

  // Свайп (touch)
  const slider = document.getElementById('gallerySlider');
  let touchX = null;
  slider?.addEventListener('touchstart', e => { touchX = e.touches[0].clientX; }, { passive: true });
  slider?.addEventListener('touchend', e => {
    if (touchX === null) return;
    const dx = e.changedTouches[0].clientX - touchX;
    if (Math.abs(dx) > 40) goTo(dx < 0 ? cur + 1 : cur - 1);
    touchX = null;
  });

  // Клавиатура
  document.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft')  goTo(cur - 1);
    if (e.key === 'ArrowRight') goTo(cur + 1);
  });
}

/* ═══════════════════════════════════════════════════════
   ITEM DETAIL PAGE
   ═══════════════════════════════════════════════════════ */
async function initItem() {
  initThemeBtn();
  if (typeof applyI18n === 'function') applyI18n();
  const id = new URLSearchParams(location.search).get('id');
  if (!id) return location.href = '/';
  document.title = 'FindIt — Загрузка…';

  try {
    const { item, isFav } = await api(`/items/${id}`);
    document.title = `FindIt — ${item.title}`;

    const typeLabel = item.type === 'lost' ? `🔴 ${t('items_lost')}` : `🟢 ${t('items_found')}`;

    // ── Фото-галерея / слайдер ────────────────────────────
    const allPhotos = (item.photos && item.photos.length)
      ? item.photos
      : item.image_url ? [item.image_url] : [];

    let img;
    if (allPhotos.length > 1) {
      img = `
        <div class="gallery-slider" id="gallerySlider">
          <div class="gallery-track" id="galleryTrack">
            ${allPhotos.map((p, i) =>
              `<img class="gallery-slide" src="${esc(p)}" alt="${esc(item.title)} фото ${i+1}" loading="${i === 0 ? 'eager' : 'lazy'}" />`
            ).join('')}
          </div>
          <button class="gallery-btn gallery-prev" id="galleryPrev" aria-label="Назад">&#8249;</button>
          <button class="gallery-btn gallery-next" id="galleryNext" aria-label="Вперёд">&#8250;</button>
          <div class="gallery-dots" id="galleryDots">
            ${allPhotos.map((_, i) => `<span class="gallery-dot${i === 0 ? ' active' : ''}" data-idx="${i}"></span>`).join('')}
          </div>
          <div class="gallery-counter" id="galleryCounter">1 / ${allPhotos.length}</div>
        </div>`;
    } else if (allPhotos.length === 1) {
      img = `<img class="item-detail-img" src="${esc(allPhotos[0])}" alt="${esc(item.title)}" />`;
    } else {
      img = `<div class="item-detail-img" style="display:flex;align-items:center;justify-content:center;font-size:5rem">${item.category_icon || '📦'}</div>`;
    }

    document.body.innerHTML = `
    <header class="header"><div class="header-inner">
      <a class="logo" href="/">Find<span>It</span></a>
      <nav class="header-nav">
        <a href="/">← ${t('back')}</a>
        ${isLoggedIn() ? `<a href="/dashboard.html">${t('nav_cabinet')}</a>` : `<a href="/auth.html">${t('nav_login')}</a>`}
        <div class="lang-switcher">
          <button class="lang-btn" data-lang="ru" onclick="setLang('ru')">RU</button>
          <button class="lang-btn" data-lang="kz" onclick="setLang('kz')">ҚЗ</button>
          <button class="lang-btn" data-lang="en" onclick="setLang('en')">EN</button>
        </div>
        <button class="btn-theme" id="btnTheme" onclick="toggleTheme()"></button>
      </nav>
    </div></header>
    <main class="section"><div class="container content-stack">
      <div class="item-detail-grid">
        <div>
          ${img}
          <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
            <span class="chip chip-${item.type}">${typeLabel}</span>
            <span class="chip chip-${item.status}">${{open:t('status_open'),closed:t('status_closed'),returned:t('status_returned')}[item.status]||item.status}</span>
            ${item.reward ? `<span class="chip" style="background:rgba(245,158,11,.15);color:#fbbf24">🎁 ${item.reward}</span>` : ''}
          </div>
          <h1 style="margin:14px 0 10px">${esc(item.title)}</h1>
          <p style="color:var(--muted);line-height:1.7;margin-bottom:20px">${esc(item.description)}</p>
          <div class="panel detail-meta-row">
            <div class="detail-field"><span class="label">📂 ${t('item_category')}</span><span class="val">${item.category_icon||''} ${item.category_name||'—'}</span></div>
            <div class="detail-field"><span class="label">📍 ${t('item_place')}</span><span class="val">${esc(item.location_text)}</span></div>
            <div class="detail-field"><span class="label">📅 ${t('item_date')}</span><span class="val">${fmtDate(item.event_date)}</span></div>
            ${item.color ? `<div class="detail-field"><span class="label">🎨 ${t('item_color')}</span><span class="val">${item.color}</span></div>` : ''}
            ${item.brand ? `<div class="detail-field"><span class="label">🏷 ${t('item_brand')}</span><span class="val">${item.brand}</span></div>` : ''}
            ${item.serial_number ? `<div class="detail-field"><span class="label">🔢 ${t('item_serial')}</span><span class="val">${item.serial_number}</span></div>` : ''}
            ${item.contact_info ? `<div class="detail-field"><span class="label">📞 ${t('item_contact')}</span><span class="val">${item.contact_info}</span></div>` : ''}
            <div class="detail-field"><span class="label">👁 ${t('item_views')}</span><span class="val">${item.views}</span></div>
            <div class="detail-field"><span class="label">👤 ${t('item_author')}</span><span class="val"><a href="/user.html?id=${item.owner_id}" style="color:var(--accent)">${esc(item.owner_name)}</a></span></div>
          </div>
        </div>
        <div class="content-stack">
          ${isLoggedIn() && item.owner_id !== state.user?.id ? `
          <div class="panel content-stack">
            <h3>${t('item_actions')}</h3>
            <button class="btn btn-primary" id="btnMsg">${t('btn_msg')}</button>
            <button class="btn ${isFav ? 'btn-accent' : 'btn-ghost'}" id="btnFav">${isFav ? t('btn_fav_rm') : t('btn_fav_add')}</button>
            <button class="btn btn-ghost" id="btnShare">${t('btn_share')}</button>
            ${item.type === 'found' ? `
            <div class="divider"></div>
            <h3>Это ваша вещь?</h3>
            <p class="text-muted" style="font-size:.82rem">Ответьте на вопросы для подтверждения владения</p>
            <button class="btn btn-warn" id="btnClaim">${t('btn_claim')}</button>` : ''}
            <div class="divider"></div>
            <button class="btn btn-ghost" id="btnReport" style="color:var(--muted);font-size:.82rem">${t('btn_report')}</button>
          </div>` : `
          <div class="panel content-stack">
            <button class="btn btn-ghost" id="btnShare">${t('btn_share')}</button>
            ${isLoggedIn() ? '' : `<a href="/auth.html" class="btn btn-primary" style="text-align:center">${t('login_to_act')}</a>`}
          </div>`}
          ${!isLoggedIn() ? `<div class="panel text-muted" style="text-align:center;padding:24px"><a href="/auth.html" class="btn btn-primary">Войдите чтобы связаться</a></div>` : ''}
          <div class="panel">
            <h3 style="margin-bottom:12px">${t('item_matches')}</h3>
            <div id="itemMatches" class="text-muted" style="font-size:.85rem">${t('loading')}</div>
          </div>
        </div>
      </div>
    </div></main>
    <div id="toast"></div>`;

    // Fav
    document.getElementById('btnFav')?.addEventListener('click', async () => {
      try {
        const { added } = await api(`/items/${id}/favorite`, { method: 'POST' });
        const btn = document.getElementById('btnFav');
        btn.textContent = added ? t('btn_fav_rm') : t('btn_fav_add');
        btn.className = `btn ${added ? 'btn-accent' : 'btn-ghost'}`;
        toast(added ? t('btn_fav_rm') : t('btn_fav_add'), 'success');
      } catch (e) { toast(e.message, 'error'); }
    });

    // Message
    document.getElementById('btnMsg')?.addEventListener('click', async () => {
      try {
        await api('/messages', { method: 'POST', body: JSON.stringify({ receiver_id: item.owner_id, body: `Привет! Пишу по объявлению "${item.title}".`, item_id: item.id }) });
        toast('Сообщение отправлено!', 'success');
        setTimeout(() => location.href = '/dashboard.html', 800);
      } catch (e) { toast(e.message, 'error'); }
    });

    // Claim — full verify modal
    document.getElementById('btnClaim')?.addEventListener('click', () => openVerifyModal(id, item));

    // ── Share ──────────────────────────────────────────────
    document.querySelectorAll('#btnShare').forEach(btn => {
      btn.addEventListener('click', async () => {
        const url   = location.href;
        const title = item.title;
        const text  = `${item.type === 'lost' ? '🔴' : '🟢'} ${title} — FindIt`;
        if (navigator.share) {
          try { await navigator.share({ title, text, url }); return; } catch {}
        }
        try {
          await navigator.clipboard.writeText(url);
          toast(t('share_copied'), 'success');
        } catch { toast(t('share_error'), 'error'); }
      });
    });

    // ── Report ─────────────────────────────────────────────
    document.getElementById('btnReport')?.addEventListener('click', () => openReportModal(id));

    // ── Theme btn after dynamic render ────────────────────
    initThemeBtn();
    if (typeof applyI18n === 'function') applyI18n();

    // ── Слайдер галереи ───────────────────────────────────
    if (allPhotos.length > 1) initGallerySlider(allPhotos);

    // Matches — FIX-7: /api/matches requires auth. Guest requests got 401
    // which the catch silently swallowed, showing "Недоступно" with no context.
    const matchesEl = document.getElementById('itemMatches');
    if (!isLoggedIn()) {
      matchesEl.innerHTML = '<a href="/auth.html" style="color:var(--primary);font-size:.85rem">Войдите чтобы видеть совпадения</a>';
    } else {
      try {
        const { matches } = await api(`/matches`);
        const rel = matches.filter(m => m.lost_id == id || m.found_id == id);
        matchesEl.innerHTML = rel.length
          ? rel.map(m => `<div style="padding:8px 0;border-bottom:1px solid var(--border)">
              <a href="/item.html?id=${m.lost_id == id ? m.found_id : m.lost_id}" style="color:var(--primary)">
                ${esc(m.lost_id == id ? m.found_title : m.lost_title)}
              </a>
              <span class="chip ${m.score>=70?'chip-found':m.score>=50?'chip-open':'chip-closed'}" style="margin-left:6px">${m.score}%</span>
            </div>`).join('')
          : '<span>Совпадений не найдено</span>';
      } catch { matchesEl.textContent = 'Не удалось загрузить совпадения.'; }
    }

  } catch (e) {
    document.body.innerHTML = `<div class="empty" style="padding:80px"><div class="empty-icon">😕</div><h2>Объявление не найдено</h2><a class="btn btn-primary" href="/">На главную</a></div>`;
  }
}

/* ═══════════════════════════════════════════════════════
   REPORT MODAL
   ═══════════════════════════════════════════════════════ */
function openReportModal(itemId) {
  document.getElementById('reportOverlay')?.remove();

  const reasons = [
    { value: 'spam',          labelKey: 'report_spam'   },
    { value: 'inappropriate', labelKey: 'report_inapp'  },
    { value: 'duplicate',     labelKey: 'report_dup'    },
    { value: 'fake',          labelKey: 'report_fake'   },
    { value: 'other',         labelKey: 'report_other'  },
  ];

  let selectedReason = '';

  const overlay = document.createElement('div');
  overlay.id = 'reportOverlay';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-box" style="max-width:440px">
      <div class="modal-head">
        <h2>${t('report_title')}</h2>
        <button class="modal-close" id="reportClose">✕</button>
      </div>
      <div class="modal-body">
        <p class="text-muted" style="font-size:.85rem;margin-bottom:14px">${t('report_reason')}</p>
        <div class="report-reason-grid">
          ${reasons.map(r => `
            <button class="report-reason-btn" data-value="${r.value}">
              ${t(r.labelKey)}
            </button>`).join('')}
        </div>
        <textarea id="reportComment" class="form-control" rows="3"
          style="width:100%;padding:10px;border-radius:8px;border:1px solid var(--border);
                 background:var(--subtle);color:var(--text);font-family:inherit;resize:vertical;margin-bottom:14px"
          placeholder="${t('report_ph')}"></textarea>
        <div style="display:flex;gap:8px">
          <button class="btn btn-ghost" id="reportCancel" style="flex:1">${t('report_cancel')}</button>
          <button class="btn btn-warn" id="reportSubmit" style="flex:2" disabled>${t('report_send')}</button>
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);

  const close = () => overlay.remove();
  document.getElementById('reportClose').addEventListener('click', close);
  document.getElementById('reportCancel').addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });

  // Reason selection
  overlay.querySelectorAll('.report-reason-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      overlay.querySelectorAll('.report-reason-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedReason = btn.dataset.value;
      document.getElementById('reportSubmit').disabled = false;
    });
  });

  // Submit
  document.getElementById('reportSubmit').addEventListener('click', async () => {
    if (!selectedReason) return;
    const comment = document.getElementById('reportComment').value.trim();
    const submitBtn = document.getElementById('reportSubmit');
    submitBtn.disabled = true;
    submitBtn.textContent = '…';
    try {
      await api(`/items/${itemId}/report`, {
        method: 'POST',
        body: JSON.stringify({ reason: selectedReason, comment }),
      });
      close();
      toast(t('report_ok'), 'success');
    } catch (e) {
      toast(e.message, 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = t('report_send');
    }
  });
}

/* ═══════════════════════════════════════════════════════
   VERIFY / CLAIM MODAL
   ═══════════════════════════════════════════════════════ */
function openVerifyModal(itemId, item) {
  // Remove existing modal if any
  document.getElementById('verifyOverlay')?.remove();

  const QUESTIONS = [
    { id: 'q1', text: 'Какой узор или царапина есть на задней крышке / чехле?' },
    { id: 'q2', text: 'Что изображено на последнем фото в фотоплёнке?' },
    { id: 'q3', text: 'Первые 6 цифр серийного номера / IMEI?' },
  ];

  let attempts = 0;
  const MAX_ATTEMPTS = 3;

  const overlay = document.createElement('div');
  overlay.id = 'verifyOverlay';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-box">
      <div class="modal-head">
        <h2>🔐 Подтверждение владения</h2>
        <button class="modal-close" id="verifyClose">✕</button>
      </div>
      <div class="modal-body">
        <div id="verifyContent">
          <div class="verify-hint">
            Ответьте на вопросы — нашедший ваших ответов не видит.
            Система оценивает совпадение автоматически.
          </div>
          <div class="verify-steps">
            <div class="verify-step done">✓ Заявка</div>
            <div class="verify-step active">Проверка</div>
            <div class="verify-step">Передача</div>
          </div>
          <div class="verify-attempts" id="verifyAttempts">Попытка 1 из ${MAX_ATTEMPTS}</div>
          ${QUESTIONS.map(q => `
          <div class="verify-q">
            <label>${q.text}</label>
            <input id="${q.id}" placeholder="Ваш ответ…" autocomplete="off" />
          </div>`).join('')}
          <button class="btn btn-primary" style="width:100%;margin-top:4px" id="verifySubmit">
            Отправить ответы
          </button>
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);

  // Close
  const close = () => overlay.remove();
  document.getElementById('verifyClose').addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });

  // Submit
  document.getElementById('verifySubmit').addEventListener('click', async () => {
    const answers = QUESTIONS.map(q => document.getElementById(q.id)?.value.trim());
    const filled = answers.filter(Boolean).length;

    attempts++;

    // Determine pass threshold: rating >= 4.5 needs 2/3, otherwise 3/3
    const userRating = state.user?.rating || 5;
    const threshold = userRating >= 4.5 ? 2 : 3;
    const passed = filled >= threshold;

    // Build proof string from answers for the API
    const proof = QUESTIONS.map((q, i) => q.text + '\nОтвет: ' + (answers[i] || '-')).join('\n\n');

    if (passed) {
      // Submit the real claim to backend
      try {
        await api('/claims', {
          method: 'POST',
          body: JSON.stringify({ item_id: itemId, proof }),
        });
      } catch (e) {
        // Claim might already exist — show result anyway
      }
      showResult(true, filled, threshold);
    } else if (attempts >= MAX_ATTEMPTS) {
      // Failed all attempts — still submit so admin can review
      try {
        await api('/claims', {
          method: 'POST',
          body: JSON.stringify({ item_id: itemId, proof: proof + '\n\n[Не прошло проверку - на модерацию]' }),
        });
      } catch {}
      showResult(false, filled, threshold, true);
    } else {
      // Wrong — show how many left
      const attemptsEl = document.getElementById('verifyAttempts');
      if (attemptsEl) attemptsEl.textContent = `Попытка ${attempts + 1} из ${MAX_ATTEMPTS} — ответьте точнее`;
      attemptsEl.style.color = 'var(--danger)';
      // Shake the submit button
      const btn = document.getElementById('verifySubmit');
      btn.style.background = 'var(--danger)';
      btn.textContent = `Неверно — осталось ${MAX_ATTEMPTS - attempts} попытки`;
      setTimeout(() => {
        btn.style.background = '';
        btn.textContent = 'Отправить ответы';
      }, 1800);
    }
  });

  function showResult(ok, filled, threshold, toModeration = false) {
    const content = document.getElementById('verifyContent');
    content.innerHTML = ok ? `
      <div class="verify-result">
        <div class="verify-result-icon">✅</div>
        <h3>Владение подтверждено!</h3>
        <p>Ваши ответы прошли проверку. Теперь вы можете связаться с нашедшим.</p>
        <div class="verify-detail ok">
          Совпало ответов: <strong>${filled} из ${threshold}</strong><br>
          Уверенность системы: <strong>высокая</strong><br>
          Нашедший получил уведомление.
        </div>
        <button class="btn btn-primary" style="width:100%" id="verifyGoChat">
          💬 Написать нашедшему
        </button>
      </div>` : `
      <div class="verify-result">
        <div class="verify-result-icon">${toModeration ? '📋' : '❌'}</div>
        <h3>${toModeration ? 'Передано в модерацию' : 'Проверка не пройдена'}</h3>
        <p>${toModeration
          ? 'Использованы все попытки. Ваша заявка передана администратору — он запросит дополнительные доказательства (фото, чек, скриншот).'
          : `Ответов недостаточно (${filled} из ${threshold}). Попробуйте снова.`}</p>
        <div class="verify-detail fail">
          Совпало ответов: <strong>${filled} из 3</strong><br>
          ${toModeration
            ? 'Статус: <strong>на рассмотрении у модератора</strong>'
            : `Осталось попыток: <strong>${MAX_ATTEMPTS - attempts}</strong>`}
        </div>
        <div style="display:flex;gap:8px">
          ${toModeration
            ? `<button class="btn btn-ghost" style="flex:1" id="verifyDone">Закрыть</button>`
            : `<button class="btn btn-ghost" style="flex:1" id="verifyRetry">Попробовать снова</button>`}
        </div>
      </div>`;

    // Wire up result buttons
    document.getElementById('verifyGoChat')?.addEventListener('click', async () => {
      try {
        await api('/messages', {
          method: 'POST',
          body: JSON.stringify({
            receiver_id: item.owner_id,
            body: `Привет! Я подтвердил владение вещью «${item.title}». Можем договориться о передаче?`,
            item_id: itemId,
          }),
        });
        toast('Сообщение отправлено!', 'success');
        close();
        setTimeout(() => location.href = '/dashboard.html', 600);
      } catch (e) { toast(e.message, 'error'); }
    });

    document.getElementById('verifyDone')?.addEventListener('click', close);

    document.getElementById('verifyRetry')?.addEventListener('click', () => {
      content.innerHTML = `
        <div class="verify-hint">Попробуйте ответить точнее на вопросы.</div>
        <div class="verify-steps">
          <div class="verify-step done">✓ Заявка</div>
          <div class="verify-step active">Проверка</div>
          <div class="verify-step">Передача</div>
        </div>
        <div class="verify-attempts" id="verifyAttempts">Попытка ${attempts + 1} из ${MAX_ATTEMPTS}</div>
        ${QUESTIONS.map(q => `
        <div class="verify-q">
          <label>${q.text}</label>
          <input id="${q.id}" placeholder="Ваш ответ…" autocomplete="off" />
        </div>`).join('')}
        <button class="btn btn-primary" style="width:100%;margin-top:4px" id="verifySubmit">
          Отправить ответы
        </button>`;
      // Re-bind submit
      document.getElementById('verifySubmit').addEventListener('click', () => {
        document.getElementById('verifySubmit').click();
      });
      // Simpler: just re-open
      close();
      openVerifyModal(itemId, item);
    });
  }
}

/* ═══════════════════════════════════════════════════════
   DASHBOARD PAGE
   ═══════════════════════════════════════════════════════ */
async function initDashboard() {
  if (!requireAuth()) return;
  initThemeBtn();
  if (typeof applyI18n === 'function') applyI18n();

  // Profile sidebar
  document.getElementById('sName').textContent = state.user?.name || '';
  document.getElementById('sRole').textContent = state.user?.role === 'admin' ? `🛡 ${t('sidebar_role_admin')}` : `👤 ${t('sidebar_role_user')}`;
  // 🔴 #3 / 🟢 #10 — показываем реальный аватар если загружен
  const sAv = document.getElementById('sAvatar');
  if (state.user?.avatar) {
    sAv.innerHTML = `<img src="${state.user.avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%" onerror="this.parentElement.textContent='${(state.user?.name||'?')[0].toUpperCase()}'" />`;
  } else {
    sAv.textContent = (state.user?.name || '?')[0].toUpperCase();
  }
  if (state.user?.role === 'admin') document.getElementById('adminLink').style.display = 'flex';

  document.getElementById('logoutBtn').addEventListener('click', () => { clearAuth(); location.href = '/'; });

  // Sidebar navigation with URL hash support
  const panes = document.querySelectorAll('.pane');

  function switchPane(paneName, updateHash = true) {
    // 🟡 #5 — остановить polling чата при уходе с вкладки сообщений
    if (paneName !== 'messages' && typeof _chatPollTimer !== 'undefined') {
      clearInterval(_chatPollTimer);
    }
    document.querySelectorAll('.sidebar-item').forEach(b => b.classList.remove('active'));
    const activeBtn = document.querySelector(`.sidebar-item[data-pane="${paneName}"]`);
    if (activeBtn) activeBtn.classList.add('active');
    panes.forEach(p => p.classList.remove('active'));
    const targetPane = document.getElementById('pane-' + paneName);
    if (targetPane) targetPane.classList.add('active');
    loadPane(paneName);
    if (updateHash) history.replaceState(null, '', '#' + paneName);
    // Always scroll to pane content when switching sections
    if (targetPane) {
      setTimeout(() => {
        const headerH = document.querySelector('.header')?.offsetHeight || 70;
        const rect = targetPane.getBoundingClientRect();
        const top = rect.top + window.scrollY - headerH - 16;
        window.scrollTo({ top, behavior: 'smooth' });
      }, 60);
    }
  }

  document.querySelectorAll('.sidebar-item[data-pane]').forEach(btn => {
    btn.addEventListener('click', () => switchPane(btn.dataset.pane));
  });

  // Unread counts
  async function refreshBadges() {
    try {
      const d = await api('/unread');
      const mb = document.getElementById('msgBadge');
      const nb = document.getElementById('notifBadge');
      const ndot = document.getElementById('navNotifDot');
      if (mb) { if (d.messages > 0) { mb.textContent = d.messages; mb.style.display = 'inline'; } else mb.style.display = 'none'; }
      if (nb) { if (d.notifications > 0) { nb.textContent = d.notifications; nb.style.display = 'inline'; if (ndot) ndot.classList.add('has-unread'); } else { nb.style.display = 'none'; if (ndot) ndot.classList.remove('has-unread'); } }
    } catch {}
  }
  refreshBadges();
  setInterval(refreshBadges, 60000); // реже — WS берёт на себя реалтайм

  // ── WebSocket (socket.io) — заменяет polling чата ────────
  let _socket = null;
  function initSocket() {
    if (typeof io === 'undefined') return; // socket.io не загружен
    if (_socket?.connected) return;
    _socket = io({ path: '/ws', auth: { token: state.token }, transports: ['websocket'] });

    _socket.on('new_message', msg => {
      // Если открыт чат с этим пользователем — добавляем сообщение в DOM
      const otherId = msg.sender_id === state.user.id ? msg.receiver_id : msg.sender_id;
      if (state.activeChatUser === otherId) {
        const box = document.getElementById('chatMsgs');
        if (box) {
          const mine = msg.sender_id === state.user.id;
          const div = document.createElement('div');
          div.className = `bubble ${mine ? 'bubble-me' : 'bubble-other'}`;
          div.innerHTML = `<div>${esc(msg.body)}</div><div class="bubble-time">только что</div>`;
          box.appendChild(div);
          box.scrollTop = box.scrollHeight;
        }
      } else {
        // Обновляем счётчик непрочитанных
        refreshBadges();
      }
    });

    _socket.on('typing', ({ from, is_typing }) => {
      if (state.activeChatUser !== from) return;
      let ind = document.getElementById('typingIndicator');
      if (is_typing) {
        if (!ind) {
          ind = document.createElement('div');
          ind.id = 'typingIndicator';
          ind.style.cssText = 'padding:6px 16px;font-size:.8rem;color:var(--muted)';
          ind.textContent = 'печатает…';
          document.getElementById('chatMsgs')?.after(ind);
        }
      } else { ind?.remove(); }
    });

    _socket.on('notification', notif => {
      refreshBadges();
      // Показываем toast если уведомление пришло в реалтайме
      if (notif?.title) toast(`${notif.title}: ${notif.body || ''}`, 'info');
    });

    _socket.on('connect_error', () => {}); // тихо — не ломаем UI
  }
  initSocket();

  // Load each pane
  async function loadPane(name) {
    if (name === 'my-items')      await loadMyItems();
    if (name === 'matches')       await loadMatches();
    if (name === 'messages')      await loadThreads();
    if (name === 'notifications') await loadNotifications();
    if (name === 'favorites')     await loadFavorites();
    if (name === 'claims')        await loadClaimsPane();
    if (name === 'achievements')  await loadAchievements();
    if (name === 'leaderboard')   await loadLeaderboard();
    if (name === 'subscriptions') await loadSubscriptions();
    if (name === 'profile')       await loadProfile();
  }

  // ── Subscriptions ─────────────────────────────────────────
  async function loadSubscriptions() {
    const box = document.getElementById('subList');
    if (!box) return;
    // Подгружаем категории в select
    const catSel = document.getElementById('subCategory');
    if (catSel && catSel.options.length === 1) {
      try {
        const { categories } = await api('/categories');
        categories.forEach(c => {
          const opt = document.createElement('option');
          opt.value = c.slug; opt.textContent = `${c.icon} ${c.name}`;
          catSel.appendChild(opt);
        });
      } catch {}
    }

    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { subscriptions } = await api('/subscriptions');
      if (!subscriptions.length) {
        box.innerHTML = `<div class="empty"><div class="empty-icon">🔔</div>${t('sub_empty')}</div>`;
        return;
      }
      box.innerHTML = subscriptions.map(s => `
        <div class="panel" style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px;padding:12px 16px">
          <div>
            ${s.item_type ? `<span class="badge">${s.item_type === 'lost' ? t('sub_type_lost_label') : t('sub_type_found_label')}</span> ` : ''}
            ${s.category_slug ? `<span class="badge" style="background:var(--subtle)">${s.category_slug}</span> ` : ''}
            ${s.location_keyword ? `<span>📍 ${esc(s.location_keyword)}</span>` : ''}
            <div style="font-size:.75rem;color:var(--muted);margin-top:4px">${timeAgo(s.created_at)}</div>
          </div>
          <button class="btn btn-ghost btn-sm" onclick="deleteSub(${s.id})">✕</button>
        </div>`).join('');
    } catch (e) { box.innerHTML = `<div class="empty">⚠️ ${e.message}</div>`; }
  }

  document.getElementById('btnAddSub')?.addEventListener('click', async () => {
    const type     = document.getElementById('subType')?.value;
    const location = document.getElementById('subLocation')?.value.trim();
    const category = document.getElementById('subCategory')?.value;
    if (!type && !location && !category)
      return toast(t('sub_fill_error'), 'error');
    try {
      await api('/subscriptions', { method: 'POST', body: JSON.stringify({
        item_type: type || null,
        location_keyword: location || null,
        category_slug: category || null,
      })});
      toast(t('sub_added'), 'success');
      loadSubscriptions();
    } catch (e) { toast(e.message, 'error'); }
  });

  window.deleteSub = async id => {
    try {
      await api(`/subscriptions/${id}`, { method: 'DELETE' });
      loadSubscriptions();
    } catch (e) { toast(e.message, 'error'); }
  };

  // ── My Items  🟡 #6 поиск  🟡 #7 пагинация
  const MY_PAGE_SIZE = 10;
  let _myItems = [], _myItemsPage = 1, _myItemsQ = '';

  async function loadMyItems() {
    const box = document.getElementById('myItemsList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { items } = await api('/my-items');
      _myItems = items;
      _myItemsPage = 1;
      renderMyItems();
    } catch (e) { box.innerHTML = `<div class="empty"><div class="empty-icon">⚠️</div>${e.message}</div>`; toast(e.message, 'error'); }
  }

  function renderMyItems() {
    const filtered = _myItems.filter(i => !_myItemsQ || i.title.toLowerCase().includes(_myItemsQ.toLowerCase()));
    const total = filtered.length, pages = Math.ceil(total / MY_PAGE_SIZE) || 1;
    _myItemsPage = Math.min(_myItemsPage, pages);
    const slice = filtered.slice((_myItemsPage - 1) * MY_PAGE_SIZE, _myItemsPage * MY_PAGE_SIZE);
    const box = document.getElementById('myItemsList');
    box.innerHTML = slice.length ? slice.map(i => itemCard(i, `
        <div style="display:flex;gap:4px" onclick="event.stopPropagation()">
          <button class="btn btn-ghost btn-sm" onclick="closeItem(${i.id},'closed')">Закрыть</button>
          <button class="btn btn-danger btn-sm" onclick="deleteMyItem(${i.id})">🗑</button>
        </div>`)).join('')
      : '<div class="empty" style="grid-column:1/-1"><div class="empty-icon">📋</div>Нет объявлений</div>';
    // Pager
    const pager = document.getElementById('myItemsPager');
    pager.innerHTML = pages > 1 ? Array.from({length: pages}, (_, i) =>
      `<button class="btn btn-sm ${i+1===_myItemsPage?'btn-primary':'btn-ghost'}" onclick="setMyItemsPage(${i+1})">${i+1}</button>`
    ).join('') : '';
  }

  window.setMyItemsPage = p => { _myItemsPage = p; renderMyItems(); };

  // Wire up search
  document.getElementById('myItemsSearchBtn')?.addEventListener('click', () => {
    _myItemsQ = document.getElementById('myItemsSearch').value.trim();
    _myItemsPage = 1; renderMyItems();
  });
  document.getElementById('myItemsSearch')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { _myItemsQ = e.target.value.trim(); _myItemsPage = 1; renderMyItems(); }
  });
  window.closeItem = async (id, s) => {
    try { await api(`/items/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status: s }) }); toast('Статус обновлён', 'success'); loadMyItems(); } catch (e) { toast(e.message, 'error'); }
  };
  window.deleteMyItem = async id => {
    if (!confirm('Удалить объявление?')) return;
    try { await api(`/items/${id}`, { method: 'DELETE' }); toast('Удалено', 'success'); loadMyItems(); } catch (e) { toast(e.message, 'error'); }
  };

  // ── Matches
  async function loadMatches() {
    const box = document.getElementById('matchesList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { matches } = await api('/matches');
      if (!matches.length) { box.innerHTML = `<div class="empty"><div class="empty-icon">🔍</div>${t('matches_empty')}</div>`; return; }
      const badge = document.getElementById('matchBadge');
      if (badge) { badge.textContent = matches.length; badge.style.display = 'inline'; }
      box.innerHTML = matches.map(m => {
        const cls = m.score >= 70 ? 'score-high' : m.score >= 45 ? 'score-medium' : 'score-low';
        return `<div class="match-card">
          <div class="match-score ${cls}">${m.score}%</div>
          <div style="flex:1">
            <div style="font-weight:600;font-size:.9rem;margin-bottom:4px">
              <a href="/item.html?id=${m.lost_id}" style="color:var(--primary)">${m.lost_title}</a>
              <span class="text-muted" style="font-size:.8rem"> ↔ </span>
              <a href="/item.html?id=${m.found_id}" style="color:var(--accent)">${m.found_title}</a>
            </div>
            <div class="text-muted" style="font-size:.78rem">📍 ${m.lost_location} · ${timeAgo(m.created_at)}</div>
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-accent btn-sm" onclick="confirmMatch(${m.id})">✅</button>
            <button class="btn btn-ghost btn-sm" onclick="rejectMatch(${m.id})">✕</button>
          </div>
        </div>`;
      }).join('');
    } catch (e) { box.innerHTML = `<div class="empty"><div class="empty-icon">⚠️</div>${e.message}</div>`; toast(e.message, 'error'); }
  }
  window.confirmMatch = async id => { try { await api(`/matches/${id}`, { method: 'PATCH', body: JSON.stringify({ status: 'confirmed' }) }); toast('Совпадение подтверждено!', 'success'); loadMatches(); } catch (e) { toast(e.message, 'error'); } };
  window.rejectMatch  = async id => { try { await api(`/matches/${id}`, { method: 'PATCH', body: JSON.stringify({ status: 'rejected'  }) }); toast(t('match_rejected'), 'info'); loadMatches(); } catch (e) { toast(e.message, 'error'); } };

  // ── Messages / Chat
  async function loadThreads() {
    const list = document.getElementById('threadList');
    list.innerHTML = `<div class="loading" style="padding:20px;font-size:.85rem">${t('loading')}</div>`;
    try {
      const { threads } = await api('/messages');
      if (!threads.length) { list.innerHTML = `<div class="empty" style="padding:24px;font-size:.85rem">${t('msgs_no_threads')}</div>`; return; }
      list.innerHTML = threads.map(th => `
        <div class="thread-item ${state.activeChatUser == th.contact_id ? 'active' : ''}" data-uid="${th.contact_id}">
          <div class="thread-avatar" style="overflow:hidden;flex-shrink:0">${th.contact_avatar ? `<img src="${th.contact_avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%" />` : (th.contact_name||'?')[0]}</div>
          <div style="flex:1;min-width:0">
            <div class="thread-name">${esc(th.contact_name)} ${th.unread > 0 ? `<span class="badge">${th.unread}</span>` : ''}</div>
            <div class="thread-preview">${th.last_msg || '…'}</div>
          </div>
        </div>`).join('');
      list.querySelectorAll('.thread-item').forEach(el => {
        el.addEventListener('click', () => {
          list.querySelectorAll('.thread-item').forEach(x => x.classList.remove('active'));
          el.classList.add('active');
          openChat(Number(el.dataset.uid), threads.find(th => th.contact_id == el.dataset.uid)?.contact_name);
        });
      });
    } catch (e) { list.innerHTML = `<div class="empty" style="padding:24px;font-size:.85rem">⚠️ ${e.message}</div>`; toast(e.message, 'error'); }
  }

  // ── WebSocket чат (без polling) ──────────────────────────
  let _chatPollTimer = null; // оставляем как fallback

  async function openChat(userId, name) {
    state.activeChatUser = userId;
    clearInterval(_chatPollTimer);
    const area = document.getElementById('chatArea');
    area.innerHTML = `
      <div style="padding:12px 16px;border-bottom:1px solid var(--border);font-weight:600;display:flex;align-items:center;gap:8px">
        ${esc(name)}
        <span id="typingIndicator" style="font-size:.75rem;color:var(--muted);font-weight:400"></span>
      </div>
      <div class="chat-messages" id="chatMsgs"></div>
      <div class="chat-input">
        <input id="chatIn" placeholder="Сообщение…" />
        <button class="btn btn-primary btn-sm" id="chatSend">→</button>
      </div>`;

    async function refreshMessages(scrollToBottom) {
      try {
        const { messages } = await api(`/messages/${userId}`);
        const box = document.getElementById('chatMsgs');
        if (!box) { clearInterval(_chatPollTimer); return; }
        const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
        box.innerHTML = messages.map(m => {
          const mine = m.sender_id === state.user.id;
          return `<div class="bubble ${mine ? 'bubble-me' : 'bubble-other'}">
            <div>${esc(m.body)}</div>
            <div class="bubble-time">${timeAgo(m.created_at)}</div>
          </div>`;
        }).join('');
        if (scrollToBottom || atBottom) box.scrollTop = box.scrollHeight;
      } catch {}
    }

    await refreshMessages(true);

    // Если WS подключён — используем его; иначе fallback polling
    if (_socket?.connected) {
      // Typing indicator: отправляем событие при вводе
      document.getElementById('chatIn')?.addEventListener('input', () => {
        _socket.emit('typing', { receiver_id: userId, is_typing: true });
        clearTimeout(window._typingTimer);
        window._typingTimer = setTimeout(() =>
          _socket.emit('typing', { receiver_id: userId, is_typing: false }), 2000);
      });
    } else {
      // Fallback: polling каждые 5 секунд
      _chatPollTimer = setInterval(() => refreshMessages(false), 5000);
    }

    const send = async () => {
      const inp = document.getElementById('chatIn');
      const body = inp.value.trim();
      if (!body) return;
      inp.value = '';
      _socket?.emit('typing', { receiver_id: userId, is_typing: false });
      try {
        if (_socket?.connected) {
          _socket.emit('send_message', { receiver_id: userId, body });
        } else {
          await api('/messages', { method: 'POST', body: JSON.stringify({ receiver_id: userId, body }) });
          await refreshMessages(true);
        }
      } catch (e) { toast(e.message, 'error'); }
    };
    document.getElementById('chatSend').addEventListener('click', send);
    document.getElementById('chatIn').addEventListener('keydown', e => e.key === 'Enter' && send());
  }
  // ── Notifications
  async function loadNotifications() {
    const box = document.getElementById('notifList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { notifications } = await api('/notifications');
      if (!notifications.length) { box.innerHTML = `<div class="empty"><div class="empty-icon">🔔</div>${t('notifs_empty')}</div>`; return; }
      box.innerHTML = notifications.map(n => `
        <div class="notif-item ${n.is_read ? '' : 'unread'}">
          <div class="notif-icon">${{match:'🔍',message:'💬',info:'ℹ️',warn:'⚠️',claim:'📬'}[n.type]||'🔔'}</div>
          <div class="notif-body">
            <strong>${n.title}</strong>
            <p>${n.body}</p>
            <p style="font-size:.75rem;color:var(--muted);margin-top:3px">${timeAgo(n.created_at)}</p>
          </div>
          ${!n.is_read ? `<button class="btn btn-ghost btn-sm" onclick="readNotif(${n.id})">✓</button>` : ''}
        </div>`).join('');
    } catch (e) { box.innerHTML = '<div class="empty"><div class="empty-icon">⚠️</div>Не удалось загрузить уведомления</div>'; toast(e.message, 'error'); }
  }
  window.readNotif = async id => { try { await api(`/notifications/${id}/read`, { method: 'PATCH' }); loadNotifications(); refreshBadges(); } catch {} };
  document.getElementById('markAllRead')?.addEventListener('click', async () => {
    try { await api('/notifications/all/read', { method: 'PATCH' }); loadNotifications(); refreshBadges(); } catch (e) { toast(e.message, 'error'); }
  });

  // ── Favorites  🟡 #6 поиск  🟡 #7 пагинация
  let _favItems = [], _favPage = 1, _favQ = '';

  async function loadFavorites() {
    const box = document.getElementById('favList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { items } = await api('/favorites');
      _favItems = items; _favPage = 1; renderFav();
    } catch (e) { box.innerHTML = `<div class="empty"><div class="empty-icon">⚠️</div>${e.message}</div>`; toast(e.message, 'error'); }
  }

  function renderFav() {
    const filtered = _favItems.filter(i => !_favQ || i.title.toLowerCase().includes(_favQ.toLowerCase()));
    const pages = Math.ceil(filtered.length / MY_PAGE_SIZE) || 1;
    _favPage = Math.min(_favPage, pages);
    const slice = filtered.slice((_favPage - 1) * MY_PAGE_SIZE, _favPage * MY_PAGE_SIZE);
    const box = document.getElementById('favList');
    box.innerHTML = slice.length ? slice.map(i => itemCard(i)).join('')
      : `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">❤️</div>${t('fav_empty')}</div>`;
    const pager = document.getElementById('favPager');
    pager.innerHTML = pages > 1 ? Array.from({length: pages}, (_, i) =>
      `<button class="btn btn-sm ${i+1===_favPage?'btn-primary':'btn-ghost'}" onclick="setFavPage(${i+1})">${i+1}</button>`
    ).join('') : '';
  }

  window.setFavPage = p => { _favPage = p; renderFav(); };

  document.getElementById('favSearchBtn')?.addEventListener('click', () => {
    _favQ = document.getElementById('favSearch').value.trim(); _favPage = 1; renderFav();
  });
  document.getElementById('favSearch')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { _favQ = e.target.value.trim(); _favPage = 1; renderFav(); }
  });

  // ── Claims pane  🔴 #4 — мои поданные заявки
  async function loadClaimsPane() {
    // Загружаем список своих заявок
    const listBox = document.getElementById('myClaimsList');
    if (listBox) {
      try {
        const { claims } = await api('/my-claims');
        const statusLabel = { pending: t('status_pending'), approved: t('status_approved_claim'), rejected: t('status_rejected_claim') };
        const statusClass = { pending: 'chip-open', approved: 'chip-found', rejected: 'chip-closed' };
        listBox.innerHTML = claims.length ? claims.map(c => `
          <div style="padding:10px 0;border-bottom:1px solid var(--border);display:flex;align-items:flex-start;gap:10px">
            <div style="flex:1">
              <a href="/item.html?id=${c.item_id}" style="font-weight:600;font-size:.9rem;color:var(--primary)">${esc(c.item_title || 'Объявление #'+c.item_id)}</a>
              <div class="text-muted" style="font-size:.78rem;margin-top:2px">${timeAgo(c.created_at)}</div>
              ${c.admin_note ? `<div style="font-size:.82rem;color:var(--muted);margin-top:4px">📝 ${esc(c.admin_note)}</div>` : ''}
            </div>
            <span class="chip ${statusClass[c.status]||'chip-open'}" style="white-space:nowrap;flex-shrink:0">${statusLabel[c.status]||c.status}</span>
          </div>`).join('')
          : `<div class="text-muted" style="font-size:.85rem;padding:8px 0">${t('my_claims_empty')}</div>`;
      } catch (e) { listBox.innerHTML = `<div class="text-muted">Не удалось загрузить: ${e.message}</div>`; }
    }

    // Форма подачи заявки (addEventListener только один раз)
    const form = document.getElementById('claimForm');
    if (form && !form._bound) {
      form._bound = true;
      form.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(e.target);
        try {
          await api('/claims', { method: 'POST', body: JSON.stringify({ item_id: fd.get('item_id'), proof: fd.get('proof') }) });
          toast('Заявка отправлена!', 'success');
          e.target.reset();
          loadClaimsPane(); // обновить список
        } catch (err) { toast(err.message, 'error'); }
      });
    }
  }

  // ── Profile  🔴 #2 смена пароля  🔴 #3 аватар
  async function loadProfile() {
    let user;
    try {
      ({ user } = await api('/auth/me'));
    } catch (e) { toast(e.message, 'error'); return; }

    // Аватар превью
    const prev = document.getElementById('profileAvatarPreview');
    if (prev) {
      if (user.avatar) {
        prev.innerHTML = `<img src="${user.avatar}" style="width:100%;height:100%;object-fit:cover" />`;
      } else {
        prev.textContent = (user.name||'?')[0].toUpperCase();
        prev.style.fontSize = '2rem';
      }
    }

    // Загрузка аватара
    const avatarInput = document.getElementById('avatarFileInput');
    if (avatarInput && !avatarInput._bound) {
      avatarInput._bound = true;
      avatarInput.addEventListener('change', async () => {
        const file = avatarInput.files[0];
        if (!file) return;
        const fd = new FormData(); fd.append('avatar', file);
        try {
          const res = await fetch('/api/auth/avatar', {
            method: 'POST', headers: { Authorization: `Bearer ${state.token}` }, body: fd
          });
          if (!res.ok) throw new Error((await res.json()).error);
          const { user: u } = await res.json();
          saveAuth(state.token, u);
          toast('Аватар обновлён!', 'success');
          // Обновить превью и сайдбар
          if (prev) prev.innerHTML = `<img src="${u.avatar}" style="width:100%;height:100%;object-fit:cover" />`;
          const sAv = document.getElementById('sAvatar');
          if (sAv) sAv.innerHTML = `<img src="${u.avatar}" style="width:100%;height:100%;object-fit:cover;border-radius:50%" />`;
        } catch (err) { toast(err.message || 'Ошибка загрузки', 'error'); }
      });
    }

    // Форма профиля
    const form = document.getElementById('profileForm');
    form.querySelector('[name=name]').value  = user.name  || '';
    form.querySelector('[name=phone]').value = user.phone || '';
    form.querySelector('[name=bio]').value   = user.bio   || '';
    const cityInput = form.querySelector('[name=city]');
    if (cityInput) cityInput.value = user.city || '';

    // ── Кнопка 🎯 «Моё местоположение» в профиле ──────
    const btnProfLoc  = document.getElementById('btnProfileMyLocation');
    const profLocStat = document.getElementById('profileLocStatus');
    if (btnProfLoc && cityInput && !btnProfLoc._bound) {
      btnProfLoc._bound = true;
      btnProfLoc.addEventListener('click', async () => {
        const orig = btnProfLoc.textContent;
        btnProfLoc.disabled = true;
        btnProfLoc.textContent = '⏳';
        if (profLocStat) profLocStat.textContent = 'Определяем…';
        try {
          const geo  = await getMyLocation({ timeout: 8000 });
          const addr = await reverseGeocode(geo.lat, geo.lng);
          if (addr) {
            cityInput.value = addr;
            if (profLocStat) profLocStat.textContent = '✅ ' + addr;
          } else {
            if (profLocStat) profLocStat.textContent = '⚠️ Адрес не найден — введите вручную.';
          }
        } catch (e) {
          toast(e.message, 'error');
          if (profLocStat) profLocStat.textContent = '';
        } finally {
          btnProfLoc.textContent = orig;
          btnProfLoc.disabled    = false;
        }
      });
    }

    form.onsubmit = async e => {
      e.preventDefault();
      const fd = new FormData(form);
      try {
        const res = await api('/auth/profile', { method: 'PUT', body: JSON.stringify({
          name:  fd.get('name'),
          phone: fd.get('phone'),
          bio:   fd.get('bio'),
          city:  fd.get('city') || '',
        }) });
        saveAuth(state.token, res.user);
        toast('Профиль сохранён!', 'success');
      } catch (err) { toast(err.message, 'error'); }
    };

    // 🔴 #2 — Смена пароля
    const cpForm = document.getElementById('changePassForm');
    if (cpForm && !cpForm._bound) {
      cpForm._bound = true;
      cpForm.addEventListener('submit', async e => {
        e.preventDefault();
        const fd = new FormData(cpForm);
        const msgEl = document.getElementById('changePassMsg');
        if (fd.get('new_password') !== fd.get('new_password2')) {
          msgEl.style.display = 'block';
          msgEl.style.cssText = 'display:block;font-size:.85rem;padding:8px 12px;border-radius:6px;margin-bottom:10px;background:#ff444422;color:#f87171;border:1px solid #f8717144';
          msgEl.textContent = 'Пароли не совпадают.';
          return;
        }
        const btn = cpForm.querySelector('button[type=submit]');
        btn.disabled = true;
        try {
          await api('/auth/change-password', { method: 'POST', body: JSON.stringify({
            current_password: fd.get('current_password'),
            new_password:     fd.get('new_password'),
          })});
          msgEl.style.cssText = 'display:block;font-size:.85rem;padding:8px 12px;border-radius:6px;margin-bottom:10px;background:var(--success,#1a7a4a22);color:#4ade80;border:1px solid #4ade8044';
          msgEl.textContent = '✅ Пароль успешно изменён.';
          cpForm.reset();
        } catch (err) {
          msgEl.style.cssText = 'display:block;font-size:.85rem;padding:8px 12px;border-radius:6px;margin-bottom:10px;background:#ff444422;color:#f87171;border:1px solid #f8717144';
          msgEl.textContent = err.message;
        } finally { btn.disabled = false; }
      });
    }

    // Ratings
    const rBox = document.getElementById('myRatings');
    try {
      const { ratings } = await api(`/ratings/${user.id}`);
      rBox.innerHTML = ratings.length
        ? `<h3 style="margin-bottom:10px">Отзывы (${user.rating} ⭐)</h3>` + ratings.map(r =>
          `<div style="padding:10px 0;border-bottom:1px solid var(--border)">
            <span>${'⭐'.repeat(r.score)}</span> <span class="text-muted" style="font-size:.8rem">от ${r.from_name}</span>
            ${r.comment ? `<p style="font-size:.85rem;margin-top:4px">${r.comment}</p>` : ''}
          </div>`).join('')
        : `<p class="text-muted" style="font-size:.85rem">Пока нет отзывов. Рейтинг: ${user.rating} ⭐</p>`;
    } catch {}
  }

  // ── Achievements / Gamification
  async function loadAchievements() {
    try {
      const { points, level, history, badges } = await api('/game/me');

      // Level card
      const pct = level.next ? Math.round((points / level.next) * 100) : 100;
      document.getElementById('achieveLevel').innerHTML = `
        <div style="display:flex;align-items:center;gap:16px">
          <div style="font-size:2.5rem">${level.icon}</div>
          <div style="flex:1">
            <div style="font-family:'Unbounded',sans-serif;font-size:1rem;margin-bottom:4px">
              Уровень ${level.level} — ${level.name}
            </div>
            <div style="background:var(--subtle);border-radius:99px;height:8px;margin-bottom:6px">
              <div style="background:var(--primary);height:8px;border-radius:99px;width:${pct}%;transition:width .5s"></div>
            </div>
            <div class="text-muted" style="font-size:.8rem">
              ${points} очков ${level.next ? `· До следующего уровня: ${level.next - points}` : '· Максимальный уровень!'}
            </div>
          </div>
          <div style="text-align:center">
            <div style="font-family:'Unbounded',sans-serif;font-size:1.6rem;color:var(--primary)">${points}</div>
            <div class="text-muted" style="font-size:.75rem">очков</div>
          </div>
        </div>`;

      // Badges
      const ALL_BADGES = {
        first_post:   { icon:'🌱', name:'Первый шаг',   desc:'Первое объявление' },
        helper:       { icon:'🤝', name:'Помощник',     desc:'Вещь возвращена' },
        super_helper: { icon:'🦸', name:'Супергерой',   desc:'5 возвратов' },
        communicator: { icon:'💬', name:'Коммуникатор', desc:'20 сообщений' },
        trusted:      { icon:'⭐', name:'Проверенный',  desc:'Рейтинг 4.5+' },
        detective:    { icon:'🕵️', name:'Детектив',    desc:'10 совпадений' },
        veteran:      { icon:'🏅', name:'Ветеран',      desc:'100 очков' },
        champion:     { icon:'🏆', name:'Чемпион',      desc:'500 очков' },
      };
      const earnedSlugs = new Set(badges.map(b => b.slug));
      const badgeBox = document.getElementById('achieveBadges');
      badgeBox.innerHTML = Object.entries(ALL_BADGES).map(([slug, b]) => {
        const earned = earnedSlugs.has(slug);
        return `<div title="${b.desc}" style="text-align:center;padding:10px;border-radius:12px;
          background:${earned ? 'rgba(59,130,246,0.1)' : 'var(--subtle)'};
          border:1px solid ${earned ? 'rgba(59,130,246,0.3)' : 'var(--border)'};
          opacity:${earned ? '1' : '0.4'}">
          <div style="font-size:1.6rem">${b.icon}</div>
          <div style="font-size:.7rem;margin-top:4px;font-weight:600">${b.name}</div>
        </div>`;
      }).join('');

      // History
      const histBox = document.getElementById('achieveHistory');
      histBox.innerHTML = history.length ? history.slice(0,10).map(h => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
          <span style="font-size:.82rem">${h.note}</span>
          <span style="color:var(--accent);font-weight:700;font-size:.85rem">+${h.points}</span>
        </div>`).join('')
        : `<p class="text-muted" style="font-size:.85rem">${t('points_history_empty')}</p>`;

    } catch (e) {
      const lvl = document.getElementById('achieveLevel');
      if (lvl) lvl.innerHTML = `<p class="text-muted">⚠️ ${e.message}</p>`;
      toast(e.message, 'error');
    }

    // Push notifications setup
    await initPush();
  }

  async function initPush() {
    const statusEl = document.getElementById('pushStatus');
    const btn      = document.getElementById('pushToggle');
    if (!btn) return;

    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      statusEl.textContent = 'Push-уведомления не поддерживаются вашим браузером.';
      btn.style.display = 'none';
      return;
    }

    try {
      const reg  = await navigator.serviceWorker.register('/sw.js');
      const perm = Notification.permission;
      const sub  = await reg.pushManager.getSubscription();

      if (sub) {
        statusEl.textContent = t('push_enabled_status');
        btn.textContent = t('push_disable');
        btn.className = 'btn btn-ghost btn-sm';
        btn.onclick = async () => {
          await sub.unsubscribe();
          await api('/push/unsubscribe', { method: 'POST', body: JSON.stringify({ endpoint: sub.endpoint }) });
          statusEl.textContent = t('push_disabled_status');
          btn.textContent = t('push_enable');
          btn.className = 'btn btn-primary btn-sm';
          toast(t('push_disable_toast'), 'info');
        };
      } else {
        statusEl.textContent = perm === 'denied'
          ? t('push_blocked_status')
          : t('push_disabled_status');
        btn.textContent = t('push_enable');
        btn.className = 'btn btn-primary btn-sm';
        btn.onclick = async () => {
          try {
            const { publicKey } = await api('/push/key');
            const newSub = await reg.pushManager.subscribe({
              userVisibleOnly: true,
              applicationServerKey: urlBase64ToUint8Array(publicKey),
            });
            await api('/push/subscribe', { method: 'POST', body: JSON.stringify({ subscription: newSub }) });
            statusEl.textContent = t('push_enabled_status');
            btn.textContent = t('push_disable');
            btn.className = 'btn btn-ghost btn-sm';
            toast(t('push_enable_toast'), 'success');
          } catch (e) { toast(t('push_enable_err') + ': ' + e.message, 'error'); }
        };
      }
    } catch (e) { statusEl.textContent = 'Ошибка инициализации: ' + e.message; }
  }

  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw     = atob(base64);
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
  }

  // ── Leaderboard
  async function loadLeaderboard() {
    const box = document.getElementById('leaderboardList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    try {
      const { leaderboard } = await api('/game/leaderboard');
      if (!leaderboard.length) { box.innerHTML = '<div class="empty">Нет данных</div>'; return; }
      box.innerHTML = `
        <div style="overflow:hidden;border-radius:14px;border:1px solid var(--border)">
          <table style="width:100%;border-collapse:collapse">
            <thead>
              <tr style="background:var(--subtle);font-size:.78rem;color:var(--muted)">
                <th style="padding:10px 14px;text-align:left">#</th>
                <th style="padding:10px 14px;text-align:left">Пользователь</th>
                <th style="padding:10px 14px;text-align:left">Уровень</th>
                <th style="padding:10px 14px;text-align:right">Очки</th>
                <th style="padding:10px 14px;text-align:right">Возвратов</th>
                <th style="padding:10px 14px;text-align:right">Рейтинг</th>
              </tr>
            </thead>
            <tbody>
              ${leaderboard.map((u, i) => {
                const medals = ['🥇','🥈','🥉'];
                const isMe   = u.id === state.user?.id;
                return `<tr style="border-top:1px solid var(--border);${isMe ? 'background:rgba(59,130,246,0.06)' : ''}">
                  <td style="padding:12px 14px;font-weight:700;color:var(--muted)">${medals[i] || i+1}</td>
                  <td style="padding:12px 14px">
                    <div style="font-weight:600;font-size:.9rem">${u.name}${isMe ? ' <span style="color:var(--primary);font-size:.75rem">(вы)</span>' : ''}</div>
                  </td>
                  <td style="padding:12px 14px"><span>${u.level.icon} ${u.level.name}</span></td>
                  <td style="padding:12px 14px;text-align:right;font-family:\'Unbounded\',sans-serif;color:var(--primary)">${u.total_points}</td>
                  <td style="padding:12px 14px;text-align:right;color:var(--accent)">${u.returns}</td>
                  <td style="padding:12px 14px;text-align:right">⭐ ${u.rating}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>`;
    } catch (e) { box.innerHTML = `<div class="empty"><div class="empty-icon">⚠️</div>${e.message}</div>`; toast(e.message, 'error'); }
  }

  // ── Initial load — respect URL hash for deep linking
  const hashPane = location.hash.replace('#', '');
  const validPanes = ['my-items','matches','messages','notifications','favorites','claims','achievements','leaderboard','subscriptions','profile'];
  const startPane = validPanes.includes(hashPane) ? hashPane : 'my-items';
  switchPane(startPane, false);
}

/* ═══════════════════════════════════════════════════════
   ADMIN PAGE
   ═══════════════════════════════════════════════════════ */
async function initAdmin() {
  if (!requireAuth() || !requireAdmin()) return;
  initThemeBtn();
  if (typeof applyI18n === 'function') applyI18n();
  document.getElementById('logoutBtn').addEventListener('click', () => { clearAuth(); location.href = '/'; });

  initTabs();

  async function loadStats() {
    try {
      const { stats } = await api('/admin/stats');
      document.getElementById('adminStats').innerHTML = `
        <div class="admin-stat"><strong>${stats.total}</strong><span>Всего</span></div>
        <div class="admin-stat"><strong>${stats.lost}</strong><span>${t('stat_lost')}</span></div>
        <div class="admin-stat"><strong>${stats.found}</strong><span>${t('stat_found')}</span></div>
        <div class="admin-stat"><strong>${stats.pending}</strong><span>${t('status_pending')}</span></div>
        <div class="admin-stat"><strong>${stats.users}</strong><span>${t('stat_users')}</span></div>`;
      const pb = document.getElementById('pendingBadge'); if (pb) pb.textContent = stats.pending;
      document.getElementById('claimsBadge').textContent  = stats.claims;
    } catch {}
  }

  function modCard(item, showModBtns = true) {
    const modLabels = {pending:t('status_pending'), approved:t('mod_approved'), rejected:t('mod_rejected')};
    const chips = `<span class="chip chip-${item.type}">${item.type==='lost'?`🔴 ${t('items_lost')}`:`🟢 ${t('items_found')}`}</span>
      <span class="chip chip-${item.moderation_status}">${modLabels[item.moderation_status]||item.moderation_status}</span>`;
    const checkbox = showModBtns
      ? `<input type="checkbox" class="pending-check" data-id="${item.id}" style="position:absolute;top:10px;right:10px;width:16px;height:16px;cursor:pointer" />`
      : '';
    const actions = showModBtns ? `<div class="mod-actions">
      ${item.moderation_status!=='approved' ? `<button class="btn btn-accent btn-sm" onclick="moderate(${item.id},'approve')">✅ Одобрить</button>` : ''}
      ${item.moderation_status!=='rejected' ? `<button class="btn btn-ghost btn-sm" onclick="promptReject(${item.id})">❌ Отклонить</button>` : ''}
      ${item.moderation_status==='approved'  ? `<button class="btn btn-warn btn-sm" onclick="moderate(${item.id},'return')">🎉 ${t('status_returned')}</button>` : ''}
      <button class="btn btn-danger btn-sm" onclick="adminDel(${item.id})">🗑</button>
    </div>` : '';
    return `<div class="mod-card" style="position:relative">
      ${checkbox}
      <div style="display:flex;gap:6px;margin-bottom:8px">${chips}</div>
      <h3><a href="/item.html?id=${item.id}" style="color:var(--text)">${item.title}</a></h3>
      <div class="meta">👤 ${item.owner_name||'—'} · 📂 ${item.category_name||'—'} · 📅 ${fmtDate(item.event_date)}</div>
      <div class="meta">📍 ${item.location_text}</div>
      ${actions}
    </div>`;
  }

  async function loadPending() {
    const box = document.getElementById('pendingList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    const { items } = await api('/admin/pending');
    box.innerHTML = items.length ? items.map(i => modCard(i)).join('')
      : `<div class="empty" style="grid-column:1/-1"><div class="empty-icon">✅</div>${t('admin_all_clear')}</div>`;
  }

  async function loadAllItems() {
    const box = document.getElementById('allItemsList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    const mod  = document.getElementById('filterMod').value;
    const type = document.getElementById('filterTypAdmin').value;
    const params = new URLSearchParams();
    if (mod)  params.append('moderation', mod);
    if (type) params.append('type', type);
    const { items } = await api('/admin/items?' + params);
    box.innerHTML = items.length ? items.map(i => modCard(i)).join('')
      : '<div class="empty" style="grid-column:1/-1">Ничего не найдено</div>';
  }

  async function loadUsers() {
    const box = document.getElementById('usersList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    const { users } = await api('/admin/users');
    box.innerHTML = users.map(u => `
      <div class="user-row">
        <div>
          <strong>${u.name}</strong>
          <div class="text-muted" style="font-size:.82rem">${u.email} · ⭐${u.rating} · ${fmtDate(u.created_at)}</div>
        </div>
        <div style="display:flex;gap:8px;align-items:center">
          <span class="chip ${u.role==='admin'?'chip-found':'chip-open'}">${u.role}</span>
          ${u.id !== state.user?.id ? `
          <button class="btn btn-ghost btn-sm" onclick="toggleRole(${u.id},'${u.role==='admin'?'user':'admin'}')">${u.role==='admin'?'→ user':'→ admin'}</button>
          <button class="btn ${u.is_banned?'btn-accent':'btn-danger'} btn-sm" onclick="toggleBan(${u.id},${u.is_banned?0:1})">${u.is_banned?'Разбан':'Бан'}</button>
          ` : '<span class="text-muted" style="font-size:.8rem">вы</span>'}
        </div>
      </div>`).join('');
  }

  async function loadClaims() {
    const box = document.getElementById('claimsList');
    box.innerHTML = `<div class="loading">${t('loading')}</div>`;
    const { claims } = await api('/admin/claims');
    box.innerHTML = claims.length ? claims.map(c => `
      <div class="mod-card" style="margin-bottom:10px">
        <h3>${c.item_title}</h3>
        <div class="meta">👤 ${c.requester_name} · ${fmtDate(c.created_at)}</div>
        <div style="background:var(--subtle);border-radius:8px;padding:8px;margin:8px 0;font-size:.85rem">${c.proof}</div>
        <span class="chip chip-${c.status}">${{pending:t('status_pending'),approved:t('status_approved_claim'),rejected:t('status_rejected_claim')}[c.status]}</span>
        ${c.status==='pending' ? `<div class="mod-actions">
          <button class="btn btn-accent btn-sm" onclick="processClaim(${c.id},'approve')">✅ Одобрить</button>
          <button class="btn btn-danger btn-sm" onclick="processClaim(${c.id},'reject')">❌ Отклонить</button>
        </div>` : ''}
      </div>`).join('')
      : `<div class="empty">${t('admin_claims_empty')}</div>`;
  }

  // Exposed functions
  window.moderate = async (id, action, reason='') => {
    try { await api(`/admin/items/${id}/moderate`, { method: 'PATCH', body: JSON.stringify({ action, reason }) });
      toast(action==='approve'?t('mod_approve_toast'):action==='reject'?t('mod_reject_toast'):t('mod_return_toast'),'success');
      await Promise.all([loadStats(), loadPending(), loadAllItems()]); } catch (e) { toast(e.message,'error'); }
  };
  window.promptReject = async id => {
    const reason = prompt(t('reject_reason'));
    if (reason === null) return;
    await window.moderate(id, 'reject', reason);
  };
  window.adminDel = async id => {
    if (!confirm('Удалить объявление?')) return;
    try { await api(`/admin/items/${id}`, { method: 'DELETE' }); toast('Удалено','success'); await Promise.all([loadStats(),loadPending(),loadAllItems()]); } catch (e) { toast(e.message,'error'); }
  };
  window.toggleRole = async (id, role) => {
    try { await api(`/admin/users/${id}/role`, { method: 'PATCH', body: JSON.stringify({ role }) }); toast('Роль обновлена','success'); loadUsers(); } catch (e) { toast(e.message,'error'); }
  };
  window.toggleBan = async (id, ban) => {
    try { await api(`/admin/users/${id}/ban`, { method: 'PATCH', body: JSON.stringify({ ban }) }); toast(ban?'Пользователь заблокирован':'Разблокирован','success'); loadUsers(); } catch (e) { toast(e.message,'error'); }
  };
  window.processClaim = async (id, action) => {
    const note = action === 'reject' ? (prompt(t('reject_reason_req')) || '') : '';
    if (action === 'reject' && note === null) return;
    try { await api(`/admin/claims/${id}`, { method: 'PATCH', body: JSON.stringify({ action, note }) }); toast('Готово','success'); await Promise.all([loadStats(),loadClaims()]); } catch (e) { toast(e.message,'error'); }
  };

  document.getElementById('applyFilter').addEventListener('click', loadAllItems);
  document.getElementById('refreshBtn').addEventListener('click', () => Promise.all([loadStats(),loadPending(),loadAllItems(),loadUsers(),loadClaims(),loadReports()]));

  // Handle tab switching to load data
  document.querySelectorAll('[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => {
      const t = btn.dataset.tab;
      if (t==='all-items')    loadAllItems();
      if (t==='users')        loadUsers();
      if (t==='claims')       loadClaims();
      if (t==='reports')      loadReports();
      if (t==='user-reports') loadUserReports();
      if (t==='analytics')    loadAnalytics();
    });
  });

  // Reports filter buttons
  document.querySelectorAll('.report-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.report-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadReports(btn.dataset.status);
    });
  });

  // User reports filter buttons
  document.querySelectorAll('.ur-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ur-filter').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadUserReports(btn.dataset.status);
    });
  });

  // ── Массовые действия ──────────────────────────────────
  let _selectedIds = new Set();
  function getSelectedIds() {
    return [...document.querySelectorAll('.pending-check:checked')].map(el => Number(el.dataset.id));
  }

  document.getElementById('bulkApproveBtn')?.addEventListener('click', async () => {
    const ids = getSelectedIds();
    if (!ids.length) return toast('Выберите объявления', 'error');
    try {
      const { processed } = await api('/admin/items/bulk', { method: 'POST', body: JSON.stringify({ ids, action: 'approve' }) });
      toast(`${t('mod_bulk_approve_toast')}: ${processed}`, 'success');
      loadPending();
    } catch (e) { toast(e.message, 'error'); }
  });

  document.getElementById('bulkRejectBtn')?.addEventListener('click', async () => {
    const ids = getSelectedIds();
    if (!ids.length) return toast('Выберите объявления', 'error');
    try {
      const { processed } = await api('/admin/items/bulk', { method: 'POST', body: JSON.stringify({ ids, action: 'reject' }) });
      toast(`${t('mod_bulk_reject_toast')}: ${processed}`, 'info');
      loadPending();
    } catch (e) { toast(e.message, 'error'); }
  });

  // ── Жалобы на пользователей ────────────────────────────
  async function loadUserReports(status = 'pending') {
    const box = document.getElementById('userReportsList');
    if (!box) return;
    box.innerHTML = `<div class="text-muted">${t('loading')}</div>`;
    try {
      const { reports } = await api(`/admin/user-reports?status=${status}`);
      if (status === 'pending') {
        const b = document.getElementById('userReportsBadge');
        if (b) b.textContent = reports.length;
      }
      if (!reports.length) { box.innerHTML = '<div class="empty"><div class="empty-icon">✅</div>Нет жалоб</div>'; return; }
      const REASONS = { spam:'Спам', fraud:'Мошенничество', abusive:'Оскорбления', fake:'Фейк', other:'Другое' };
      box.innerHTML = reports.map(r => `
        <div class="panel" style="margin-bottom:12px;display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
          <div style="flex:1;min-width:200px">
            <strong>На пользователя: ${esc(r.target_name)}</strong>
            <span style="color:var(--muted);font-size:.8rem"> (${esc(r.target_email)})</span><br/>
            <span style="font-size:.85rem">Жалобщик: ${esc(r.reporter_name)}</span><br/>
            <span class="badge">${REASONS[r.reason] || r.reason}</span>
            ${r.comment ? `<p style="margin-top:6px;font-size:.85rem;color:var(--muted)">${esc(r.comment)}</p>` : ''}
            <p style="font-size:.75rem;color:var(--muted);margin-top:4px">${timeAgo(r.created_at)}</p>
          </div>
          ${status === 'pending' ? `
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn btn-sm" style="background:#ef4444;color:#fff" onclick="processUserReport(${r.id},'ban')">🚫 Заблокировать</button>
            <button class="btn btn-ghost btn-sm" onclick="processUserReport(${r.id},'reviewed')">✓ Рассмотрено</button>
            <button class="btn btn-ghost btn-sm" onclick="processUserReport(${r.id},'dismissed')">✕ Отклонить</button>
          </div>` : ''}
        </div>`).join('');
    } catch (e) { box.innerHTML = `<div class="empty">⚠️ ${e.message}</div>`; }
  }

  window.processUserReport = async (id, action) => {
    try {
      await api(`/admin/user-reports/${id}`, { method: 'PATCH', body: JSON.stringify({ action }) });
      toast('Готово', 'success');
      const activeBtn = document.querySelector('.ur-filter.active');
      loadUserReports(activeBtn?.dataset.status || 'pending');
    } catch (e) { toast(e.message, 'error'); }
  };

  // ── Аналитика / графики ────────────────────────────────
  let _chartsDrawn = false;
  async function loadAnalytics() {
    if (_chartsDrawn) return;
    _chartsDrawn = true;
    try {
      const { charts } = await api('/admin/stats');
      const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#6366f1';
      const green  = '#22c55e';
      const purple = '#a855f7';

      function drawChart(canvasId, label, data, color) {
        const canvas = document.getElementById(canvasId);
        if (!canvas || typeof Chart === 'undefined') return;
        const labels = data.map(d => d.day?.slice(5)); // MM-DD
        const values = data.map(d => d.count);
        new Chart(canvas, {
          type: 'bar',
          data: {
            labels,
            datasets: [{ label, data: values, backgroundColor: color + '99', borderColor: color, borderWidth: 1, borderRadius: 4 }]
          },
          options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
              x: { grid: { display: false }, ticks: { font: { size: 10 }, maxRotation: 45 } },
              y: { beginAtZero: true, ticks: { precision: 0 } }
            }
          }
        });
      }

      drawChart('chartItems',   t('admin_chart_items'),   charts.daily,         accent);
      drawChart('chartReturns', t('admin_chart_returns'),  charts.returns,       green);
      drawChart('chartUsers',   t('admin_chart_users'),    charts.registrations, purple);
    } catch (e) { toast('Ошибка загрузки аналитики: ' + e.message, 'error'); }
  }

  async function loadReports(status = 'pending') {
    const box = document.getElementById('reportsList');
    if (!box) return;
    box.innerHTML = `<div class="text-muted">${t('loading')}</div>`;
    try {
      const { reports } = await api(`/admin/reports?status=${status}`);
      // Update badge with pending count
      if (status === 'pending') {
        const badge = document.getElementById('reportsBadge');
        if (badge) badge.textContent = reports.length;
      }
      if (!reports.length) { box.innerHTML = '<div class="empty"><div class="empty-icon">✅</div><p>Нет жалоб</p></div>'; return; }
      const REASON_LABELS = {
        spam: 'Спам', inappropriate: 'Неприемлемый контент',
        duplicate: 'Дубликат', fake: 'Мошенничество', other: 'Другое',
      };
      box.innerHTML = reports.map(r => `
        <div class="panel" style="margin-bottom:12px;display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
          <div style="flex:1;min-width:200px">
            <div style="font-weight:600;margin-bottom:4px">
              🚩 <a href="/item.html?id=${r.item_id}" target="_blank" style="color:var(--primary)">${r.item_title || 'Объявление #'+r.item_id}</a>
            </div>
            <div style="font-size:.82rem;color:var(--muted);margin-bottom:4px">
              Причина: <span style="color:var(--warn)">${REASON_LABELS[r.reason] || r.reason}</span>
              &nbsp;·&nbsp; От: ${r.reporter_name || 'Аноним'}
              &nbsp;·&nbsp; ${fmtDate(r.created_at)}
            </div>
            ${r.comment ? `<div style="font-size:.82rem;color:var(--text);margin-top:4px;padding:8px;background:var(--subtle);border-radius:6px">${r.comment}</div>` : ''}
          </div>
          <div style="display:flex;gap:6px;flex-shrink:0">
            <button class="btn btn-ghost btn-sm" onclick="handleReport(${r.id},'reviewed')">✅ Рассмотрено</button>
            <button class="btn btn-ghost btn-sm" style="color:var(--muted)" onclick="handleReport(${r.id},'dismissed')">❌ Отклонить</button>
          </div>
        </div>`).join('');
    } catch (e) { box.innerHTML = `<div class="text-muted">${e.message}</div>`; }
  }
  window.handleReport = async (reportId, action) => {
    try {
      await api(`/admin/reports/${reportId}`, { method: 'PATCH', body: JSON.stringify({ action }) });
      toast('Обновлено', 'success');
      const activeBtn = document.querySelector('.report-filter-btn.active');
      await loadReports(activeBtn?.dataset.status || 'pending');
    } catch (e) { toast(e.message, 'error'); }
  };

  await Promise.all([loadStats(), loadPending()]);
}

/* ═══════════════════════════════════════════════════════
   BOOTSTRAP
   ═══════════════════════════════════════════════════════ */
(async () => {
  const p = page();
  if (p === 'home')      await initHome();
  if (p === 'auth')      await initAuth();
  if (p === 'dashboard') await initDashboard();
  if (p === 'admin')     await initAdmin();
  if (p === 'item')      await initItem();
})();
