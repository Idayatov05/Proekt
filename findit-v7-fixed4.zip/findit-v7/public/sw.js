/* FindIt Service Worker — Web Push */
const CACHE = 'findit-v3';

self.addEventListener('install', e => {
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(clients.claim());
});

// Обработка push-уведомления
self.addEventListener('push', e => {
  if (!e.data) return;
  let data = {};
  try { data = e.data.json(); } catch { data = { title: 'FindIt', body: e.data.text() }; }

  e.waitUntil(
    self.registration.showNotification(data.title || 'FindIt', {
      body:  data.body  || '',
      icon:  data.icon  || '/icon-192.png',
      badge: data.badge || '/icon-96.png',
      data:  { url: data.url || '/' },
      vibrate: [200, 100, 200],
      tag: 'findit-' + Date.now(),
    })
  );
});

// Клик по уведомлению — открываем страницу
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = e.notification.data?.url || '/';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(cs => {
      for (const c of cs) {
        if (c.url.includes(url) && 'focus' in c) return c.focus();
      }
      return clients.openWindow(url);
    })
  );
});
