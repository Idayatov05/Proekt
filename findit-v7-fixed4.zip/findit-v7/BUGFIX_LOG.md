# Findit — Bug Fixes

## Баги исправлены

---

### 🔴 BUG 1 — `authOptional` middleware не работал (критический)
**Файл:** `src/middleware/auth.js` + `src/routes/index.js`

**Проблема:** Функция `authRequired(req, res, next, mode)` принимала `mode` 4-м аргументом.
Express вызывает middleware только с тремя аргументами `(req, res, next)` — 4-й аргумент никогда не передаётся.
Результат: `mode === 'optional'` всегда `undefined`, маршрут `GET /items/:id` требовал авторизацию
вместо пропуска анонимных пользователей → **401 для неавторизованных**.

**Исправление:** Заменён на factory-функцию `authMiddleware(mode)` которая возвращает правильный
3-аргументный middleware. Добавлены именованные экспорты `authRequired` и `authOptional`.

---

### 🔴 BUG 2 — `/notifications/all/read` конфликтовал с `/notifications/:id/read` (критический)
**Файл:** `src/routes/index.js` + `src/controllers/social.js`

**Проблема:** Маршрут `PATCH /notifications/:id/read` перехватывал запрос
`PATCH /notifications/all/read`, передавая `req.params.id = 'all'`.
Контроллер проверял `if (req.params.id === 'all')` — это работало, но только по случайности.
При добавлении middleware или изменении порядка роутов — ломалось.

**Исправление:** Разделены на два отдельных маршрута:
- `PATCH /notifications/all/read` → `markAllNotifsRead`
- `PATCH /notifications/:id/read` → `markNotifRead`

Маршрут `all` зарегистрирован **до** `/:id`.

---

### 🔴 BUG 3 — `pushService.saveSubscription` падал с TypeError (критический)
**Файл:** `src/services/pushService.js`

**Проблема:** Деструктуризация `const { endpoint, keys: { p256dh, auth } } = subscription`
падает с `TypeError: Cannot destructure property 'p256dh' of undefined` если `subscription.keys`
отсутствует (старые браузеры, malformed запрос).

**Исправление:** Добавлена явная проверка перед деструктуризацией:
```js
if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
  throw new Error('Некорректная push-подписка: отсутствуют endpoint или keys.');
}
```

---

### 🟡 BUG 4 — `/map` страница возвращала 404 (средний)
**Файл:** `src/app.js`

**Проблема:** SPA-fallback список страниц не включал `/map`, поэтому переход
на `/map` отдавал `index.html` вместо `map.html`, что ломало карту находок.

**Исправление:** Добавлен `/map` в массив `pages`.

---

### 🟡 BUG 5 — Некорректный код в `initPush` unsubscribe handler (средний)
**Файл:** `public/app.js`

**Проблема:** Строка `btn.click && statusEl && (statusEl.textContent = '...')` 
выглядит как проверка условия, но `btn.click` — это всегда truthy (метод объекта).
По сути это запутанная запись обычного присваивания, которая может скрыть ошибки.

**Исправление:** Заменено на прямое присваивание:
```js
statusEl.textContent = '🔕 Уведомления отключены';
```

---

### 🟢 BUG 6 — Неиспользуемый импорт `notifyApproved` в `items.js` (минорный)
**Файл:** `src/controllers/items.js`

**Проблема:** `const { notifyApproved } = require('../services/pushService')` импортируется,
но нигде не вызывается в `items.js` (функция используется только в `admin.js`).
Лишний импорт запутывает код.

**Исправление:** Импорт удалён.

---

## Файлы изменены

| Файл | Баги |
|------|------|
| `src/middleware/auth.js` | BUG 1 |
| `src/routes/index.js` | BUG 1, BUG 2 |
| `src/controllers/social.js` | BUG 2 |
| `src/services/pushService.js` | BUG 3 |
| `src/app.js` | BUG 4 |
| `public/app.js` | BUG 5 |
| `src/controllers/items.js` | BUG 6 |

## Запуск

```bash
npm install
cp .env.example .env
# Отредактируйте .env (JWT_SECRET обязателен)
node server.js
```

Тестовые аккаунты:
- **Админ:** `admin@findit.kz` / `admin123`
- **Юзер:** `user@findit.kz` / `user123`

---

## v4.0 — Полный апдейт (🔴🟡🟢)

### 🔴 Критические (влияют на работу)

**#1 — Email-отправка (nodemailer)**
- Добавлена зависимость `nodemailer` в `package.json`
- `src/config/env.js` — новые переменные `SMTP_HOST/PORT/SECURE/USER/PASS/EMAIL_FROM`
- `src/controllers/auth.js` — `sendResetEmail()`: если SMTP настроен → шлёт красивое HTML-письмо; иначе — fallback на `console.log` (dev-режим, ссылка в ответе)
- `.env.example` — примеры для Resend, Gmail

**#2 — Смена пароля в профиле**
- `POST /api/auth/change-password` (authRequired) — принимает `current_password` + `new_password`, проверяет текущий пароль
- `dashboard.html` — блок «Безопасность» с тремя полями (текущий / новый / повтор)
- `app.js` — `loadProfile()` вешает обработчик, показывает цветное сообщение об успехе/ошибке

**#3 — Аватар в профиле**
- `POST /api/auth/avatar` (authRequired, multer) — загружает фото, сохраняет URL в `users.avatar`
- `dashboard.html` — круглый превью + кнопка «Загрузить фото» с `<input type=file>`
- `app.js` — после загрузки обновляет превью, сайдбар и `state.user`

**#4 — Список своих заявок (Заявки)**
- `Claims.listByUser(userId)` — новый метод в `models/index.js`
- `social.getMyClaims` — контроллер
- `GET /api/my-claims` (authRequired) — маршрут
- `dashboard.html` — панель «Мои поданные заявки» с чипом статуса и ссылкой на объявление
- После отправки новой заявки список обновляется автоматически

---

### 🟡 Улучшения UX

**#5 — Реальное время в чате**
- `openChat()` полностью переписан: `refreshMessages()` отдельная функция
- `_chatPollTimer = setInterval(refreshMessages, 4000)` — обновление каждые 4 сек
- При переключении вкладки и при уходе со вкладки «Сообщения» таймер сбрасывается (`clearInterval`)
- Авто-скролл: только если пользователь уже был у нижнего края

**#6 — Поиск внутри дашборда**
- «Мои объявления»: поле + кнопка 🔍, фильтрация по названию в памяти
- «Избранное»: аналогичное поле + кнопка 🔍

**#7 — Пагинация в дашборде**
- «Мои объявления» и «Избранное»: `MY_PAGE_SIZE = 10`, страницы рендерятся кнопками под списком
- Данные загружаются один раз, фильтрация/страницы — клиентские

**#8 — Подтверждение перед удалением** ✅ уже было реализовано (`confirm('Удалить объявление?')`)

---

### 🟢 Новые фичи

**#9 — Badge-счётчики в реальном времени** ✅ уже было: `setInterval(refreshBadges, 30000)`

**#10 — Фото в профиле собеседника**
- Список диалогов: аватар-картинка если `contact_avatar` есть, иначе инициал
- Сайдбар: `<img>` с аватаром вместо инициала, `onerror` фолбек на инициал

**#11 — Поделиться объявлением** ✅ уже было: Web Share API + clipboard fallback

**#12 — История поиска**
- `localStorage` ключ `findit_search_history`, хранит 5 последних запросов
- Дропдаун при фокусе/вводе в поле поиска: клик — подставляет запрос, ✕ — удаляет
- После нажатия «Найти» запрос сохраняется, дропдаун скрывается
